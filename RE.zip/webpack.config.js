const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')

const config = [{
    mode: "development",
    entry: {
        Index: [path.resolve('src', 'components','pages', 'Index.js')],
        Store: [path.resolve('src', 'components','pages', 'Store.js')],
        Shop: [path.resolve('src', 'components','pages', 'Shop.js')],
        ShopCategory: [path.resolve('src', 'components','pages', 'ShopCategory.js')],
        Stores: [path.resolve('src', 'components','pages', 'Stores.js')],
        Survey: [path.resolve('src', 'components','pages', 'Survey.js')],
        Career: [path.resolve('src', 'components','pages', 'Career.js')],
        CareerSingle: [path.resolve('src', 'components','pages', 'CareerSingle.js')],
        FAQ: [path.resolve('src', 'components','pages', 'FAQ.js')],
        About: [path.resolve('src', 'components','pages', 'About.js')],
        Tnc: [path.resolve('src', 'components','pages', 'Tnc.js')],
        Privacy: [path.resolve('src', 'components','pages', 'Privacy.js')],
        Contact: [path.resolve('src', 'components','pages', 'Contact.js')],
        TakeSurvey: [path.resolve('src', 'components','pages', 'TakeSurvey.js')],
        HowItWorks: [path.resolve('src', 'components','pages', 'HowItWorks.js')],
        Vision: [path.resolve('src', 'components','pages', 'Vision.js')],
        FourOFour: [path.resolve('src', 'components','pages', 'FourOFour.js')],
        
        Register: [path.resolve('src', 'components', 'auth', 'Register.js')],
        Login: [path.resolve('src', 'components', 'auth', 'Login.js')],
        ForgotPassword: [path.resolve('src', 'components', 'auth', 'ForgotPassword.js')],
        ResetPassword: [path.resolve('src', 'components', 'auth', 'ResetPassword.js')],
        
        Blog: [path.resolve('src', 'components', 'blog', 'Blog.js')],
        Category: [path.resolve('src', 'components', 'blog', 'Blog.js')],
        Search: [path.resolve('src', 'components', 'blog', 'Blog.js')],
        Single: [path.resolve('src', 'components', 'blog', 'Single.js')],
        
        Summary: [path.resolve('src', 'components', 'admin', 'Summary.js')],
        AdminUser: [path.resolve('src', 'components', 'admin', 'User.js')],
        AdminContacts: [path.resolve('src', 'components', 'admin', 'AdminContacts.js')],
        AdminBlogMeta: [path.resolve('src', 'components', 'admin', 'AdminBlogMeta.js')],
        AdminBlogs: [path.resolve('src', 'components', 'admin', 'AdminBlogs.js')],
        AddBlog: [path.resolve('src', 'components', 'admin', 'AddBlog.js')],
        UpdateBlog: [path.resolve('src', 'components', 'admin', 'UpdateBlog.js')],
        AdminMeta: [path.resolve('src', 'components', 'admin', 'Meta.js')],
        AdminComments: [path.resolve('src', 'components', 'admin', 'AdminComments.js')],
        AdminBasics: [path.resolve('src', 'components', 'admin', 'Basic.js')],
        SurveyResponse: [path.resolve('src', 'components', 'admin', 'SurveyResponse.js')],
        CheckSurvey: [path.resolve('src', 'components', 'admin', 'CheckSurvey.js')],
        AdminCareer: [path.resolve('src', 'components', 'admin', 'AdminCareer.js')],
        RefSchema: [path.resolve('src', 'components','admin', 'RefSchema.js')],
        RefSitemap: [path.resolve('src', 'components','admin', 'RefSitemap.js')],
        
        AdminCategory: [path.resolve('src', 'components', 'store', 'AdminCategory.js')],
        AdminCoupon: [path.resolve('src', 'components', 'store', 'AdminCoupon.js')],
        AdminDeal: [path.resolve('src', 'components', 'store', 'AdminDeal.js')],
        AdminStore: [path.resolve('src', 'components', 'store', 'AdminStore.js')],
        CreateStore: [path.resolve('src', 'components', 'store', 'CreateStore.js')],
        UpdateStore: [path.resolve('src', 'components', 'store', 'UpdateStore.js')],
        UpdateDeal: [path.resolve('src', 'components', 'store', 'UpdateDeal.js')],
        UpdateCoupon: [path.resolve('src', 'components', 'store', 'UpdateCoupon.js')],
        AdminCashback: [path.resolve('src', 'components', 'store', 'AdminCashback.js')],
        LeaderBoard: [path.resolve('src', 'components', 'store', 'LeaderBoard.js')],
        Advertisement: [path.resolve('src', 'components', 'admin', 'Advertisement.js')],
        Special: [path.resolve('src', 'components', 'admin', 'Special.js')],
        AddSurvey: [path.resolve('src', 'components', 'admin', 'AddSurvey.js')],
        QuestionBank: [path.resolve('src', 'components', 'admin', 'QuestionBank.js')],
        AdminSurvey: [path.resolve('src', 'components', 'admin', 'Survey.js')],
        UpdateSurvey: [path.resolve('src', 'components', 'admin', 'UpdateSurvey.js')],
        JobApplications: [path.resolve('src', 'components', 'admin', 'JobApplications.js')],
        Subscription: [path.resolve('src', 'components', 'admin', 'Subscription.js')],
        VendorAPI: [path.resolve('src', 'components', 'admin', 'VendorAPI.js')],
        CashOut: [path.resolve('src', 'components', 'admin', 'CashOut.js')],
        
        AppliedJobs: [path.resolve('src', 'components', 'user', 'AppliedJobs.js')],
        CashbackHistory: [path.resolve('src', 'components', 'user', 'CashbackHistory.js')],
        MyAccount: [path.resolve('src', 'components', 'user', 'MyAccount.js')],
        MyProfile: [path.resolve('src', 'components', 'user', 'MyProfile.js')],
        ReferNEarn: [path.resolve('src', 'components', 'user', 'ReferNEarn.js')],
        YourSurveys: [path.resolve('src', 'components', 'user', 'YourSurveys.js')],
        SurveyCategory: [path.resolve('src', 'components','user', 'SurveyCategory.js')],
        SurveySingle: [path.resolve('src', 'components','user', 'SurveySingle.js')],
        CashbackReward: [path.resolve('src', 'components','user', 'CashbackReward.js')],
        SavedCoupons: [path.resolve('src', 'components','user', 'SavedCoupons.js')],
    },
    output: {
        path: path.resolve(__dirname, 'src', 'static', 'public'),
        filename: 'js/[chunkhash].js',
        publicPath: '/public'
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: [/node_modules/, /static/],
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env', '@babel/preset-react'],
                        plugins: ['@babel/transform-runtime']
                    }
                }
            }, 
            {
                test: /\.ejs$/,
                loader: 'raw-loader'
            }, 
            {
                test: /\.(css)/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                        publicPath: '/public/css/'
                    }
                }, 'css-loader']  
            }
        ]
    },
    resolve: {
        extensions: ['.js', '.jsx', '.json', '.wasm', '.mjs', '*']
    },
    optimization: {
        splitChunks: {
            automaticNameDelimiter: '.',
            cacheGroups: {
                react: {
                    chunks: 'initial',
                }
            }
        }
    },
    plugins: [
        new MiniCssExtractPlugin({ chunkFilename: 'css/[hash].css' }),
        new HtmlWebpackPlugin({ chunks: ['Index'], filename: '../views/pages/Index.ejs', template: path.join('src', 'views', 'index.ejs') }),       
        new HtmlWebpackPlugin({ chunks: ['Store'], filename: '../views/pages/Store.ejs', template: path.join('src', 'views', 'index.ejs') }),       
        new HtmlWebpackPlugin({ chunks: ['Shop'], filename: '../views/pages/Shop.ejs', template: path.join('src', 'views', 'index.ejs') }),       
        new HtmlWebpackPlugin({ chunks: ['ShopCategory'], filename: '../views/pages/ShopCategory.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Stores'], filename: '../views/pages/Stores.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Survey'], filename: '../views/pages/Survey.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['TakeSurvey'], filename: '../views/pages/TakeSurvey.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Career'], filename: '../views/pages/Career.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['CareerSingle'], filename: '../views/pages/CareerSingle.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['FAQ'], filename: '../views/pages/FAQ.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Contact'], filename: '../views/pages/Contact.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['HowItWorks'], filename: '../views/pages/HowItWorks.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['About'], filename: '../views/pages/About.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Tnc'], filename: '../views/pages/Tnc.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Privacy'], filename: '../views/pages/Privacy.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Vision'], filename: '../views/pages/Vision.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['FourOFour'], filename: '../views/pages/FourOFour.ejs', template: path.join('src', 'views', 'index.ejs') }),
        
        new HtmlWebpackPlugin({ chunks: ['Register'], filename: '../views/auth/Register.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Login'], filename: '../views/auth/Login.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['ForgotPassword'], filename: '../views/auth/ForgotPassword.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['ResetPassword'], filename: '../views/auth/ResetPassword.ejs', template: path.join('src', 'views', 'index.ejs') }),
        
        new HtmlWebpackPlugin({ chunks: ['Blog'], filename: '../views/blog/Blog.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Single'], filename: '../views/blog/Single.ejs', template: path.join('src', 'views', 'index.ejs') }),
        
        new HtmlWebpackPlugin({ chunks: ['Summary'], filename: '../views/admin/Summary.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminUser'], filename: '../views/admin/User.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminContacts'], filename: '../views/admin/AdminContacts.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminBlogMeta'], filename: '../views/admin/AdminBlogMeta.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminBlogs'], filename: '../views/admin/AdminBlogs.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AddBlog'], filename: '../views/admin/AddBlog.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['UpdateBlog'], filename: '../views/admin/UpdateBlog.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminMeta'], filename: '../views/admin/Meta.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminComments'], filename: '../views/admin/AdminComments.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminBasics'], filename: '../views/admin/AdminBasics.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['SurveyResponse'], filename: '../views/admin/SurveyResponse.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['RefSchema'], filename: '../views/admin/RefSchema.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['RefSitemap'], filename: '../views/admin/RefSitemap.ejs', template: path.join('src', 'views', 'index.ejs') }),
        
        new HtmlWebpackPlugin({ chunks: ['AdminCategory'], filename: '../views/store/AdminCategory.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminStore'], filename: '../views/store/AdminStore.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminCoupon'], filename: '../views/store/AdminCoupon.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminDeal'], filename: '../views/store/AdminDeal.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['CreateStore'], filename: '../views/store/CreateStore.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['UpdateStore'], filename: '../views/store/UpdateStore.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['UpdateDeal'], filename: '../views/store/UpdateDeal.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['UpdateCoupon'], filename: '../views/store/UpdateCoupon.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminCashback'], filename: '../views/store/AdminCashback.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['LeaderBoard'], filename: '../views/store/LeaderBoard.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Advertisement'], filename: '../views/admin/Advertisement.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Special'], filename: '../views/admin/Special.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AddSurvey'], filename: '../views/admin/AddSurvey.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['QuestionBank'], filename: '../views/admin/QuestionBank.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminSurvey'], filename: '../views/admin/Survey.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['UpdateSurvey'], filename: '../views/admin/UpdateSurvey.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['CheckSurvey'], filename: '../views/admin/CheckSurvey.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['AdminCareer'], filename: '../views/admin/AdminCareer.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['JobApplications'], filename: '../views/admin/JobApplications.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['Subscription'], filename: '../views/admin/Subscription.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['VendorAPI'], filename: '../views/admin/VendorAPI.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['CashOut'], filename: '../views/admin/CashOut.ejs', template: path.join('src', 'views', 'index.ejs') }),
        
        new HtmlWebpackPlugin({ chunks: ['AppliedJobs'], filename: '../views/user/AppliedJobs.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['CashbackHistory'], filename: '../views/user/CashbackHistory.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['MyAccount'], filename: '../views/user/MyAccount.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['MyProfile'], filename: '../views/user/MyProfile.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['ReferNEarn'], filename: '../views/user/ReferNEarn.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['YourSurveys'], filename: '../views/user/YourSurveys.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['SurveyCategory'], filename: '../views/user/SurveyCategory.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['SurveySingle'], filename: '../views/user/SurveySingle.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['CashbackReward'], filename: '../views/user/CashbackReward.ejs', template: path.join('src', 'views', 'index.ejs') }),
        new HtmlWebpackPlugin({ chunks: ['SavedCoupons'], filename: '../views/user/SavedCoupons.ejs', template: path.join('src', 'views', 'index.ejs') }),
    ]
    // devtool: 'source-map'
}]

module.exports = config