"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _Index = _interopRequireDefault(require("../../pages/index/Index"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_Index.default, null), document.getElementById("root"));