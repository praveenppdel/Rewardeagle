"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _FourOFour = _interopRequireDefault(require("../../pages/index/FourOFour"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_FourOFour.default, null), document.getElementById("root"));