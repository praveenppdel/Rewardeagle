"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _Survey = _interopRequireDefault(require("../../pages/index/Survey"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_Survey.default, null), document.getElementById("root"));