"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _Contact = _interopRequireDefault(require("../../pages/index/Contact"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_Contact.default, null), document.getElementById("root"));