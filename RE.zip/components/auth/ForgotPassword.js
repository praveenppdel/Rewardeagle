"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _ForgotPassword = _interopRequireDefault(require("../../pages/auth/ForgotPassword"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_ForgotPassword.default, null), document.getElementById("root"));