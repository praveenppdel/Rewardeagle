"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _QuestionBank = _interopRequireDefault(require("../../pages/admin/QuestionBank"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_QuestionBank.default, null), document.getElementById("root"));