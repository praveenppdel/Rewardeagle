"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _AddSurvey = _interopRequireDefault(require("../../pages/admin/AddSurvey"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_AddSurvey.default, null), document.getElementById("root"));