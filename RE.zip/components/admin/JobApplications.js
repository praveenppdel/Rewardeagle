"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _JobApplications = _interopRequireDefault(require("../../pages/admin/JobApplications"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_JobApplications.default, null), document.getElementById("root"));