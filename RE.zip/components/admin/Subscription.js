"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _Subscription = _interopRequireDefault(require("../../pages/admin/Subscription"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_Subscription.default, null), document.getElementById("root"));