"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _CheckSurvey = _interopRequireDefault(require("../../pages/admin/CheckSurvey"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_CheckSurvey.default, null), document.getElementById("root"));