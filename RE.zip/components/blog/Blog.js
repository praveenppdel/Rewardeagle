"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _Blog = _interopRequireDefault(require("../../pages/blog/Blog"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_Blog.default, null), document.getElementById("root"));