"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _CashbackHistory = _interopRequireDefault(require("../../pages/user/CashbackHistory"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_CashbackHistory.default, null), document.getElementById("root"));