"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _ReferNEarn = _interopRequireDefault(require("../../pages/user/ReferNEarn"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_ReferNEarn.default, null), document.getElementById("root"));