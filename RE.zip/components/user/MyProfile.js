"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _MyProfile = _interopRequireDefault(require("../../pages/user/MyProfile"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_MyProfile.default, null), document.getElementById("root"));