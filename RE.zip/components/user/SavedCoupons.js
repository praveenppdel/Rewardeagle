"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _SavedCoupons = _interopRequireDefault(require("../../pages/user/SavedCoupons"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_SavedCoupons.default, null), document.getElementById("root"));