"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _AdminCoupon = _interopRequireDefault(require("../../pages/store/AdminCoupon"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_AdminCoupon.default, null), document.getElementById("root"));