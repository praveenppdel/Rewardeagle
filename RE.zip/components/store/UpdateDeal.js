"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = _interopRequireDefault(require("react"));

var _reactDom = require("react-dom");

var _UpdateDeal = _interopRequireDefault(require("../../pages/store/UpdateDeal"));

(0, _reactDom.render)( /*#__PURE__*/_react.default.createElement(_UpdateDeal.default, null), document.getElementById("root"));