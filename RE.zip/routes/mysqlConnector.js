"use strict";

var mysql = require('mysql');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  database: 'reward',
  password: '',
  multipleStatements: true
});
module.exports = pool;