"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _express = _interopRequireDefault(require("express"));

const router = _express.default.Router();

var pool = require('./mysqlConnector');

const asyncMiddleware = require('./asyncMiddleware');

const func = require('./functions');

const time = new Date().toISOString().slice(0, 19).replace('T', ' ');

const path = require('path');

const upload = require('express-fileupload');

const fs = require('fs');

router.use(upload());

const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtpout.secureserver.net",
  port: 465,
  secure: true,
  auth: {
    user: 'noreply@rewardeagle.com',
    pass: 'CasleyRe2021ILU',
    debug: true
  },
  tls: {
    rejectUnauthorized: false,
    secureProtocol: "TLSv1_method"
  }
}); // const storage = './src/public/images/'

const storage = path.join(__dirname, '../public/images/');
router.get('/adminUsers', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, name, email, role, phone, referralcode, created_at FROM users Limit 5000;
                SELECT count('id') FROM users;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0],
          count: results[1][0]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/getUserPaginated', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, name, email, role, phone, referralcode, created_at FROM users where id between '${req.body.from}' AND '${req.body.to}';`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getProfile/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.*, b.name, b.email, b.role, b.phone FROM userprofile as a left join users as b on a.userId = b.id WHERE a.userId = '${req.params.id}'`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/AdminMetas', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, title, url, description, keyword, updated_at FROM metas ORDER BY id DESC`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const pending = await func.pendingMeta();
        res.send({
          data: results,
          pending
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addMeta', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "url": req.body.url,
    "title": req.body.title,
    "description": req.body.description,
    "keyword": req.body.keyword,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO metas SET ?';
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const pending = await func.pendingMeta();
        const data = await func.getSingleMeta(results.insertId);
        res.send({
          success: true,
          data,
          pending,
          message: 'Meta added successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateMeta', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "url": req.body.url,
    "title": req.body.title,
    "description": req.body.description,
    "keyword": req.body.keyword,
    "updated_at": time
  };
  let sql = `UPDATE metas SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const pending = await func.pendingMeta();
        const data = await func.getSingleMeta(req.body.id);
        res.send({
          success: true,
          data,
          pending,
          message: 'Meta updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminBlogMeta', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, type, name, url FROM blog_metas ORDER BY id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (results) {
        res.send({
          data: results
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addBlogMeta', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "type": req.body.type,
    "url": req.body.url,
    "created_at": time,
    "updated_at": time
  };

  if (req.body.type === 'page') {
    if (req.files.cover) {
      var file = req.files.cover;
      var filename = Date.now() + '-' + file.name;
      file.mv(storage + 'cover/' + filename, function (err) {
        if (err) {
          func.printError(err);
        }
      });
      post.name = filename;
    }
  } else {
    post.name = req.body.name;
  }

  let sql = 'INSERT INTO blog_metas SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (err) throw err;

      if (results) {
        let sql = `SELECT id, type, name, url, updated_at FROM blog_metas ORDER BY id DESC LIMIT 1`;
        pool.query(sql, (err, results2) => {
          try {
            if (err) throw err;
            res.send({
              success: true,
              data: results2[0],
              message: 'Blog meta added successfuly'
            });
          } catch (e) {
            func.logError(e);
            res.status(403);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(403);
      return;
    }
  });
}));
router.post('/updateBlogMeta', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "type": req.body.type,
    "url": req.body.url,
    "updated_at": time
  };

  if (req.body.type === 'page') {
    if (req.files.cover) {
      var file = req.files.cover;
      var filename = Date.now() + '-' + file.name;
      var oldCover = req.body.oldCover;

      if (oldCover) {
        if (fs.existsSync(storage + 'cover/' + oldCover)) {
          fs.unlinkSync(storage + 'cover/' + oldCover);
        }

        file.mv(storage + 'cover/' + filename, function (err) {
          if (err) {
            func.printError(err);
          }
        });
      }

      post.name = filename;
    }
  } else {
    post.name = req.body.name;
  }

  let sql = `UPDATE blog_metas SET ? WHERE id = ${req.body.id} `;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) throw err;

      if (err) {
        res.send({
          success: false,
          message: err.sqlMessage
        });
      }

      if (results) {
        let sql = `SELECT id, type, name, url, updated_at FROM blog_metas WHERE id = ${req.body.id}`;
        pool.query(sql, (err, results2) => {
          try {
            if (err) throw err;
            res.send({
              success: true,
              data: results2[0],
              message: 'Blog meta updated successfuly'
            });
          } catch (e) {
            func.logError(e);
            res.status(403);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(403);
      return;
    }
  });
}));
router.get('/adminBlogs', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, title, url, coverImg, updated_at FROM blogs ORDER BY id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (results) {
        res.send({
          data: results
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/blogMetaOptions', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT name as text, id as value FROM blog_metas WHERE type = 'category';
                SELECT name as text, id as value FROM blog_metas WHERE type = 'tag';`;
  pool.query(sql, [1, 2], (err, results) => {
    try {
      if (results) {
        res.send({
          catOptions: results[0],
          tagOptions: results[1]
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addBlog', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'title': req.body.title,
    'url': req.body.url,
    'content': req.body.content,
    'category': req.body.category,
    'tag': req.body.tag,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.coverImg = filename;
    file.mv(storage + 'blog/' + filename, function (err) {
      if (err) {
        func.logError(err);
      }
    });
  }

  let sql = `INSERT INTO blogs SET ?`;
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        res.send({
          success: true,
          message: 'Blog added successfuly'
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getBlog/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, title, url, coverImg, content, category, tag, updated_at FROM blogs WHERE id = '${req.params.id}'`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const catList = await func.blogMetaName('category', JSON.parse(results[0].category));
        const tagList = await func.blogMetaName('tag', JSON.parse(results[0].tag));
        res.send({
          data: results[0],
          catList,
          tagList
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateBlog', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'title': req.body.title,
    'url': req.body.url,
    'content': req.body.content,
    'category': req.body.category,
    'tag': req.body.tag,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.coverImg = filename;

    if (fs.existsSync(storage + 'blog/' + req.body.oldCoverImg)) {
      fs.unlinkSync(storage + 'blog/' + req.body.oldCoverImg);
    }

    file.mv(storage + 'blog/' + filename, function (err) {
      if (err) {
        func.logError(e);
      }
    });
  }

  let sql = `UPDATE blogs SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, title, url, coverImg, category, tag, content, updated_at FROM blogs WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Blog updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addComment', asyncMiddleware(async (req, res, next) => {
  let post = {
    "blogId": req.body.id,
    "c_order": req.body.order,
    "status": req.body.status,
    "commentId": req.body.commentId,
    "user": req.body.name,
    "email": req.body.email,
    "comment": req.body.comment,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO comments SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        res.send({
          success: true,
          message: 'Comment submitted for approval'
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateComment', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'user': req.body.name,
    'email': req.body.email,
    'comment': req.body.comment,
    'status': req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE comments SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT a.id, a.blogId, a.c_order, a.commentId, a.user, a.email, a.comment, a.status, a.updated_at, b.url, b.title FROM comments as a
                    left join blogs as b on b.id = a.blogId WHERE a.id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Comment updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminComments', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.blogId, a.c_order, a.commentId, a.user, a.email, a.comment, a.status, a.updated_at, b.url, b.title FROM comments as a
                left join blogs as b on b.id = a.blogId  ORDER BY a.id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminContacts', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT name, email, phone, message, created_at FROM contact_forms ORDER BY id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminBasic', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, type, name, tab1, tab2, tab3, status FROM basic ORDER BY id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addBasic', asyncMiddleware(async (req, res, next) => {
  let post = {
    "type": req.body.type,
    "tab1": req.body.tab1,
    "tab2": req.body.tab2,
    "status": req.body.status,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      file.mv(storage + 'basic/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });

      if (req.body.type == 'Survey') {
        post.name = req.body.name;
        post.tab3 = imageName;
      } else if (req.body.type == 'Jhalar') {
        post.name = imageName;
      } else {
        post.name = imageName;
        post.tab3 = req.body.tab3;
      }
    }
  } else {
    post.name = req.body.name;
    post.tab3 = req.body.tab3;
  }

  let sql = 'INSERT INTO basic SET ?';
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.getSingleBasic(results.insertId);
        res.send({
          success: true,
          data,
          message: 'Basic added successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(403);
      return;
    }
  });
}));
router.post('/updateBasic', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "type": req.body.type,
    "tab1": req.body.tab1,
    "tab2": req.body.tab2,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      file.mv(storage + 'basic/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });

      if (fs.existsSync(storage + 'basic/' + req.body.oldImage)) {
        fs.unlinkSync(storage + 'basic/' + req.body.oldImage);
      }

      if (req.body.type == 'Survey') {
        post.name = req.body.name;
        post.tab3 = imageName;
      } else if (req.body.type == 'Jhalar') {
        post.name = imageName;
      } else {
        post.name = imageName;
      }
    }
  } else {
    post.name = req.body.name;
    post.tab3 = req.body.tab3;
  }

  let sql = `UPDATE basic SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.getSingleBasic(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Basic updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeBasicStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE basic SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.getSingleBasic(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Basic updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/publisherList', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT name, id FROM basic WHERE type = 'publisher';
                SELECT name, id FROM category;
                SELECT name as text, id as value FROM basic WHERE type = 'Tags';
                SELECT name as text, id as value FROM category;
                SELECT name as text, id as value FROM basic WHERE type = 'Publisher';`;
  pool.query(sql, [1, 2, 3, 4, 5], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          data: results[0],
          categoryList: results[1],
          tagOptions: results[2],
          catOptions: results[3],
          publisherOptions: results[4]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/fetchStore', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, title, url, name, logo, category, url, display_order, status, updated_at FROM store ORDER BY id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addStore', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'name': req.body.name,
    'publisher': req.body.publisher,
    'display_order': req.body.display_order,
    'url': req.body.url,
    'tlink': req.body.tlink,
    'title': req.body.title,
    'description': req.body.description,
    'category': req.body.category,
    'tags': req.body.tags,
    'tagline': req.body.tagline,
    'salesline': req.body.salesline,
    'cashback': req.body.cashback,
    'status': 1,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.logo) {
      var file = req.files.logo;
      var logoName = Date.now() + '-' + file.name;
      post.logo = logoName;
      file.mv(storage + 'store/logo/' + logoName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }

    if (req.files.banner) {
      var file = req.files.banner;
      var bannerName = Date.now() + '-' + file.name;
      post.banner = bannerName;
      file.mv(storage + 'store/banner/' + bannerName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `INSERT INTO store SET ?`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Store created successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getStore/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, name, publisher, title, description, category, tags, logo, url, tlink, display_order, banner, tagline, salesline, cashback, updated_at FROM store WHERE id = '${req.params.id}';`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const tagData = await func.tagName(JSON.parse(results[0].tags));
        const catData = await func.catName(JSON.parse(results[0].category));
        const pubData = await func.pubName(JSON.parse(results[0].publisher));
        res.send({
          data: results[0],
          tagData: tagData,
          catData: catData,
          pubData: pubData
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateStore', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'name': req.body.name,
    'publisher': req.body.publisher,
    'url': req.body.url,
    'tlink': req.body.tlink,
    'display_order': req.body.display_order,
    'title': req.body.title,
    'description': req.body.description,
    'category': req.body.category,
    'tags': req.body.tags,
    'tagline': req.body.tagline,
    'salesline': req.body.salesline,
    'cashback': req.body.cashback,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.logo) {
      var file = req.files.logo;
      var logoName = Date.now() + '-' + file.name;
      post.logo = logoName;

      if (fs.existsSync(storage + 'store/logo/' + req.body.oldLogoName)) {
        fs.unlinkSync(storage + 'store/logo/' + req.body.oldLogoName);
      }

      file.mv(storage + 'store/logo/' + logoName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }

    if (req.files.banner) {
      var file = req.files.banner;
      var bannerName = Date.now() + '-' + file.name;
      post.banner = bannerName;

      if (fs.existsSync(storage + 'store/banner/' + req.body.oldBannerName)) {
        fs.unlinkSync(storage + 'store/banner/' + req.body.oldBannerName);
      }

      file.mv(storage + 'store/banner/' + bannerName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `UPDATE store SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Store updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeStoreStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE store SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, title, name, logo, display_order, status, updated_at FROM store WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'store updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/fetchCategory', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, type, category, title, url, name, icon, display_order, banner, status, updated_at FROM category ORDER BY id DESC`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addCategory', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "type": req.body.type,
    "url": req.body.url,
    "name": req.body.name,
    "title": req.body.title,
    "display_order": req.body.display_order,
    "status": 1,
    "created_at": time,
    "updated_at": time
  };

  if (req.body.type == 'SubCategory') {
    post.category = req.body.category;
  }

  if (req.files) {
    if (req.files.icon) {
      var file = req.files.icon;
      var iconName = Date.now() + '-' + file.name;
      post.icon = iconName;
      file.mv(storage + 'category/icon/' + iconName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }

    if (req.files.banner) {
      var file = req.files.banner;
      var bannerName = Date.now() + '-' + file.name;
      post.banner = bannerName;
      file.mv(storage + 'category/banner/' + bannerName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `INSERT INTO category SET ?`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminCategory(results.insertId);
        res.send({
          success: true,
          data,
          message: 'Category added successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateCategory', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "type": req.body.type,
    "url": req.body.url,
    "name": req.body.name,
    "title": req.body.title,
    "status": req.body.status,
    "display_order": req.body.display_order,
    "updated_at": time
  };

  if (req.body.type == 'SubCategory') {
    post.category = req.body.category;
  }

  if (req.files) {
    if (req.files.icon) {
      var file = req.files.icon;
      var iconName = Date.now() + '-' + file.name;
      post.icon = iconName;

      if (fs.existsSync(storage + 'category/icon/' + req.body.oldIconName)) {
        fs.unlinkSync(storage + 'category/icon/' + req.body.oldIconName);
      }

      file.mv(storage + 'category/icon/' + iconName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }

    if (req.files.banner) {
      var file = req.files.banner;
      var bannerName = Date.now() + '-' + file.name;
      post.banner = bannerName;

      if (fs.existsSync(storage + 'category/banner/' + req.body.oldBannerName)) {
        fs.unlinkSync(storage + 'category/banner/' + req.body.oldBannerName);
      }

      file.mv(storage + 'category/banner/' + bannerName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `UPDATE category SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminCategory(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Category updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeCategoryStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE category SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, title, name, icon, display_order, banner, status, updated_at FROM category WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Category updated successfuly'
              });
            } else if (err2) {
              throw err2;
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/couponData', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  const stPub = await func.stPub();
  let sql = `SELECT a.id, a.store, a.title, a.category, a.tags, a.url, a.tlink, a.publisher, a.commission, a.image, a.offer, a.cashback, a.status, a.start, a.expiry, a.coupon_type, a.updated_at, b.name as storeName FROM coupon as a LEFT join store as b on b.id = a.store ORDER BY id DESC ;
                SELECT id, name FROM basic WHERE type='CouponType' ORDER BY id DESC;
                SELECT id, name FROM category ORDER BY id DESC;
                SELECT name as text, id as value FROM basic WHERE type = 'Tags';`;
  pool.query(sql, [1, 2], (err, results) => {
    try {
      if (results) {
        res.send({
          data: results[0],
          couponType: results[1],
          categoryList: results[2],
          tagOptions: results[3],
          store: stPub[0],
          publisher: stPub[1]
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addCoupon', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'type': 'coupon',
    'store': req.body.store,
    'category': req.body.category,
    'tags': req.body.tags,
    'title': req.body.title,
    'url': req.body.url,
    'tlink': req.body.tlink,
    'publisher': req.body.publisher,
    'commission': req.body.commission,
    'offer': req.body.offer,
    'cashback': req.body.cashback,
    'status': req.body.status,
    'start': req.body.start,
    'expiry': req.body.expiry,
    'coupon_type': req.body.coupon_type,
    'tnc': req.body.tnc,
    'discription': req.body.discription,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      post.image = imageName;
      file.mv(storage + 'store/coupon/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `INSERT INTO coupon SET ?`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminCoupon(results.insertId);
        res.send({
          success: true,
          data,
          message: 'Coupon added successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeCouponStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE coupon SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminCoupon(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Coupon updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getCoupon/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, store, title, category, tags, url, tlink, publisher, commission, image, offer, cashback, status, start, expiry, coupon_type, tnc, discription, updated_at FROM coupon WHERE id=${req.params.id};
                SELECT id, name FROM store ORDER BY id DESC;
                SELECT id, name FROM category ORDER BY id DESC;
                SELECT name, id FROM basic WHERE type = 'Publisher';
                SELECT name as text, id as value FROM basic WHERE type = 'Tags';`;
  pool.query(sql, [1, 2, 3, 4, 5], async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const tagData = await func.tagName(JSON.parse(results[0][0].tags));
        res.send({
          data: results[0][0],
          store: results[1],
          categoryList: results[2],
          publisherList: results[3],
          tagOptions: results[4],
          tagData: tagData
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateCoupon', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'store': req.body.store,
    'category': req.body.category,
    'tags': req.body.tags,
    'title': req.body.title,
    'url': req.body.url,
    'tlink': req.body.tlink,
    'publisher': req.body.publisher,
    'commission': req.body.commission,
    'offer': req.body.offer,
    'cashback': req.body.cashback,
    'status': req.body.status,
    'start': req.body.start,
    'expiry': req.body.expiry,
    'coupon_type': req.body.coupon_type,
    'tnc': req.body.tnc,
    'discription': req.body.discription,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      post.image = imageName;

      if (fs.existsSync(storage + 'store/coupon/' + req.body.oldImageName)) {
        fs.unlinkSync(storage + 'store/coupon/' + req.body.oldImageName);
      }

      file.mv(storage + 'store/coupon/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `UPDATE coupon SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminCoupon(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Coupon updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/dealData', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.store, a.title, a.status, a.start, a.expiry, b.name as storeName FROM deal as a left join store as b on b.id = a.store ORDER BY id DESC;
                SELECT id, name FROM store ORDER BY id DESC;
                SELECT id, name FROM category ORDER BY id DESC;
                SELECT name, id FROM basic WHERE type = 'Publisher';
                SELECT name as text, id as value FROM basic WHERE type = 'Tags';`; // SELECT a.id, a.store, a.url, a.tlink, a.category, a.title, a.deal_type, a.percent, a.tags, a.tagline, a.cutoff, a.current_value, a.offer_count, a.status, a.start, a.expiry, a.updated_at, b.name as storeName FROM deal as a left join store as b on b.id = a.store ORDER BY id DESC;

  pool.query(sql, [1, 2, 3, 4, 5], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0],
          store: results[1],
          categoryList: results[2],
          publisherList: results[3],
          tagOptions: results[4]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getDeal/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, store, url, tlink, category, title, deal_type, percent, tags, offday, tagline, cutoff, current_value, offer_count, status, publisher, tnc, discription, start, expiry, updated_at, offday FROM deal WHERE id=${req.params.id};
                SELECT id, name FROM store ORDER BY id DESC;
                SELECT id, name FROM category ORDER BY id DESC;
                SELECT name, id FROM basic WHERE type = 'Publisher';
                SELECT name as text, id as value FROM basic WHERE type = 'Tags';`;
  pool.query(sql, [1, 2, 3, 4, 5], async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const tagData = await func.tagName(JSON.parse(results[0][0].tags));
        res.send({
          data: results[0][0],
          store: results[1],
          categoryList: results[2],
          publisherList: results[3],
          tagOptions: results[4],
          tagData: tagData
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addDeal', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'type': 'deal',
    'store': req.body.store,
    'url': req.body.url,
    'tlink': req.body.tlink,
    'category': req.body.category,
    'publisher': req.body.publisher,
    'title': req.body.title,
    'deal_type': req.body.deal_type,
    'percent': req.body.percent,
    'tags': req.body.tags,
    'tagline': req.body.tagline,
    'cutoff': req.body.cutoff,
    'current_value': req.body.current_value,
    'offer_count': req.body.offer_count,
    'status': req.body.status,
    'tnc': req.body.tnc,
    'discription': req.body.discription,
    'start': req.body.start,
    'expiry': req.body.expiry,
    'offday': req.body.offday,
    "created_at": time,
    "updated_at": time
  }; // if(req.files){
  //     if(req.files.image){
  //         var file = req.files.image
  //         var imageName = Date.now() + '-' + file.name;
  //         post.image = imageName
  //         file.mv(storage+'store/deal/'+imageName, function(err){ if(err){ func.logError(err) } })
  //     }
  // }

  let sql = `INSERT INTO deal SET ?`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminDeal(results.insertId);
        res.send({
          success: true,
          data,
          message: 'Deal added successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeDealStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE deal SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminDeal(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Deal updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateDeal', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'store': req.body.store,
    'url': req.body.url,
    'tlink': req.body.tlink,
    'category': req.body.category,
    'publisher': req.body.publisher,
    'title': req.body.title,
    'deal_type': req.body.deal_type,
    'percent': req.body.percent,
    'tags': req.body.tags,
    'tagline': req.body.tagline,
    'cutoff': req.body.cutoff,
    'current_value': req.body.current_value,
    'offer_count': req.body.offer_count,
    'status': req.body.status,
    'tnc': req.body.tnc,
    'discription': req.body.discription,
    'start': req.body.start,
    'expiry': req.body.expiry,
    'offday': req.body.offday,
    "updated_at": time
  }; // if(req.files){
  //     if(req.files.image){
  //         var file = req.files.image
  //         var imageName = Date.now() + '-' + file.name;
  //         post.image = imageName
  //         if (fs.existsSync(storage+'store/deal/'+req.body.oldImageName)) { fs.unlinkSync(storage+'store/deal/'+req.body.oldImageName) }
  //         file.mv(storage+'store/deal/'+imageName, function(err){ if(err){ func.logError(err) } })
  //     }
  // }

  let sql = `UPDATE deal SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.adminDeal(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Deal updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminLeaderBoard', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  const stPub = await func.stPub(); // const users = await func.userOptions();

  let sql = `SELECT a.id, a.userId, a.cashback, a.reward, a.redeemed, a.total, a.updated_at, b.name, b.email, b.phone FROM leaderboard as a
                    left join users as b on b.id = a.userId;`;
  pool.query(sql, (err, results) => {
    try {
      if (results) {
        res.send({
          data: results,
          store: stPub[0],
          publisher: stPub[1]
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addCashback', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'publisher': req.body.publisher,
    'date': req.body.date,
    'store': req.body.store,
    'amount': req.body.amount,
    'rewardPayout': req.body.rewardPayout,
    'description': req.body.description,
    'customerPayout': req.body.customerPayout,
    'status': req.body.status,
    "created_at": time,
    "updated_at": time
  };
  let sql = `INSERT INTO cashback SET ?`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (results) {
        if (req.body.status = "Approved") {
          var data = await func.updateLeaderBoard(req.body.userId, req.body.points, 'cashback');
        }

        res.send({
          success: true,
          data: data,
          message: 'Cashback updated successfuly'
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addReward', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'points': req.body.points,
    'description': req.body.description,
    "created_at": time,
    "updated_at": time
  };
  let sql = `INSERT INTO reward SET ?`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (results) {
        const data = await func.updateLeaderBoard(req.body.userId, req.body.points, 'reward');
        res.send({
          success: true,
          data: data,
          message: 'Reward updated successfuly'
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/redeemPoints', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'points': req.body.points,
    'description': req.body.description,
    "created_at": time,
    "updated_at": time
  };
  let sql = `INSERT INTO redeem SET ?`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (results) {
        const data = await func.updateLeaderBoard(req.body.userId, req.body.points, 'redeem');
        res.send({
          success: true,
          data: data,
          message: 'Reward updated successfuly'
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminCashbackData', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  const data = await func.userOptions();
  const stPub = await func.stPub();
  let sql = `SELECT a.id, a.userId, a.publisher, a.date, a.store, a.amount, a.rewardPayout, a.customerPayout, a.description, a.updated_at, a.status, b.name, b.email, b.phone, c.name as store, d.name as publisher FROM cashback as a 
    left join users as b on b.id = a.userId 
    left join store as c on c.id = a.store
    left join basic as d on d.id = a.publisher;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results,
          userOptions: data,
          store: stPub[0],
          publisher: stPub[1]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/approveCashback', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'status': "Approved",
    "updated_at": time
  };
  let sql = `UPDATE cashback SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        await func.updateLeaderBoard(req.body.userId, req.body.customerPayout, 'cashback');
        const data = await func.getCashbackUser(req.body.id);
        res.send({
          success: true,
          data,
          message: 'Cashback updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/footerData', asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, name, url FROM store WHERE status= 1 ORDER BY display_order ASC Limit 8;
                SELECT id, title, url FROM coupon WHERE status= 1 ORDER BY expiry DESC;
                SELECT id, title, url FROM deal WHERE status= 1 ORDER BY expiry DESC;
                SELECT id, title, url FROM blogs Limit 8;`;
  pool.query(sql, [1, 2, 3, 4], (err, results) => {
    try {
      if (results) {
        res.send({
          store: results[0],
          coupon: results[1],
          deal: results[2],
          blog: results[3]
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminAds', asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, type, image, url, status, target, updated_at FROM ads ORDER BY id DESC;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addAds', asyncMiddleware(async (req, res, next) => {
  let post = {
    "type": req.body.type,
    "url": req.body.url,
    "status": req.body.status,
    "target": req.body.target,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      post.image = imageName;
      file.mv(storage + 'ads/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = 'INSERT INTO ads SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, type, image, url, target, status, updated_at FROM ads ORDER BY id DESC LIMIT 1`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) throw err;
            res.send({
              success: true,
              data: results2[0],
              message: 'Advertisement added successfuly'
            });
          } catch (e) {
            func.logError(e);
            res.status(403);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateAds', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "type": req.body.type,
    "url": req.body.url,
    "status": req.body.status,
    "target": req.body.target,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      post.image = imageName;

      if (fs.existsSync(storage + 'ads/' + req.body.oldImage)) {
        fs.unlinkSync(storage + 'ads/' + req.body.oldImage);
      }

      file.mv(storage + 'ads/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `UPDATE ads SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, type, image, url, target, status, updated_at FROM ads WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Advertisement updated successfuly'
              });
            } else if (err2) {
              throw err2;
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeAdStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE ads SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, type, image, url, target, status, updated_at FROM ads WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Advertisement updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getSpecial', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, image, url, status, tag, updated_at FROM special ORDER BY id DESC;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addSpecial', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res, next) => {
  let post = {
    "url": req.body.url,
    "status": req.body.status,
    "tag": req.body.tag,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      post.image = imageName;
      file.mv(storage + 'special/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = 'INSERT INTO special SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, image, url, status, tag, updated_at FROM special ORDER BY id DESC LIMIT 1`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) throw err;
            res.send({
              success: true,
              data: results2[0],
              message: 'Special added successfuly'
            });
          } catch (e) {
            func.logError(e);
            res.status(403);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateSpecial', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "url": req.body.url,
    "status": req.body.status,
    "tag": req.body.tag,
    "updated_at": time
  };

  if (req.files) {
    if (req.files.image) {
      var file = req.files.image;
      var imageName = Date.now() + '-' + file.name;
      post.image = imageName;

      if (fs.existsSync(storage + 'special/' + req.body.oldImage)) {
        fs.unlinkSync(storage + 'special/' + req.body.oldImage);
      }

      file.mv(storage + 'special/' + imageName, function (err) {
        if (err) {
          func.logError(err);
        }
      });
    }
  }

  let sql = `UPDATE special SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, image, url, status, tag, updated_at FROM special WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Special updated successfuly'
              });
            } else if (err2) {
              throw err2;
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeSpecialStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE special SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, image, url, status, tag, updated_at FROM special WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Special updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
})); // router.get('/adminQuestionBank', asyncMiddleware( async(req, res) => {
//     let sql =   `SELECT id, title, type, mandatory, options, answer, status, updated_at FROM question ORDER BY id DESC;`
//     pool.query(sql, (err, results) => {
//         try{
//             if(err){ throw err }
//             if(results){ res.send({ data: results }); }
//         }catch(e){ func.logError(e); res.status(500); return; }
//     })
// }))

router.post('/addQuestion', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res, next) => {
  let post = {
    "title": req.body.title,
    "type": req.body.type,
    "options": req.body.options,
    "mandatory": req.body.mandatory,
    "status": req.body.status,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO question SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, title, type, mandatory, options, status, updated_at FROM question ORDER BY id DESC LIMIT 1`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) throw err;
            res.send({
              success: true,
              data: results2[0],
              message: 'Question added successfuly'
            });
          } catch (e) {
            func.logError(e);
            res.status(403);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeQuestionStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE question SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, title, type, mandatory, options, status, updated_at FROM question WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Special updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateQuestion', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "title": req.body.title,
    "type": req.body.type,
    "options": req.body.options,
    "mandatory": req.body.mandatory,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE question SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, title, type, mandatory, options, status, updated_at FROM question WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Question updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminQuestionBank', asyncMiddleware(async (req, res) => {
  const data = await func.adminQuestionBank();
  const category = await func.surveyCategory();
  res.send({
    data: data.results,
    category: category.results
  });
}));
router.get('/adminSurvey', asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.title, a.status, a.reward, a.updated_at, b.name FROM survey as a left join basic as b on b.id = a.category ORDER BY a.id DESC;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addSurvey', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res, next) => {
  let post = {
    "category": req.body.category,
    "title": req.body.title,
    "status": req.body.status,
    "reward": req.body.reward,
    "questions": req.body.questions,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO survey SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeSurveyStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE survey SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, title, category, status, reward, updated_at FROM survey WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Category updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/getSurvey/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  const data = await func.adminQuestionBank();
  const category = await func.surveyCategory();
  let sql = `SELECT id, category, title, questions, status, reward, updated_at FROM survey WHERE id = '${req.params.id}'`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          questions: results[0],
          data,
          category
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateSurvey', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "category": req.body.category,
    "title": req.body.title,
    "status": req.body.status,
    "reward": req.body.reward,
    "questions": req.body.questions,
    "updated_at": time
  };
  let sql = `UPDATE survey SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/surveyQuestionnaire/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, title, questions, status, reward, updated_at FROM survey WHERE id = '${req.params.id}'`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.userQuestionBank(JSON.parse(results[0].questions));
        res.send({
          questions: results[0],
          data
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/surveyCategoryData/:id', asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.title, a.category, a.reward, a.updated_at, b.name FROM survey as a left join basic as b on b.id = a.category WHERE a.category = ${req.params.id} AND a.status = 1 ORDER BY a.id DESC;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/takeSurvey/:id', asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.title, a.category, a.reward, a.questions, a.updated_at, b.name FROM survey as a left join basic as b on b.id = a.category WHERE a.id = ${req.params.id} AND a.status = 1;`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results && results[0]) {
        const questions = await func.getSurveyQuestion(JSON.parse(results[0].questions));
        res.send({
          data: results[0],
          questions: questions.results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/submitSurvey', [func.verifyToken], asyncMiddleware(async (req, res) => {
  let post = {
    "surveyId": req.body.surveyId,
    "userId": req.body.userId,
    "answers": req.body.answers,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO surveyresponse SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Survey submitted successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/surveyResponse', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.surveyId, a.userId, a.answers, a.updated_at, b.name, b.email, b.phone, c.title, c.reward FROM surveyresponse as a 
    left join users as b on b.id = a.userId left join survey as c on c.id = a.id;`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/checkSurveyData/:id', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  // let sql = `SELECT id, title, questions, status, reward, updated_at FROM survey WHERE id = '${req.params.id}'`
  let sql = `SELECT a.id, a.surveyId, a.userId, a.answers, a.updated_at, b.name, b.email, b.phone, c.title, c.reward, c.questions FROM surveyresponse as a 
    left join users as b on b.id = a.userId left join survey as c on c.id = a.surveyId WHERE a.id = '${req.params.id}';`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        const data = await func.userQuestionBank(JSON.parse(results[0].questions));
        res.send({
          questions: results[0],
          data
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/userSurveyList/:id', [func.verifyToken], asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.surveyId, a.updated_at, b.title, b.reward FROM surveyresponse as a left join survey as b on b.id = a.surveyId WHERE a.userId = '${req.params.id}'`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/userCashback/:id', [func.verifyToken], asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.publisher, a.date, a.store, a.customerPayout as payout, a.updated_at, b.name as store, b.url FROM cashback as a left join store as b on b.id = a.store WHERE a.userId = '${req.params.id}'`;
  pool.query(sql, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminCareer', asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, role, location, qualification, experience, description, status, updated_at FROM career ORDER BY id DESC;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/addCareer', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res, next) => {
  let post = {
    "role": req.body.role,
    "location": req.body.location,
    "qualification": req.body.qualification,
    "experience": req.body.experience,
    "description": req.body.description,
    "status": req.body.status,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO career SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        let sql = `SELECT id, role, location, qualification, experience, description, status, updated_at FROM career ORDER BY id DESC LIMIT 1`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) throw err;
            res.send({
              success: true,
              data: results2[0],
              message: 'Job Listed successfuly'
            });
          } catch (e) {
            func.logError(e);
            res.status(403);
            return;
          }
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/changeCareerStatus', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "id": req.body.id,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE career SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, role, location, qualification, experience, description, status, updated_at FROM career WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Job updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateCareer', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    "role": req.body.role,
    "location": req.body.location,
    "qualification": req.body.qualification,
    "experience": req.body.experience,
    "description": req.body.description,
    "status": req.body.status,
    "updated_at": time
  };
  let sql = `UPDATE career SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        let sql = `SELECT id, role, location, qualification, experience, description, status, updated_at FROM career WHERE id = ${req.body.id}`;
        pool.query(sql, (err2, results2) => {
          try {
            if (err2) {
              throw err2;
            }

            if (results2) {
              res.send({
                success: true,
                data: results2[0],
                message: 'Job updated successfuly'
              });
            }
          } catch (e) {
            func.logError(e);
            res.status(500);
            return;
          }
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/applyForJob', [func.verifyToken, func.verifyUser], asyncMiddleware(async (req, res) => {
  let post = {
    'careerId': req.body.careerId,
    'name': req.body.name,
    'email': req.body.email,
    'phone': req.body.phone,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.resume = filename;
    file.mv(storage + 'career/' + filename, function (err) {
      if (err) {
        func.logError(err);
      }
    });
  }

  let sql = `INSERT INTO jobapplication SET ?`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Job Applied successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/jobApplications', asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.careerId, a.name, a.email, a.phone, a.resume, a.updated_at, b.role, b.location FROM jobapplication as a
                left join career as b on b.id = a.careerId ORDER BY id DESC;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/contactForm', (req, res, next) => {
  let post = {
    "name": req.body.name,
    "email": req.body.email,
    "phone": req.body.phone,
    "message": req.body.message,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO contact_forms SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (err) throw err; // const mailBody =`
      //   <h2><strong>Dear ${req.body.name}</strong></h2>
      //   <p>Thanks for connecting with us.</p>
      //   <p>The details provided by you are:</p>
      //   <ul>
      //     <li>Email: ${req.body.email}</li>
      //     <li>Phone: ${req.body.phone}</li>
      //     <li>Message: ${req.body.message}</li>
      //   </ul>
      //   <p>We will reach back to you on priority. If anything urgent, you can call me on </p><br/>
      //   <p>Warm Regards</p>
      //   `
      // let mailOptions = { to: req.body.email, from: 'navneet.khare@casleyconsulting.co.jp', subject: "Form filled on website ✔ www.rewardeagle.com", html: mailBody }
      // transporter.sendMail( mailOptions, (error, info)=>{
      //   if(error){ func.printError(err) }
      //   func.printError("Message sent: %s")
      // });

      res.send({
        success: true,
        message: "Thank you for connecting with us"
      });
    } catch (e) {
      func.logError(e);
      res.status(403);
      return;
    }
  });
});
router.get('/checkProfile/:id', asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, userId, image, user, address, scim,	bank, google, paytm,phonepe  FROM userprofile WHERE userId =${req.params.id};`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/createProfile', [func.verifyToken, func.verifyUser], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'user': req.body.user,
    'address': req.body.address,
    'scim': req.body.scim,
    'bank': req.body.bank,
    'google': req.body.google,
    'paytm': req.body.paytm,
    'phonepe': req.body.phonepe,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.image = filename;
    file.mv(storage + 'profile/' + filename, function (err) {
      if (err) {
        func.logError(err);
      }
    });
  }

  let sql = `INSERT INTO userprofile SET ?`;
  pool.query(sql, post, (err, results) => {
    try {
      if (results) {
        res.send({
          success: true,
          message: 'Profile created successfuly'
        });
      } else if (err) {
        throw err;
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updateProfile', [func.verifyToken, func.verifyUser], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'user': req.body.user,
    'address': req.body.address,
    'scim': req.body.scim,
    'bank': req.body.bank,
    'google': req.body.google,
    'paytm': req.body.paytm,
    'phonepe': req.body.phonepe,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.image = filename;

    if (fs.existsSync(storage + 'profile/' + req.body.oldImage)) {
      fs.unlinkSync(storage + 'profile/' + req.body.oldImage);
    }

    file.mv(storage + 'profile/' + filename, function (err) {
      if (err) {
        func.logError(err);
      }
    });
  }

  let sql = `UPDATE userprofile SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Profile updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/userAppliedJobs/:id', asyncMiddleware(async (req, res) => {
  let sql = `SELECT a.id, a.careerId, a.resume, a.updated_at, b.role, b.location, b.qualification, b.experience, b.description, b.status FROM jobapplication as a left join career as b on b.id = a.careerId WHERE a.userId =${req.params.id};
                SELECT * FROM career WHERE status =1;`;
  pool.query(sql, [1, 2], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0],
          jobs: results[1]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/userAccounts/:id', asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, userId, cashback, reward, redeemed, total FROM leaderboard WHERE userId =${req.params.id};
                SELECT id, customerPayout FROM cashback WHERE status = "Pending";
                SELECT id, bank FROM userprofile WHERE userId =${req.params.id};`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0][0],
          pending: results[1],
          profile: results[2]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/redeemRequest', [func.verifyToken, func.verifyUser], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'redeem': req.body.redeem,
    'status': 0,
    "created_at": time,
    "updated_at": time
  };
  let sql = `INSERT INTO transfercashback SET ?`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Transfer requested successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/userCashbackHistory/:id', asyncMiddleware(async (req, res) => {
  console.log(`req.params.id`, req.params.id);
  let sql = `SELECT a.id, a.userId, a.status,  a.date, a.store, a.customerPayout, a.updated_at, b.name, b.url FROM cashback as a left join store as b on b.id = a.store WHERE a.userId =${req.params.id} ORDER BY a.id DESC;
    Select * from transfercashback Where userId = ${req.params.id};`; // let sql =   `Select * from transfercashback Where userId = ${req.params.id};`

  console.log(`sql`, sql);
  pool.query(sql, [1, 2], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          cashback: results[0],
          transferRequest: results[1]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/convertRewardToCash', [func.verifyToken, func.verifyUser], asyncMiddleware(async (req, res) => {
  let sql = `SELECT id, userId, cashback, reward, redeemed, total FROM leaderboard WHERE userId =${req.body.userId};`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results && results[0]) {
        if (results[0].reward < req.body.points) {
          res.send({
            success: false,
            message: 'Something went wrong'
          });
        } else {
          const reward = parseInt(results[0].reward) - parseInt(req.body.points);
          const cashback = parseInt(results[0].cashback) + parseInt(req.body.points) * 200;
          let post = {
            'reward': reward,
            'cashback': cashback,
            "updated_at": time
          };
          let sql2 = `UPDATE leaderboard SET ? WHERE userId = ${req.body.userId}`;
          pool.query(sql2, post, (err2, results2) => {
            try {
              if (err2) {
                throw err2;
              }

              if (results2) {
                res.send({
                  success: true,
                  message: 'Reward Points converted succesfully'
                });
              }
            } catch (e) {
              func.logError(e);
              res.status(500);
              return;
            }
          });
        }
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/checkStoreUrl/:url', asyncMiddleware(async (req, res, next) => {
  let sql = `SELECT id, type, name, url FROM category WHERE url ='${req.params.url}';
                SELECT id, name, category, logo, url, tlink, cashback, title, tagline as offer FROM store WHERE url= '${req.params.url}';`;
  pool.query(sql, [1, 2], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0],
          storeData: results[1]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminSummary', asyncMiddleware(async (req, res, next) => {
  let sql = `SELECT count(id) as count FROM users WHERE role='User';
                SELECT id, name FROM basic WHERE type='Publisher'; 
                SELECT id, publisher FROM store WHERE status=1;
                SELECT id, publisher FROM coupon WHERE status=1;
                SELECT id, publisher FROM deal WHERE status=1;
                SELECT a.id, a.surveyId, b.category, c.name FROM surveyresponse as a left join survey as b on b.id = a.surveyId left join basic as c on c.id = b.category;
                SELECT id, name FROM basic WHERE type='Survey';  
                SELECT count(id) as count FROM blogs;
                SELECT a.id, a.careerId, b.role FROM jobapplication as a left join career as b on b.id = a.careerId;
                SELECT id, role FROM career WHERE status =1;  
                SELECT count(id) as count FROM subscribe;  
                `;
  pool.query(sql, [1, 2, 3, 4, 5, 6, 7], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/subscribe', asyncMiddleware(async (req, res) => {
  let post = {
    "email": req.body.email,
    "created_at": time,
    "updated_at": time
  };
  let sql = 'INSERT INTO subscribe SET ?';
  pool.query(sql, post, (err, results) => {
    try {
      if (err && err.code == 'ER_DUP_ENTRY') {
        res.send({
          success: true,
          message: 'You are already subscribed with us'
        });
      }

      if (results) {
        const mailBody = `
                    <h2>Hi</h2>
                    <p>Thank you for subscribing us.</p>
                    <p>We are happy toffer you the best deals and coupons available.</p><br/>

                    <p>Warm Regards</p>
                    <p>Team Reward Eagle</p>
                `;
        let mailOptions = {
          to: req.body.email,
          from: '<noreply@rewardeagle.com>',
          subject: "Thanks for subscribing ✔ www.rewardeagle.com",
          html: mailBody
        };
        transporter.sendMail(mailOptions, (error, info) => {
          res.send({
            success: true,
            message: 'Thank you for subscribing us'
          });
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/adminCreateProfile', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'user': req.body.user,
    'address': req.body.address,
    'scim': req.body.scim,
    'bank': req.body.bank,
    'google': req.body.google,
    'paytm': req.body.paytm,
    'phonepe': req.body.phonepe,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.image = filename;
    file.mv(storage + 'profile/' + filename, function (err) {
      if (err) {
        func.logError(err);
      }
    });
  }

  let sql = `INSERT INTO userprofile SET ?`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Profile created successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/adminUpdateProfile', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let post = {
    'userId': req.body.userId,
    'user': req.body.user,
    'address': req.body.address,
    'scim': req.body.scim,
    'bank': req.body.bank,
    'google': req.body.google,
    'paytm': req.body.paytm,
    'phonepe': req.body.phonepe,
    "created_at": time,
    "updated_at": time
  };

  if (req.files) {
    var file = req.files.file;
    var filename = Date.now() + '-' + file.name;
    post.image = filename;

    if (fs.existsSync(storage + 'profile/' + req.body.oldImage)) {
      fs.unlinkSync(storage + 'profile/' + req.body.oldImage);
    }

    file.mv(storage + 'profile/' + filename, function (err) {
      if (err) {
        func.logError(err);
      }
    });
  }

  let sql = `UPDATE userprofile SET ? WHERE userId = ${req.body.userId}`;
  pool.query(sql, post, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true,
          message: 'Profile updated successfuly'
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/userData/:userId', asyncMiddleware(async (req, res, next) => {
  let sql = `SELECT image FROM userprofile WHERE userId=${req.params.userId};`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results[0]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/adminSubscription', asyncMiddleware(async (req, res, next) => {
  let sql = `SELECT email, updated_at FROM subscribe;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/getUserOptions', asyncMiddleware(async (req, res, next) => {
  let sql = `SELECT id, name, email, role, phone, referralcode, created_at FROM users WHERE email LIKE '%${req.body.email}%';`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/cashOutRequest', asyncMiddleware(async (req, res, next) => {
  let sql = `SELECT a.id, a.userId, a.redeem, a.remarks, a.status, a.merchantrefid, a.payuresponse, a.updated_at, b.name, b.email, b.phone, c.cashback, c.reward, c.total, d.bank
    FROM transfercashback as a left join users as b on b.id = a.userId
    left join leaderboard as c on c.userId = a.userId
    left join userprofile as d on d.userId = a.userId;`;
  pool.query(sql, (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          data: results
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.get('/sitemapData', [func.verifyToken, func.verifyAdmin], asyncMiddleware(async (req, res) => {
  let sql = `SELECT url  FROM blogs;
                SELECT type, url FROM blog_metas;
                SELECT url FROM store;
                SELECT url FROM category;
                SELECT tab1 as url FROM basic WHERE type='Tags';`;
  pool.query(sql, [1, 2, 3, 4, 5], (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          blogs: results[0],
          blogMeta: results[1],
          stores: results[2],
          category: results[3],
          tags: results[4]
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/payuresponse', asyncMiddleware(async (req, res) => {
  let post = {
    'payuresponse': JSON.stringify([req.body])
  };

  if (req.body.event == "TRANSFER_SUCCESS") {
    post.status = 1;
  } else {
    post.status = 0;
  }

  let sql = `UPDATE transfercashback SET ? WHERE merchantrefid = ${req.body.merchantReferenceId}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        res.send({
          success: true
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
}));
router.post('/updatePaymentStatus', asyncMiddleware(async (req, res, next) => {
  let post = {
    'merchantrefid': req.body.merchantrefid,
    'status': 1
  };
  let sql = `UPDATE transfercashback SET ? WHERE id = ${req.body.id}`;
  pool.query(sql, post, async (err, results) => {
    try {
      if (err) {
        throw err;
      }

      if (results) {
        await func.cashbackDone(req.body.userId, req.body.points);
        const data = await func.getcashbackedData(req.body.id);
        res.send({
          success: true,
          data
        });
      }
    } catch (e) {
      func.logError(e);
      res.status(500);
      return;
    }
  });
})); // router.post('/updatePaymentStatus', asyncMiddleware( async(req, res, next) => {
//     for (let i = 0; i < req.body.id.length; i++) {
//         let post= {
//             'merchantrefid':                   req.body.merchantrefid,
//             'status':                           1
//         }
//         let sql = `UPDATE transfercashback SET ? WHERE id = ${req.body.id[i].id}`;
//         pool.query(sql, post, async(err, results) => {
//             try{
//                 if(err){ throw err }
//                 if(results){
//                     await func.cashbackDone(req.body.id[i].userId, req.body.id[i].points);
//                     if(i== req.body.id.length-1){ 
//                         const data = await func.getcashbackedData(req.body.ids);
//                         res.send({ success: true, data }); 
//                     }
//                 }
//             }catch(e){ func.logError(e); res.status(500); return; }
//         })
//     }
// }))
// router.get('/walletx', asyncMiddleware( async(req, res, next) => {
//     let sql =   `SELECT * FROM walletx;
//                 SELECT DISTINCT userId FROM walletx;`
//     pool.query(sql, (err, results) => {
//         try{
//             if(err){ throw err }
//             if(results){ res.send({ data: results[0], id: results[1] }); }
//         }catch(e){ func.logError(e); res.status(500); return; }
//     })
// }))

module.exports = router;