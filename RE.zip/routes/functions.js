"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.printError = printError;
exports.getBlogCategory = getBlogCategory;
exports.pendingMeta = pendingMeta;
exports.getSingleMeta = getSingleMeta;
exports.specialList = specialList;
exports.adHomeList = adHomeList;
exports.adList = adList;
exports.storeData = storeData;
exports.adminQuestionBank = adminQuestionBank;
exports.surveyCategory = surveyCategory;
exports.getSurveyQuestion = getSurveyQuestion;
exports.userQuestionBank = userQuestionBank;
exports.surveyData = surveyData;
exports.getUser = getUser;
exports.allStoreData = allStoreData;
exports.storeSidebar = storeSidebar;
exports.homeData = homeData;
exports.shopData = shopData;
exports.headerData = headerData;
exports.categoryData = categoryData;
exports.updateLeaderBoard = updateLeaderBoard;
exports.cashbackDone = cashbackDone;
exports.getcashbackedData = getcashbackedData;
exports.getSingleBasic = getSingleBasic;
exports.getLeaderBoard = getLeaderBoard;
exports.getCashbackUser = getCashbackUser;
exports.stPub = stPub;
exports.userOptions = userOptions;
exports.getMeta = getMeta;
exports.tagName = tagName;
exports.catName = catName;
exports.pubName = pubName;
exports.blogMetaName = blogMetaName;
exports.blogMetaData = blogMetaData;
exports.suggestBlogs = suggestBlogs;
exports.verifyToken = verifyToken;
exports.verifyAdmin = verifyAdmin;
exports.verifyUser = verifyUser;
exports.adminCategory = adminCategory;
exports.adminCoupon = adminCoupon;
exports.adminDeal = adminDeal;
exports.logError = logError;

var _jsonwebtoken = require("jsonwebtoken");

var mysql = require('mysql');

const jwt = require('jsonwebtoken');

var pool = require('./mysqlConnector');

const time = new Date().toISOString().slice(0, 19).replace('T', ' ');
const today = new Date().toISOString().slice(0, 10);
const recomStore = 22;

const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtpout.secureserver.net",
  port: 465,
  secure: true,
  auth: {
    user: 'noreply@rewardeagle.com',
    pass: 'CasleyRe2021ILU',
    debug: true
  },
  tls: {
    rejectUnauthorized: false,
    secureProtocol: "TLSv1_method"
  }
});

function printError(mesg) {
  console.log('mesg', mesg);
}

function getBlogCategory() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT url, name FROM blog_metas WHERE type='category';`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function pendingMeta() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT CONCAT('/blog/', a.url) as url from blogs as a left join metas as b on b.url = CONCAT('/blog/', a.url) WHERE b.url IS NULL;
        SELECT CONCAT('/category/', a.url) as url from blog_metas as a left join metas as b on b.url = CONCAT('/category/', a.url) WHERE b.url IS NULL AND a.type='category';
        SELECT CONCAT('/tag/', a.url) as url from blog_metas as a left join metas as b on b.url = CONCAT('/tag/', a.url) WHERE b.url IS NULL AND a.type='tag';
        SELECT CONCAT('/stores/', a.url) as url from store as a left join metas as b on b.url = CONCAT('/stores/', a.url) WHERE b.url IS NULL;
        SELECT CONCAT('/storeCategory/', a.url) as url from category as a left join metas as b on b.url = CONCAT('/storeCategory/', a.url) WHERE b.url IS NULL AND a.type='Category';`;
    pool.query(sql, [1, 2, 3, 4, 5], (err, rows) => {
      try {
        if (err) throw err;

        if (rows) {
          resolve(rows);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getSingleMeta(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, title, url, description, keyword, updated_at FROM metas WHERE id =${id}`;
    pool.query(sql, async (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function specialList() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT url, image, tag FROM special WHERE status= '1';`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function adHomeList() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT type, url, image, target FROM ads WHERE status= '1';`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function adList(data) {
  return new Promise((resolve, reject) => {
    var sql = `SELECT type, url, image, target FROM ads WHERE type IN (${data});`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function storeData(url) {
  return new Promise((resolve, reject) => {
    var sql = `SELECT id, name, title, tagline, category FROM store WHERE url= '${url}'`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results && results[0]) {
          var sql = `SELECT a.id, a.type, a.title, a.url, a.tlink, a.commission, a.offer, a.cashback, a.category, a.store, a.image, a.expiry, a.tnc, a.discription, b.logo as storeLogo FROM coupon as a LEFT JOIN store as b on b.id = a.store WHERE a.status= '1' AND a.store= '${results[0].id}' AND a.start<= '${today}' AND a.expiry >= '${today}';
                                SELECT a.id, a.type, a.title, a.url, a.tlink, a.percent, a.tagline, a.cutoff, a.current_value, a.category, a.store, a.offday, a.expiry, a.tnc, a.discription, b.logo as storeLogo FROM deal as a LEFT JOIN store as b on b.id = a.store WHERE a.status= '1' AND a.store= '${results[0].id}' AND a.start< '${today}' AND a.expiry > '${today}';                                
                                SELECT id, name, logo, url FROM store WHERE status= '1' ORDER by RAND() LIMIT 3 ;
                                SELECT id, name, title, tagline FROM store WHERE url= '${url}';`;
          pool.query(sql, [1, 2, 3, 4], (err2, results2) => {
            try {
              if (err2) {
                throw err2;
              }

              if (results2) {
                resolve(results2);
              }
            } catch (e) {
              logError(e);
              return;
            }
          });
        } else {
          resolve([]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function adminQuestionBank() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, title, type, mandatory, options, status, updated_at FROM question ORDER BY id DESC;`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve({
            results
          });
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function surveyCategory() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, name, tab1, tab2, tab3 FROM basic WHERE type="Survey" ORDER BY tab1 DESC;`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve({
            results
          });
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getSurveyQuestion(data) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, title, type, mandatory, options FROM question WHERE id IN (${data});`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve({
            results
          });
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function userQuestionBank(data) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, title, type, mandatory, options, updated_at FROM question WHERE id IN (${data});`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve({
            results
          });
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function surveyData() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, type, name, tab3 FROM basic WHERE type='Survey' AND tab2=1 ORDER BY id DESC;`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve({
            results
          });
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getUser(code) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id FROM users WHERE referralcode='${code}';`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results[0]) {
          resolve(results[0].id);
        } else {
          resolve(null);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
} // export function allStoreData() {
//     return new Promise((resolve, reject) => {
//         var sql = `SELECT id, type, category, title, url, commission, offer, cashback, image, expiry, store FROM coupon WHERE status= '1';
//                     SELECT id, type, category, title, url, percent, tagline, cutoff, current_value, image, store FROM deal WHERE status= '1';
//                     SELECT id, name, category, logo, url FROM store WHERE status= '1';
//                     SELECT id, name, url, icon FROM category WHERE status= '1' AND type='Category' ORDER BY display_order ASC;`;
//         pool.query(sql, [1,2,3,4], (err, results) => {
//             try{
//             if(err){ throw err }
//             if(results){ resolve( results ) }
//             }catch(e){ logError(e); return; }
//         })
//     })
// }


function allStoreData() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT id, name, category, logo, url, cashback FROM store WHERE status= '1';`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function storeSidebar() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT id, name, category, logo, url, cashback FROM store WHERE status= '1';
                    SELECT id, name, icon, url FROM category WHERE status= '1' AND type='Category' ORDER BY display_order ASC;
                    SELECT id, name, tab1 as url FROM basic WHERE status= '1' AND type='Tags';`;
    pool.query(sql, [1, 2, 3], (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function homeData() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT type, name, tab1, tab2, tab3 FROM basic WHERE type IN('Carousel', 'SnowFall') AND status =1; 
                    SELECT id, name, icon, url FROM category WHERE status= '1' AND type='Category' ORDER BY display_order ASC;
                    SELECT a.id, a.name, a.logo, a.category, a.tagline, a.url, a.salesline, a.cashback, b.icon, b.banner FROM store as a left join category as b on b.id = a.category WHERE a.status= '1' ORDER BY a.display_order ASC;
                    SELECT a.title, a.url, a.offday, a.category, a.cutoff, a.current_value, a.offer_count, a.tagline, a.store, b.url as storeUrl, b.logo as storeLogo FROM deal as a left JOIN store as b on b.id = a.store WHERE a.status= '1' AND JSON_CONTAINS(a.tags, '33') = 1;
                    SELECT a.title, a.url, a.image, a.category, a.tags, a.commission, a.cashback, a.offer, a.cashback, a.store, b.url as storeUrl, b.title as storeTitle, b.logo as storeLogo FROM coupon as a left JOIN store as b on b.id = a.store WHERE ( JSON_CONTAINS(a.tags, '11') OR JSON_CONTAINS(a.tags, '33') ) AND a.status= '1';
                    SELECT a.id, a.name, a.url, a.logo, a.category, a.tagline, a.salesline, a.cashback, b.icon, a.banner FROM store as a left join category as b on b.id = a.category WHERE a.status= '1' AND JSON_CONTAINS(a.tags, '30') = 1 ORDER BY a.display_order ASC;
                    SELECT name FROM basic WHERE id= 33;
                    SELECT name FROM basic WHERE type= 'Tagline' AND status= 1;
                    SELECT name FROM basic WHERE type= 'Jhalar' AND status= 1;`;
    pool.query(sql, [1, 2, 3, 4, 5, 6, 7, 8, 9], (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function shopData() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT logo, tagline, cashback, url, tags FROM store WHERE status= 1;
                    SELECT id, name FROM basic WHERE type ='Tags'`;
    pool.query(sql, [1, 2], (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function headerData() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT logo, tagline, cashback, tags, url, name, category FROM store WHERE status= 1;
                    SELECT id, name, tab1 as url FROM basic WHERE type ='Tags' AND status= 1;
                    SELECT id, name, url FROM category WHERE status= 1 AND type = 'Category' AND status= 1;
                    SELECT id, name, cashback, url FROM store WHERE status= 1 AND tags LIKE '%${recomStore}%';
                    SELECT name as text, url as value FROM store WHERE status= 1;
                    `;
    pool.query(sql, [1, 2], (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function categoryData() {
  return new Promise((resolve, reject) => {
    var sql = `SELECT id, type, category, name, url FROM category WHERE status= 1;`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function updateLeaderBoard(id, points, action) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, cashback, reward, redeemed, total FROM leaderboard WHERE userId = '${id}'`;
    pool.query(sql, async (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results.length) {
          let post = {
            'userId': id,
            "updated_at": time
          };

          if (action == 'cashback') {
            post.cashback = parseInt(results[0].cashback) + parseInt(points);
            post.total = parseInt(results[0].total) + parseInt(points);
          } else if (action == 'reward') {
            post.reward = parseInt(results[0].reward) + parseInt(points);
            post.total = parseInt(results[0].total) + parseInt(points) * 200;
          } else if (action == 'redeem') {
            post.redeemed = parseInt(results[0].redeemed) + parseInt(points);
            post.total = parseInt(results[0].total) - parseInt(points);
          }

          let sql = `UPDATE leaderboard SET ? WHERE userId = ${id}`;
          pool.query(sql, post, (err2, results2) => {
            try {
              if (err2) {
                throw err2;
              }

              if (results2) {
                const leader = getLeaderBoard(id);
                resolve(leader);
              }
            } catch (e) {
              logError(e);
              return;
            }
          });
        } else {
          let post = {
            'userId': id,
            'redeemed': 0,
            "created_at": time,
            "updated_at": time
          };

          if (action == 'cashback') {
            post.cashback = parseInt(points);
            post.total = parseInt(points);
          } else if (action == 'reward') {
            post.reward = parseInt(points);
            post.total = parseInt(points) * 200;
          } else if (action == 'redeem') {
            post.redeemed = parseInt(results[0].redeemed) + parseInt(points);
            post.total = parseInt(results[0].total) - parseInt(points);
          }

          let sql = `INSERT INTO leaderboard SET ?`;
          pool.query(sql, post, (err2, results2) => {
            try {
              if (err2) {
                throw err2;
              }

              if (results2) {
                const leader = getLeaderBoard(id);
                resolve(leader);
              }
            } catch (e) {
              logError(e);
              return;
            }
          });
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function cashbackDone(userId, points) {
  return new Promise((resolve, reject) => {
    var sql = `UPDATE leaderboard SET cashback=cashback-${points}, redeemed = redeemed + ${points}, total=total-${points} WHERE userId = ${userId}`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getcashbackedData(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT a.id, a.userId, a.redeem, a.remarks, a.status, a.merchantrefid, a.payuresponse, a.updated_at, b.name, b.email, b.phone, c.cashback, c.reward, c.total
                    FROM transfercashback as a left join users as b on b.id = a.userId
                    left join leaderboard as c on c.userId = a.userId WHERE a.id = ${id};`;
    pool.query(sql, async (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
} // export function getcashbackedData(array){
//     return new Promise((resolve, reject) => {
//         let sql =   `SELECT a.id, a.userId, a.redeem, a.remarks, a.status, a.merchantrefid, a.updated_at, b.name, b.email, b.phone, c.cashback, c.reward, c.total
//                     FROM transfercashback as a left join users as b on b.id = a.userId
//                     left join leaderboard as c on c.userId = a.userId WHERE a.id IN (${array});`
//         pool.query(sql, async(err, results) => {
//             try{
//                 if(err){ throw err }
//                 if(results){ resolve( results ) }
//             }catch(e){ logError(e); return; }
//         })
//     })
// }


function getSingleBasic(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, type, name, tab1, tab2, tab3, status FROM basic WHERE id = '${id}';`;
    pool.query(sql, async (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getLeaderBoard(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT a.id, a.userId, a.cashback, a.reward, a.redeemed, a.total, a.updated_at, b.name, b.email, b.phone FROM leaderboard as a
                    left join users as b on b.id = a.userId WHERE a.userId = '${id}';`;
    pool.query(sql, async (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getCashbackUser(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT a.id, a.userId, a.publisher, a.date, a.store, a.amount, a.rewardPayout, a.customerPayout, a.description, a.updated_at, a.status, b.name, b.email, b.phone, c.name as store, d.name as publisher FROM cashback as a 
                    left join users as b on b.id = a.userId 
                    left join store as c on c.id = a.store
                    left join basic as d on d.id = a.publisher WHERE a.id= ${id};`;
    pool.query(sql, async (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function stPub() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, name FROM store ORDER BY id DESC;
                    SELECT id, name FROM basic WHERE type='Publisher' ORDER BY id DESC;`;
    pool.query(sql, (err, rows) => {
      try {
        if (err) {
          throw err;
        }

        if (rows) {
          resolve(rows);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function userOptions() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT name as text, id as value FROM users;`;
    pool.query(sql, (err, rows) => {
      try {
        if (err) {
          throw err;
        }

        if (rows) {
          resolve(rows);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function getMeta(url) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT title, description, keyword FROM metas WHERE url='${url}';
                    SELECT title, description, keyword FROM metas WHERE url='default';
                    SELECT name FROM blog_metas WHERE type='page' AND url='${url}'`;
    pool.query(sql, [1, 2, 3], (err, rows) => {
      try {
        if (err) throw err;

        if (rows) {
          if (rows[0].length) {
            rows[0][0].url = url;

            if (rows[2].length) {
              rows[0][0].image = 'cover/' + rows[2][0].name;
            }

            resolve(rows[0]);
          } else if (rows[1].length) {
            rows[1][0].url = url;

            if (rows[2].length) {
              rows[1][0].image = 'cover/' + rows[2][0].name;
            }

            resolve(rows[1]);
          }
        } else if (err) {
          throw err;
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function tagName(data) {
  var list = [];
  return new Promise((resolve, reject) => {
    if (data.length > 0) {
      let sql = `SELECT name as text, id as value FROM basic WHERE id IN (${data});`;
      pool.query(sql, (err, results) => {
        try {
          if (err) throw err;

          if (results) {
            resolve(results);
          }
        } catch (e) {
          logError(e);
          return;
        }
      });
    } else {
      resolve(list);
    }
  });
}

function catName(data) {
  var list = [];
  return new Promise((resolve, reject) => {
    if (data.length > 0) {
      let sql = `SELECT name as text, id as value FROM category WHERE id IN (${data});`;
      pool.query(sql, (err, results) => {
        try {
          if (err) throw err;

          if (results) {
            resolve(results);
          }
        } catch (e) {
          logError(e);
          return;
        }
      });
    } else {
      resolve(list);
    }
  });
}

function pubName(data) {
  var list = [];
  return new Promise((resolve, reject) => {
    if (data.length > 0) {
      let sql = `SELECT name as text, id as value FROM basic WHERE id IN (${data});`;
      pool.query(sql, (err, results) => {
        try {
          if (err) throw err;

          if (results) {
            resolve(results);
          }
        } catch (e) {
          logError(e);
          return;
        }
      });
    } else {
      resolve(list);
    }
  });
}

function blogMetaName(type, data) {
  var list = [];
  return new Promise((resolve, reject) => {
    if (data.length > 0) {
      for (var i = 0; i < data.length; i++) {
        let sql = `SELECT name, id, url FROM blog_metas WHERE type = '${type}' AND id = '${data[i]}';`;
        pool.query(sql, (err, results) => {
          try {
            if (err) throw err;
            list.push(results[0]);

            if (i == data.length) {
              resolve(list);
            }
          } catch (e) {
            logError(e);
            return;
          }
        });
      }
    } else {
      resolve(list);
    }
  });
}

function blogMetaData(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT title, url FROM blogs ORDER BY id DESC;
                    SELECT name, url FROM blog_metas WHERE type = 'category';
                    SELECT name, url FROM blog_metas WHERE type = 'tag';
                    SELECT id, blogId, c_order, commentId, user, email, comment, updated_at FROM comments WHERE blogId = '${id}' AND status='1' AND c_order= '0' ORDER BY id DESC;
                    SELECT id, blogId, c_order, commentId, user, email, comment, updated_at FROM comments WHERE blogId = '${id}' AND status='1' AND c_order= '1' ORDER BY id ASC
                    `;
    pool.query(sql, [1, 2, 3, 4, 5], (err, results) => {
      try {
        if (err) throw err;
        resolve(results);
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function suggestBlogs() {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, title as heading, url, coverImg FROM blogs ORDER by RAND() LIMIT 10`;
    pool.query(sql, (err, rows) => {
      try {
        if (err) {
          throw err;
        }

        if (rows) {
          resolve(rows);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function verifyToken(req, res, next) {
  if (req.cookies.token) {
    const bearerHeader = req.cookies.token;

    if (typeof bearerHeader !== 'undefined') {
      req.token = bearerHeader;
      const {
        exp
      } = (0, _jsonwebtoken.decode)(bearerHeader);

      if (Date.now() >= exp * 1000) {
        res.redirect('/login?e=' + encodeURIComponent('LoggedOut'));
        return;
      }

      next();
    } else {
      res.sendStatus(403);
      return;
    }
  } else {
    res.redirect('/login?e=' + encodeURIComponent('LoggedOut'));
    return;
  }
}

function verifyAdmin(req, res, next) {
  if (req.cookies.token) {
    const bearerHeader = req.cookies.token;

    try {
      const user = jwt.verify(bearerHeader, 'secretkey');

      if (user.user.role !== 'Admin') {
        res.redirect('/blog');
        res.end();
        return;
      }

      next();
    } catch (e) {
      logError(e);
      res.status(403);
      return;
    }
  } else {
    res.redirect('/login?e=' + encodeURIComponent('LoggedOut'));
  }
}

function verifyUser(req, res, next) {
  if (req.cookies.token) {
    const bearerHeader = req.cookies.token;

    try {
      const user = jwt.verify(bearerHeader, 'secretkey');

      if (user.user.role !== 'User') {
        res.redirect('/blog');
        res.end();
        return;
      }

      next();
    } catch (e) {
      logError(e);
      res.status(403);
      return;
    }
  } else {
    res.redirect('/login?e=' + encodeURIComponent('LoggedOut'));
  }
}

function adminCategory(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, type, url, category, title, name, icon, display_order, banner, status, updated_at FROM category WHERE id = '${id}'`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function adminCoupon(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, store, title, category, tags, url, tlink, publisher, commission, image, offer, cashback, status, start, expiry, coupon_type, tnc, discription, updated_at from coupon WHERE id = '${id}'`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function adminDeal(id) {
  return new Promise((resolve, reject) => {
    let sql = `SELECT id, store, url, tlink, category, publisher, title, deal_type, percent, tags, offday, tagline, cutoff, current_value, offer_count, status, tnc, discription, start, expiry, updated_at, offday FROM deal WHERE id = '${id}';`;
    pool.query(sql, (err, results) => {
      try {
        if (err) {
          throw err;
        }

        if (results) {
          resolve(results[0]);
        }
      } catch (e) {
        logError(e);
        return;
      }
    });
  });
}

function sendMailOnError(e) {
  const mailBody = `
        <h2><strong>Hi</h2>
        <p>There has been error in Reward Eagle. Please check if website is running or not.</p>
        <p>Then check the log</p>
        ${e}<br/>
        <p>Warm Regards</p>`;
  let mailOptions = {
    to: 'navneet.khare@casleyconsulting.co.jp',
    from: 'navneet.khare@casleyconsulting.co.jp',
    subject: "Error on ✔ www.rewardeagle.com",
    html: mailBody
  };
  transporter.sendMail(mailOptions, (error, info) => {
    printError(e);
  });
}

function logError(e) {
  sendMailOnError(e);
  console.log(`e in logError`, e);
  printError(e);
}