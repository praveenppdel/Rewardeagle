"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Blog = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _BlogList = _interopRequireDefault(require("./BlogList"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

class Blog extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "catApi", async (type, url) => {
      const response = await fetch('/blog/list/' + type + '/' + url);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        blogs: body.blogs,
        title: body.title,
        category: body.category
      });
    });
    this.state = {
      blogs: this.props.blogs,
      title: this.props.title,
      category: this.props.category
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    const slug = window.location.pathname.split("/").pop();

    if (slug === 'blog') {
      const url = 'All';
      const type = "All";
      this.catApi(type, url);
    }

    if (slug !== 'blog') {
      const url = slug;
      const type = window.location.pathname.split("/")[1];
      this.catApi(type, url);
    }

    (window.adsbygoogle = window.adsbygoogle || []).push({});
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container mt-5"
    }, this.state.title ? /*#__PURE__*/_react.default.createElement("section", {
      dangerouslySetInnerHTML: {
        __html: this.state.title
      }
    }) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "row blogs"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "web mb-5"
    }, /*#__PURE__*/_react.default.createElement("h2", null, "Categories"), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/blog"
    }, "All")), this.state.category ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.category.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/category/" + i.url
    }, i.name)))) : null)), /*#__PURE__*/_react.default.createElement("ins", {
      className: "adsbygoogle",
      style: {
        display: 'block'
      },
      "data-ad-client": "ca-pub-3464486838908135",
      "data-ad-slot": "1079744155",
      "data-ad-format": "auto",
      "data-full-width-responsive": "true"
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-9"
    }, /*#__PURE__*/_react.default.createElement(_BlogList.default, {
      blogs: this.state.blogs
    })))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.Blog = Blog;
var _default = Blog;
exports.default = _default;