"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

class Sidebar extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    this.state = {
      search: ''
    };
  }

  componentDidMount() {
    (window.adsbygoogle = window.adsbygoogle || []).push({});
  }

  render() {
    return /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3 mt-5 sidebar"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Search for",
      name: "search",
      required: true,
      value: this.state.search,
      onChange: this.onChange
    }), /*#__PURE__*/_react.default.createElement("div", {
      className: "form-group text-center"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/search/" + this.state.search,
      type: "Submit",
      className: "casleyBtn",
      style: {
        padding: '5px 1em'
      }
    }, "Search"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "redBg mb-5"
    }, this.props.blogList ? /*#__PURE__*/_react.default.createElement("div", {
      className: "list"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Recent Blogs"), /*#__PURE__*/_react.default.createElement("ul", null, this.props.blogList.slice(0, 5).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/blog/" + i.url
    }, i.title))))) : null, this.props.cats ? /*#__PURE__*/_react.default.createElement("div", {
      className: "list"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Blog Categories"), /*#__PURE__*/_react.default.createElement("ul", null, this.props.cats.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/category/" + i.url
    }, i.name))))) : null, this.props.tags ? /*#__PURE__*/_react.default.createElement("div", {
      className: "list"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Blog Tags"), /*#__PURE__*/_react.default.createElement("ul", null, this.props.tags.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/tag/" + i.url
    }, i.name))))) : null), /*#__PURE__*/_react.default.createElement("ins", {
      className: "adsbygoogle",
      style: {
        display: 'block'
      },
      "data-ad-client": "ca-pub-3464486838908135",
      "data-ad-slot": "1079744155",
      "data-ad-format": "auto",
      "data-full-width-responsive": "true"
    }));
  }

}

var _default = Sidebar;
exports.default = _default;