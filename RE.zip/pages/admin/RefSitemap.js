"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.RefSitemap = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

class RefSitemap extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/sitemapData');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        blogs: body.blogs,
        blogMeta: body.blogMeta,
        stores: body.stores,
        category: body.category,
        tags: body.tags
      });
    });
    this.state = {
      blogs: [],
      blogMeta: [],
      stores: [],
      category: [],
      tags: [],
      pages: ['stores', 'category', 'deals', 'about-us', 'blog', 'career', 'survey', 'faq', 'how-it-works', 'vision-and-mission']
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    const time = new Date().toISOString().slice(0, 19);
    const site = "https://www.rewardeagle.com/";
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin my-5"
    }, /*#__PURE__*/_react.default.createElement("h1", {
      className: "heading"
    }, /*#__PURE__*/_react.default.createElement("span", null, "Admin Panel "), "(Sitemap)"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row admin"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10 sitemap"
    }, /*#__PURE__*/_react.default.createElement("p", null, '<?xml version="1.0" encoding="UTF-8"?>'), /*#__PURE__*/_react.default.createElement("p", null, '<urlset'), /*#__PURE__*/_react.default.createElement("p", null, 'xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"'), /*#__PURE__*/_react.default.createElement("p", null, 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'), /*#__PURE__*/_react.default.createElement("p", null, 'xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9'), /*#__PURE__*/_react.default.createElement("p", null, 'http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">'), /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1"
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>1.00</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>')), this.state.pages.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1",
      key: index
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}${i}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>.90</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>'))), this.state.blogs.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1",
      key: index
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}blog/${i.url}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>.80</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>'))), this.state.stores.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1",
      key: index
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}stores/${i.url}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>.80</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>'))), this.state.stores.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1",
      key: index
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}storeCategory/${i.url}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>.80</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>'))), this.state.tags.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1",
      key: index
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}storeTag/${i.url}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>.80</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>'))), this.state.blogMeta.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "ml1",
      key: index
    }, /*#__PURE__*/_react.default.createElement("p", null, '<url>'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<loc>${site}${i.type}/${i.url}</loc>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<lastmod>${time}+00:00</lastmod>`), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, `<priority>.70</priority>`), /*#__PURE__*/_react.default.createElement("p", null, '</url>'))), /*#__PURE__*/_react.default.createElement("p", null, '</urlset> ')))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.RefSitemap = RefSitemap;
var _default = RefSitemap;
exports.default = _default;