"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Schema = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

class Schema extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/blog/list/All/All');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        blogs: body.blogs
      });
    });
    this.state = {
      blogs: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  _renderBlogList() {
    const siteName = "https://www.rewardeagle.com/";
    var currentdate = new Date();
    return this.state.blogs.map((i, index) => {
      return /*#__PURE__*/_react.default.createElement("div", {
        className: "col-sm-12 ",
        key: i.id
      }, /*#__PURE__*/_react.default.createElement("p", {
        className: "ml4"
      }, "{"), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"@context\":\"http://schema.org\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"@type\": \"BlogPosting\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"image\": ", '{', "\"@type\": \"imageObject\", \"url\": \"", siteName, "images/blog/", i.coverImg, "\"", '}', ","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"url\": \"", siteName, "blog/", i.url, "\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"headline\": \"", i.title, "\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"dateCreated\": \"", i.updated_at, "\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"datePublished\": \"", i.updated_at, "\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"datemodified\": \"", i.updated_at, "\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"inLanguage\": \"English\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"isFamilyFriendly\": \"true\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"copyrightYear\": ", currentdate.getFullYear(), ","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"copyrightHolder\": \"Reward Eagle\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"author\": \"Reward Eagle\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"mainEntityOfPage\": \"True\","), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"creator\": ", '{', "\"@type\": \"Organization\", \"name\": \"Reward Eagle\", \"url\": \"", siteName, "\"", "},"), /*#__PURE__*/_react.default.createElement("p", {
        className: "ml5"
      }, "\"publisher\": ", '{', "\"@type\": \"Organization\", \"name\": \"Reward Eagle\", \"url\": \"", siteName, "\", \"logo\": ", '{', "\"@type\": \"ImageObject\", \"url\": \"", siteName, "images/logo-red.png\"", '}'), this.state.blogs.length - 1 == index ? /*#__PURE__*/_react.default.createElement("p", {
        className: "ml4"
      }, "}") : /*#__PURE__*/_react.default.createElement("p", {
        className: "ml4"
      }, "},"));
    });
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin my-5"
    }, /*#__PURE__*/_react.default.createElement("h1", {
      className: "heading"
    }, /*#__PURE__*/_react.default.createElement("span", null, "Admin Panel "), "(Schema)"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row admin"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10 schema"
    }, /*#__PURE__*/_react.default.createElement("p", null, '<script type="application/ld+json">'), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml1"
    }, "{"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"@context\":             \"http://www.schema.org\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"@type\":                \"LocalBusiness\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"@id\":                  \"https://www.rewardeagle.com/\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"url\":                  \"https://www.rewardeagle.com/\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"name\" :                \"Reward Eagle\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"description\" :         \"We provide best deals and coupons for shopping\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"logo\":                 \"https://www.rewardeagle.com/images/logo-red.png\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"address\":"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml3"
    }, "{"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"@type\" :           \"PostalAddress\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"addressCountry\" :  \"IN\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"addressLocality\" : \"Gurgaon\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"addressRegion\" :   \"Haryana\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"postalCode\" :      \"122002\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"streetAddress\" :   \"Gurgaon, Haryana - 122002\""), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml3"
    }, "},"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"telephone\" :           \"+91-9695871040\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"email\":                \"hello@Reward Eagle.com\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"image\" :               \"https://www.rewardeagle.com/images/logo-red.png\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"sameAs\" :"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml3"
    }, "["), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"https://www.facebook.com/rewardeagle\", "), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"https://www.linkedin.com/company/20445385/admin/\", "), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"https://twitter.com/Reward_Eagle\", "), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml4"
    }, "\"https://www.instagram.com/rewardeagle_india/\", "), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml3"
    }, "],"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"priceRange\" : \"$10 - $300\","), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml2"
    }, "\"@graph\":"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml3"
    }, "["), this._renderBlogList(), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml3"
    }, "]"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml1"
    }, "}"), /*#__PURE__*/_react.default.createElement("p", {
      className: "ml"
    }, '</script>')))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.Schema = Schema;
var _default = Schema;
exports.default = _default;