"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Survey = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _axios = _interopRequireDefault(require("axios"));

const secret = require('../parts/secret');

const func = require('../parts/functions');

class Survey extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "activeChange", val => {
      this.setState({
        active: val
      });
    });
    (0, _defineProperty2.default)(this, "inrData", async e => {
      e.preventDefault();
      this.setState({
        loading: true,
        getINR: true
      });
      var date1 = new Date(this.state.startdate);
      var date2 = new Date(this.state.enddate);
      var diffDays = parseInt((date2 - date1) / (1000 * 60 * 60 * 24), 10);

      if (diffDays < 60) {
        _axios.default.get(`${this.state.hero}https://inrdeals.com/fetch/reports?token=${this.state.token}&id=${this.state.inrId}&startdate=${this.state.startdate.replace(/-/g, "")}&enddate=${this.state.enddate.replace(/-/g, "")}`, {
          crossdomain: true
        }).catch(err => func.printError(err)).then(res => {
          this.setState({
            inr: res.data.result.data,
            loading: false
          });
        });
      } else {
        func.callSwal(`Only 60 days period allowed - ${diffDays} Days`);
      }
    });
    (0, _defineProperty2.default)(this, "vcData", async e => {
      e.preventDefault();
      this.setState({
        loading: true,
        getVC: true
      });

      _axios.default.get(`${this.state.hero}https://vcm.api.hasoffers.com/Apiv3/json?api_key=${this.state.vcToken}&Target=Affiliate_Report&Method=getConversions&fields[]=Stat.approved_payout&fields[]=Stat.offer_id&fields[]=Stat.id&fields[]=ConversionsMobile.affiliate_unique2&fields[]=ConversionsMobile.affiliate_click_id&filters[Stat.date][conditional]=BETWEEN&filters[Stat.date][values][]=${this.state.vcStartDate}&filters[Stat.date][values][]=${this.state.vcEndDate}`, {
        crossdomain: true
      }).catch(err => func.printError(err)).then(res => {
        this.setState({
          vcRes: res.data.response.data.data,
          loading: false
        });
      });
    });
    this.state = {
      hero: "https://cors-anywhere.herokuapp.com/",
      token: secret.inrToken,
      inrId: secret.inrId,
      vcToken: secret.vcToken,
      // startdate:              "2021-04-01",
      // enddate:                "2021-05-13",
      startdate: "",
      enddate: "",
      // vcStartDate:            "2021-04-01",
      // vcEndDate:              "2021-05-13",
      vcStartDate: "",
      vcEndDate: "",
      inr: [],
      vcRes: [],
      active: "INR",
      loading: false,
      getINR: false,
      getVC: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
  }

  render() {
    const renderINR = this.state.inr.map((i, index) => {
      return /*#__PURE__*/_react.default.createElement("tr", {
        key: index
      }, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null, i.click_id, " | ", i.id, " | ", i.transaction_id), /*#__PURE__*/_react.default.createElement("td", null, i.status, " | ", i.referrer_url), /*#__PURE__*/_react.default.createElement("td", null, i.sale_amount, " | ", i.sale_date), /*#__PURE__*/_react.default.createElement("td", null, i.store_name), /*#__PURE__*/_react.default.createElement("td", null, i.sub_id1, " | ", i.sub_id2), /*#__PURE__*/_react.default.createElement("td", null, i.updated_at), /*#__PURE__*/_react.default.createElement("td", null, i.user_commission));
    });
    const renderVC = this.state.vcRes.map((i, index) => {
      return /*#__PURE__*/_react.default.createElement("tr", {
        key: index
      }, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null, i.Stat.id), /*#__PURE__*/_react.default.createElement("td", null, i.Stat.offer_id), /*#__PURE__*/_react.default.createElement("td", null, i.Stat.approved_payout), /*#__PURE__*/_react.default.createElement("td", null, i.ConversionsMobile.affiliate_click_id));
    });
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin apis"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( Vendor API )"), /*#__PURE__*/_react.default.createElement("ul", {
      className: "vendors mb-5"
    }, /*#__PURE__*/_react.default.createElement("li", {
      onClick: () => this.activeChange('INR'),
      className: this.state.active == "INR" ? "active" : null
    }, "INR Deals"), /*#__PURE__*/_react.default.createElement("li", {
      onClick: () => this.activeChange('VC'),
      className: this.state.active == "VC" ? "active" : null
    }, "V Commission")), this.state.active == "INR" ? /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.inrData
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2"
    }), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Start Date"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "startdate",
      required: true,
      value: this.state.startdate,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "End Date"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "enddate",
      required: true,
      value: this.state.enddate,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2"
    }), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn m-0",
      type: "submit"
    }, "Submit", /*#__PURE__*/_react.default.createElement("span", null))))) : this.state.active == "VC" ? /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.vcData
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2"
    }), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Start Date"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "vcStartDate",
      required: true,
      value: this.state.vcStartDate,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "End Date"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "vcEndDate",
      required: true,
      value: this.state.vcEndDate,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2"
    }), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn m-0",
      type: "submit"
    }, "Submit", /*#__PURE__*/_react.default.createElement("span", null))))) : null, this.state.active == "INR" && this.state.getINR ? /*#__PURE__*/_react.default.createElement("div", {
      className: "apiResults"
    }, /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl no."), /*#__PURE__*/_react.default.createElement("td", null, "click_id | id | transaction_id"), /*#__PURE__*/_react.default.createElement("td", null, "Status | referrer_url"), /*#__PURE__*/_react.default.createElement("td", null, "sale_amount | sale_date"), /*#__PURE__*/_react.default.createElement("td", null, "store_name"), /*#__PURE__*/_react.default.createElement("td", null, "sub_id1 | sub_id2"), /*#__PURE__*/_react.default.createElement("td", null, "updated_at"), /*#__PURE__*/_react.default.createElement("td", null, "user_commission"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.loading ? /*#__PURE__*/_react.default.createElement("tr", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("td", {
      colSpan: "10",
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    }))) : renderINR))) : null, this.state.active == "VC" && this.state.getVC ? /*#__PURE__*/_react.default.createElement("div", {
      className: "apiResults"
    }, /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl no."), /*#__PURE__*/_react.default.createElement("td", null, "Id"), /*#__PURE__*/_react.default.createElement("td", null, "Offer Id"), /*#__PURE__*/_react.default.createElement("td", null, "Payout"), /*#__PURE__*/_react.default.createElement("td", null, "affiliate_click_id"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.loading ? /*#__PURE__*/_react.default.createElement("tr", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("td", {
      colSpan: "10",
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    }))) : renderVC))) : null))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.Survey = Survey;
var _default = Survey;
exports.default = _default;