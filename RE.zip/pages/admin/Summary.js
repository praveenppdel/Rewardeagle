"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Summary = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

const func = require('../parts/functions');

class Summary extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/adminSummary');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data,
        loading: false
      });
    });
    this.state = {
      data: [],
      loading: true
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin Panel Summary "), /*#__PURE__*/_react.default.createElement("div", {
      className: "container"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, this.state.data[0] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Active Customers"), /*#__PURE__*/_react.default.createElement("span", null, this.state.data[0][0].count)) : null, this.state.data[1] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Active Publishers"), /*#__PURE__*/_react.default.createElement("span", null, this.state.data[1].length)) : null, this.state.data[2] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Active Stores"), /*#__PURE__*/_react.default.createElement("span", null, this.state.data[2].length)) : null, this.state.data[3] && this.state.data[4] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Active Coupon & Deals"), /*#__PURE__*/_react.default.createElement("span", null, this.state.data[3].length + this.state.data[4].length)) : null, this.state.data[7] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Blogs Published"), /*#__PURE__*/_react.default.createElement("span", null, this.state.data[7][0].count)) : null, this.state.data[10] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Subscriptions"), /*#__PURE__*/_react.default.createElement("span", null, this.state.data[10][0].count)) : null, this.state.data[5] ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("h3", null, "Survey"), /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Category"), /*#__PURE__*/_react.default.createElement("td", null, "Surveys"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.data[6].map((i, index) => /*#__PURE__*/_react.default.createElement("tr", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("td", null, i.name), /*#__PURE__*/_react.default.createElement("td", null, this.state.data[5].filter(j => j.category == i.id).length)))))) : null)), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, this.state.data[5] ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("h3", null, "Job Applications"), /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Role"), /*#__PURE__*/_react.default.createElement("td", null, "Applications"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.data[9].map((i, index) => /*#__PURE__*/_react.default.createElement("tr", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("td", null, i.role), /*#__PURE__*/_react.default.createElement("td", null, this.state.data[8].filter(j => j.careerId == i.id).length)))))) : null, this.state.data[1] ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("h3", null, "Publisher"), /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Publisher"), /*#__PURE__*/_react.default.createElement("td", null, "Store"), /*#__PURE__*/_react.default.createElement("td", null, "Coupon"), /*#__PURE__*/_react.default.createElement("td", null, "Deal"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.data[1].map((i, index) => /*#__PURE__*/_react.default.createElement("tr", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("td", null, i.name), /*#__PURE__*/_react.default.createElement("td", null, this.state.data[2].filter(j => j.publisher == i.id).length), /*#__PURE__*/_react.default.createElement("td", null, this.state.data[3].filter(j => j.publisher == i.id).length), /*#__PURE__*/_react.default.createElement("td", null, this.state.data[4].filter(j => j.publisher == i.id).length)))))) : null)))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.Summary = Summary;
var _default = Summary;
exports.default = _default;