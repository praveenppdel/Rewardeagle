"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.User = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _reactstrap = require("reactstrap");

var _ExportReactCSV = require("../parts/ExportReactCSV");

var _axios = _interopRequireDefault(require("axios"));

var _Autocomplete = _interopRequireDefault(require("@material-ui/lab/Autocomplete"));

var _TextField = _interopRequireDefault(require("@material-ui/core/TextField"));

const func = require('../parts/functions');

class User extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "handleClick", e => {
      this.setState({
        currentPage: Number(e.target.id)
      });
    });
    (0, _defineProperty2.default)(this, "changeitemsPerPage", e => {
      this.setState({
        itemsPerPage: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "searchSpace", e => {
      this.setState({
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "uploadImage", e => {
      this.setState({
        image: e.target.files[0]
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/adminUsers');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        users: body.data,
        count: body.count[`count('id')`],
        countValue: Math.ceil(body.count[`count('id')`] / 5000),
        usersCopy: body.data,
        loading: false
      });
    });
    (0, _defineProperty2.default)(this, "showProfile", async userId => {
      this.setState({
        userId: userId
      });
      const response = await fetch('/admin/getProfile/' + userId);
      const body = await response.json();

      if (body.data) {
        this.setState({
          userProfile: body.data,
          profileExists: true,
          showModal: true,
          userId: body.data.userId,
          name: JSON.parse(body.data.user)[0],
          email: JSON.parse(body.data.user)[1],
          phone: JSON.parse(body.data.user)[2],
          gender: JSON.parse(body.data.user)[3],
          dob: JSON.parse(body.data.user)[4],
          state: JSON.parse(body.data.address)[0],
          city: JSON.parse(body.data.address)[1],
          address: JSON.parse(body.data.address)[2],
          salary: JSON.parse(body.data.scim)[0],
          occupation: JSON.parse(body.data.scim)[1],
          interest: JSON.parse(body.data.scim)[2],
          marital: JSON.parse(body.data.scim)[3],
          actype: JSON.parse(body.data.bank)[0],
          bank: JSON.parse(body.data.bank)[1],
          acholder: JSON.parse(body.data.bank)[2],
          ifsc: JSON.parse(body.data.bank)[3],
          gpid: JSON.parse(body.data.google)[0],
          gpmob: JSON.parse(body.data.google)[1],
          paytmid: JSON.parse(body.data.paytm)[0],
          paytmmob: JSON.parse(body.data.paytm)[1],
          ppid: JSON.parse(body.data.phonepe)[0],
          ppmob: JSON.parse(body.data.phonepe)[1],
          oldImage: body.data.image
        });
      } else {
        this.setState({
          showModal: true
        });
        func.callSwal('Profile does not exist');
      }
    });
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        showModal: false,
        profileExists: false,
        id: '',
        name: '',
        email: '',
        gender: '',
        dob: '',
        phone: '',
        state: '',
        city: '',
        address: '',
        salary: '',
        occupation: '',
        interest: '',
        marital: '',
        actype: '',
        bank: '',
        acholder: '',
        confirmacnumber: '',
        ifsc: '',
        gpid: '',
        gpmob: '',
        paytmid: '',
        paytmmob: '',
        ppid: '',
        ppmob: '',
        image: null,
        oldImage: ''
      });
    });
    (0, _defineProperty2.default)(this, "submitHandler", e => {
      e.preventDefault();
      const data = new FormData();
      data.append('file', this.state.image);
      data.append('userId', this.state.userId);
      data.append('user', JSON.stringify([this.state.name, this.state.email, this.state.phone, this.state.gender, this.state.dob]));
      data.append('address', JSON.stringify([this.state.state, this.state.city, this.state.address]));
      data.append('scim', JSON.stringify([this.state.salary, this.state.occupation, this.state.interest, this.state.marital]));
      data.append('bank', JSON.stringify([this.state.actype, this.state.bank, this.state.acholder, this.state.ifsc]));
      data.append('google', JSON.stringify([this.state.gpid, this.state.gpmob]));
      data.append('paytm', JSON.stringify([this.state.paytmid, this.state.paytmmob]));
      data.append('phonepe', JSON.stringify([this.state.ppid, this.state.ppmob]));

      if (this.state.profileExists) {
        data.append('oldImage', this.state.oldImage);

        _axios.default.post('/admin/adminUpdateProfile', data).catch(err => func.printError(err)).then(res => {
          if (res.data.success) {
            localStorage.setItem('message', res.data.message);
            this.resetData();
          }

          func.callSwal(res.data.message);
        });
      } else {
        _axios.default.post('/admin/adminCreateProfile', data).catch(err => func.printError(err)).then(res => {
          if (res.data.success) {
            localStorage.setItem('message', res.data.message);
            this.resetData();
          }

          func.callSwal(res.data.message);
        });
      }
    });
    (0, _defineProperty2.default)(this, "getUsers", async e => {
      this.setState({
        check: e.target.value
      });

      if (e.target.value.length > 5) {
        const data = {
          email: e.target.value
        };

        _axios.default.post('/admin/getUserOptions', data).catch(err => func.printError(err)).then(res => {
          this.setState({
            userOptions: res.data.data,
            users: res.data.data
          });
        });
      } else {
        this.setState({
          userOptions: [],
          users: this.state.usersCopy
        });
      }
    });
    (0, _defineProperty2.default)(this, "changePagination", async e => {
      this.setState({
        currentPagination: e.target.value,
        loading: true
      });
      const data = {
        from: 5000 * (e.target.value - 1) + 1,
        to: 5000 * e.target.value
      };

      _axios.default.post('/admin/getUserPaginated', data).catch(err => func.printError(err)).then(res => {
        this.setState({
          users: res.data.data,
          loading: false
        });
      });
    });
    this.state = {
      count: '',
      countValue: 0,
      users: [],
      usersCopy: [],
      userOptions: [],
      userProfile: {},
      check: '',
      search: '',
      currentPage: 1,
      itemsPerPage: 25,
      loading: true,
      showModal: false,
      profileExists: false,
      id: '',
      name: '',
      email: '',
      gender: '',
      dob: '',
      phone: '',
      state: '',
      city: '',
      address: '',
      salary: '',
      occupation: '',
      interest: '',
      marital: '',
      actype: '',
      bank: '',
      acholder: '',
      confirmacnumber: '',
      ifsc: '',
      gpid: '',
      gpmob: '',
      paytmid: '',
      paytmmob: '',
      ppid: '',
      ppmob: '',
      image: null,
      oldImage: '',
      currentPagination: 1
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    const {
      currentPage,
      itemsPerPage
    } = this.state;
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const data = this.state.users.filter(i => {
      if (this.state.search == null) return i;else if (i.name.toLowerCase().includes(this.state.search.toLowerCase()) || i.email.toLowerCase().includes(this.state.search.toLowerCase())) {
        return i;
      }
    });
    const renderItems = data.slice(indexOfFirstItem, indexOfLastItem).map((i, index) => {
      return /*#__PURE__*/_react.default.createElement("tr", {
        key: index
      }, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null, i.name), /*#__PURE__*/_react.default.createElement("td", null, i.email), /*#__PURE__*/_react.default.createElement("td", null, i.phone), /*#__PURE__*/_react.default.createElement("td", null, i.role), /*#__PURE__*/_react.default.createElement("td", null, i.referralcode), /*#__PURE__*/_react.default.createElement("td", {
        className: "editIcon text-center"
      }, /*#__PURE__*/_react.default.createElement("img", {
        src: "/images/icons/edit.svg",
        alt: "Edit Icon",
        onClick: () => this.showProfile(i.id)
      })));
    });
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(this.state.users.length / itemsPerPage); i++) {
      pageNumbers.push(i);
    } // const renderPagination = pageNumbers.map(number => { if(currentPage == number){ return ( <li key={number} id={number} onClick={this.handleClick} className="active"> {number}</li> ) }else{ return ( <li key={number} id={number} onClick={this.handleClick} > {number}</li> ) } })


    const countArray = [];

    for (let i = 1; i <= this.state.countValue; i++) {
      countArray.push(i);
    }

    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( Users Data)"), /*#__PURE__*/_react.default.createElement("div", {
      className: "btn-pag"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex perPage"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Items per page"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      required: true,
      value: itemsPerPage,
      onChange: e => this.changeitemsPerPage(e)
    }, /*#__PURE__*/_react.default.createElement("option", null, itemsPerPage), /*#__PURE__*/_react.default.createElement("option", {
      value: "25"
    }, "25"), /*#__PURE__*/_react.default.createElement("option", {
      value: "50"
    }, "50"), /*#__PURE__*/_react.default.createElement("option", {
      value: "100"
    }, "100"), /*#__PURE__*/_react.default.createElement("option", {
      value: "500"
    }, "500"), /*#__PURE__*/_react.default.createElement("option", {
      value: "1000"
    }, "1000"), /*#__PURE__*/_react.default.createElement("option", {
      value: "2000"
    }, "2000"), /*#__PURE__*/_react.default.createElement("option", {
      value: "5000"
    }, "5000"))), this.state.countValue ? /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex perPage"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Pagination"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      required: true,
      value: 5000 * (this.state.currentPagination - 1) + 1 - 5000 * this.state.currentPagination,
      onChange: e => this.changePagination(e),
      style: {
        maxWidth: '200px'
      }
    }, /*#__PURE__*/_react.default.createElement("option", null, 5000 * (this.state.currentPagination - 1) + 1, " - ", 5000 * this.state.currentPagination), countArray.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i,
      key: index
    }, 5000 * (i - 1) + 1, " - ", 5000 * i)))) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "search"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex searchInput"
    }, /*#__PURE__*/_react.default.createElement(_Autocomplete.default, {
      inputValue: this.state.check,
      id: "combo-box-demo",
      options: this.state.userOptions,
      getOptionLabel: option => option.name,
      renderInput: params => /*#__PURE__*/_react.default.createElement(_TextField.default, (0, _extends2.default)({}, params, {
        label: "Search Here",
        variant: "outlined"
      })),
      onInputChange: e => this.getUsers(e)
    })))), /*#__PURE__*/_react.default.createElement("table", {
      className: "table"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl No."), /*#__PURE__*/_react.default.createElement("td", null, "Name"), /*#__PURE__*/_react.default.createElement("td", null, "Email"), /*#__PURE__*/_react.default.createElement("td", null, "Phone"), /*#__PURE__*/_react.default.createElement("td", null, "Role"), /*#__PURE__*/_react.default.createElement("td", null, "Referral Code"), /*#__PURE__*/_react.default.createElement("td", null, "Profile"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.loading ? /*#__PURE__*/_react.default.createElement("tr", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("td", {
      colSpan: "5",
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    }))) : renderItems)), /*#__PURE__*/_react.default.createElement(_ExportReactCSV.ExportReactCSV, {
      csvData: data,
      fileName: 'Users -' + func.time + '.xls'
    })))), /*#__PURE__*/_react.default.createElement(_Footer.default, null), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.showModal,
      className: "adminModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalHeader, null, " User Profile "), /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Your Name"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Your Name",
      name: "name",
      required: true,
      value: this.state.name,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Email"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "email",
      placeholder: "Your Email",
      name: "email",
      required: true,
      value: this.state.email,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Gender"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "gender",
      required: true,
      value: this.state.gender,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Gender"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Male"
    }, "Male"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Female"
    }, "Female"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Date of Birth"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      placeholder: "Your Date of Birth",
      name: "dob",
      required: true,
      value: this.state.dob,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Phone"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Your Phone",
      name: "phone",
      required: true,
      value: this.state.phone,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "State"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "State",
      name: "state",
      required: true,
      value: this.state.state,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "City"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "City",
      name: "city",
      required: true,
      value: this.state.city,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Address"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Address",
      name: "address",
      required: true,
      value: this.state.address,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Annual Salary"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "salary",
      required: true,
      value: this.state.salary,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Salary"), func.salary.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      key: index,
      value: i.value
    }, i.text)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Occupation"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "occupation",
      required: true,
      value: this.state.occupation,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Occupation"), func.occupation.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      key: index,
      value: i.value
    }, i.text)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Interest"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "interest",
      required: true,
      value: this.state.interest,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Interest"), func.interest.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      key: index,
      value: i.value
    }, i.text)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Marital Status"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "marital",
      required: true,
      value: this.state.marital,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Marital Status"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Single"
    }, "Single"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Married"
    }, "Married"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Profile Pic"), /*#__PURE__*/_react.default.createElement("input", {
      type: "file",
      className: "form-control",
      onChange: this.uploadImage
    }), this.state.oldImage ? /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/profile/" + this.state.oldImage,
      className: "preview"
    }) : null)), /*#__PURE__*/_react.default.createElement("h3", null, "Bank Details"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Account Type"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "actype",
      value: this.state.actype,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Account Type"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Savings"
    }, "Savings"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Current"
    }, "Current"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Bank Name"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Bank Name",
      name: "bank",
      value: this.state.bank,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Name of Account Holder"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Name of Account Holder",
      name: "acholder",
      value: this.state.acholder,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Confirm Account Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Account Number",
      name: "confirmacnumber",
      value: this.state.confirmacnumber,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "IFSC Code"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "IFSC Code",
      name: "ifsc",
      value: this.state.ifsc,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("h3", null, "Other Bank Options"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Google Pay ID"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Google Pay ID",
      name: "gpid",
      value: this.state.gpid,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Mobile Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Mobile Number",
      name: "gpmob",
      value: this.state.gpmob,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "PayTM ID"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "PayTM ID",
      name: "paytmid",
      value: this.state.paytmid,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Mobile Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Mobile Number",
      name: "paytmmob",
      value: this.state.paytmmob,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "PhonePe ID"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "PhonePe ID",
      name: "ppid",
      value: this.state.ppid,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Mobile Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Mobile Number",
      name: "ppmob",
      value: this.state.ppmob,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, this.state.profileExists ? "Update Profile" : "Create Profile"))))));
  }

}

exports.User = User;
var _default = User;
exports.default = _default;