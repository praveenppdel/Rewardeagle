"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.CashOut = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _reactstrap = require("reactstrap");

var _ExportReactCSV = require("../parts/ExportReactCSV");

var _axios = _interopRequireDefault(require("axios"));

var _moment = _interopRequireDefault(require("moment"));

const func = require('../parts/functions');

const secret = require('../parts/secret');

class CashOut extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "handleClick", e => {
      this.setState({
        currentPage: Number(e.target.id)
      });
    });
    (0, _defineProperty2.default)(this, "changeitemsPerPage", e => {
      this.setState({
        itemsPerPage: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "searchSpace", e => {
      this.setState({
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/cashOutRequest');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data,
        loading: false
      }, () => this.getAccessToken());
    });
    (0, _defineProperty2.default)(this, "getAccessToken", () => {
      console.log('getAccessToken called');
      const data = {
        'grant_type': this.state.grant_type,
        'scope': this.state.scope,
        'client_id': this.state.payuClientId,
        'username': this.state.username,
        'password': this.state.password
      };
      console.log(`data`, data);

      _axios.default.post(this.state.accessTokenAPI, data).catch(err => func.printError(err)).then(res => {
        console.log(`res in get accesstoken`, res);
        this.setState({
          access_token: res.data.access_token,
          refresh_token: res.data.refresh_token,
          expires_in: res.data.expires_in
        }, () => this.checkBalance());
      });
    });
    (0, _defineProperty2.default)(this, "checkBalance", () => {
      _axios.default.defaults.headers.common["Authorization"] = `Bearer ${this.state.access_token}`;
      _axios.default.defaults.headers.common["payoutMerchantId"] = this.state.payoutMerchantId;

      _axios.default.get(this.state.getAccountDetail).catch(err => func.printError(err)).then(res => {
        console.log(`res in checkbalance`, res);
        this.setState({
          balance: res.data.data.balance,
          lowBalance: res.data.data.lowBalance
        });
      }); // console.log(`this.state.access_token`, this.state.access_token)
      // console.log(`this.state.payoutMerchantId`, this.state.payoutMerchantId)
      // console.log(`this.state.webhook`, this.state.webhook)
      // console.log(`this.state.webhookData`, this.state.webhookData)


      _axios.default.defaults.headers.common["Authorization"] = `Bearer ${this.state.access_token}`;
      _axios.default.defaults.headers.common["payoutMerchantId"] = this.state.payoutMerchantId;

      _axios.default.post(this.state.webhook, this.state.webhookData).catch(err => func.printError(err)).then(res => {
        console.log(`res in webhook`, res);
        func.callSwal(res.data.msg);
      });
    });
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        addmodalIsOpen: false,
        beneficiary: [],
        idArray: []
      });
    });
    (0, _defineProperty2.default)(this, "refreshTokenAndMakePayment", () => {
      _axios.default.defaults.headers.common["Authorization"] = `Bearer ${this.state.access_token}`;
      _axios.default.defaults.headers.common["payoutMerchantId"] = this.state.payoutMerchantId;
      const data = {
        "grant_type": this.state.grant_refresh_token,
        "client_id": this.state.payuClientId,
        "refresh_token": this.state.refresh_token
      };
      console.log(`data in refreshTokenAndMakePayment`, data);

      _axios.default.post(this.state.accessTokenAPI, data).catch(err => func.printError(err)).then(res => {
        console.log(`res in refreshTokenAndMakePayment`, res);
        this.setState({
          access_token: res.data.access_token,
          refresh_token: res.data.refresh_token,
          expires_in: res.data.expires_in
        }, () => this.makePayment());
      });
    });
    (0, _defineProperty2.default)(this, "makePayment", () => {
      console.log('Making Payment');
      _axios.default.defaults.headers.common["Authorization"] = `Bearer ${this.state.access_token}`;
      _axios.default.defaults.headers.common["payoutMerchantId"] = this.state.payoutMerchantId;

      _axios.default.post(this.state.payOutAPI, this.state.beneficiary).catch(err => func.printError(err)).then(res => {
        console.log(`res in make Payment`, res);
        func.callSwal(res.data.msg);

        if (res.data.status == 0) {
          this.updatePaymentStatus();
        }
      });
    });
    (0, _defineProperty2.default)(this, "updatePaymentStatus", () => {
      const ids = [];
      this.state.idArray.map(i => ids.push(i.id));
      const data = {
        ids: ids,
        id: this.state.idArray,
        merchantrefid: this.state.merchantRefId
      };
      console.log(`data in updatePaymentStatus`, data);

      _axios.default.post("/admin/updatePaymentStatus", data).catch(err => func.printError(err)).then(res => {
        console.log(`res`, res);

        for (let i = 0; i < res.data.data.length; i++) {
          this.setState({
            data: this.state.data.map(x => x.id == parseInt(res.data.data[i].id) ? x = res.data.data[i] : x)
          });
        }

        this.resetData();
      });
    });
    (0, _defineProperty2.default)(this, "addToBeneficiary", (e, i) => {
      if (e.target.checked) {
        const merchantRefId = Date.now();
        this.setState({
          merchantRefId: merchantRefId
        });
        this.setState({
          beneficiary: [...this.state.beneficiary, {
            "beneficiaryAccountNumber": "61234567890",
            "beneficiaryIfscCode": "HDFC0001234",
            "beneficiaryName": i.name,
            "beneficiaryEmail": i.email,
            "beneficiaryMobile": i.phone,
            "purpose": "Cashback from Reward Eagle",
            "amount": i.redeem,
            "batchId": i.userId,
            "merchantRefId": merchantRefId,
            "paymentType": "IMPS",
            "retry": false
          }],
          idArray: [...this.state.idArray, {
            id: i.id,
            userId: i.userId,
            points: i.redeem
          }]
        });
      } else {
        this.setState({
          beneficiary: this.state.beneficiary.filter(j => j.batchId !== i.userId),
          idArray: this.state.idArray.filter(j => j.id !== i.userId)
        });
      }
    });
    (0, _defineProperty2.default)(this, "openModal", () => {
      this.setState({
        addmodalIsOpen: true
      });
    });
    (0, _defineProperty2.default)(this, "changeBeneficiaryAmount", (index, value) => {
      this.state.beneficiary[index].amount = value;
      this.setState({
        beneficiary: this.state.beneficiary
      });
    });
    (0, _defineProperty2.default)(this, "checkDetails", i => {
      console.log(`i`, i);
    });
    this.state = {
      data: [],
      users: [],
      userOptions: [],
      search: '',
      currentPage: 1,
      itemsPerPage: 100,
      loading: false,
      addmodalIsOpen: false,
      payuClientId: secret.payuClientId,
      payuClientSecret: secret.payuClientSecret,
      payoutMerchantId: secret.payoutMerchantId,
      scope: secret.scope,
      grant_type: secret.grant_type,
      accessTokenAPI: secret.accessTokenAPI,
      getAccountDetail: secret.getAccountDetail,
      payOutAPI: secret.payOutAPI,
      webhook: secret.webhook,
      balance: '',
      lowBalance: false,
      beneficiary: [],
      webhookData: secret.webhookData,
      username: secret.username,
      password: secret.password,
      refresh_token: '',
      grant_refresh_token: secret.grant_refresh_token,
      idArray: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    console.log(`this.state`, this.state);
    const {
      currentPage,
      itemsPerPage
    } = this.state;
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const data = this.state.data.filter(i => {
      if (this.state.search == null) return i;else if (i.name.toLowerCase().includes(this.state.search.toLowerCase()) || i.email.toLowerCase().includes(this.state.search.toLowerCase())) {
        return i;
      }
    });
    const renderItems = data.slice(indexOfFirstItem, indexOfLastItem).map((i, index) => {
      return /*#__PURE__*/_react.default.createElement("tr", {
        key: index
      }, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null, i.name, /*#__PURE__*/_react.default.createElement("br", null), i.email, i.phone), /*#__PURE__*/_react.default.createElement("td", null, "Cashback: ", i.cashback, /*#__PURE__*/_react.default.createElement("br", null), "Reward: ", i.reward, /*#__PURE__*/_react.default.createElement("br", null), "Total: ", i.total, /*#__PURE__*/_react.default.createElement("br", null)), /*#__PURE__*/_react.default.createElement("td", null, "Rs.", i.redeem), /*#__PURE__*/_react.default.createElement("td", null, i.status == 0 ? "Pending" : "Done"), /*#__PURE__*/_react.default.createElement("td", null, (0, _moment.default)(i.updated_at).format("DD MMMM  YYYY")), /*#__PURE__*/_react.default.createElement("td", {
        className: "editIcon text-center"
      }, i.status == 0 ? /*#__PURE__*/_react.default.createElement("input", {
        className: "form-control",
        type: "checkbox",
        onChange: e => this.addToBeneficiary(e, i)
      }) : /*#__PURE__*/_react.default.createElement("img", {
        src: "/images/icons/edit.svg",
        alt: "Edit Icon",
        onClick: () => this.checkDetails(i)
      })));
    });
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(this.state.data.length / itemsPerPage); i++) {
      pageNumbers.push(i);
    }

    const renderPagination = pageNumbers.map(number => {
      if (currentPage == number) {
        return /*#__PURE__*/_react.default.createElement("li", {
          key: number,
          id: number,
          onClick: this.handleClick,
          className: "active"
        }, " ", number);
      } else {
        return /*#__PURE__*/_react.default.createElement("li", {
          key: number,
          id: number,
          onClick: this.handleClick
        }, " ", number);
      }
    });
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( Cash Out )"), this.state.balance ? /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "The amount in your account is ", /*#__PURE__*/_react.default.createElement("strong", null, this.state.balance)) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "btn-pag"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "perPage"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("label", null, "Items per page"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      required: true,
      value: itemsPerPage,
      onChange: e => this.changeitemsPerPage(e)
    }, /*#__PURE__*/_react.default.createElement("option", null, itemsPerPage), /*#__PURE__*/_react.default.createElement("option", {
      value: "10"
    }, "10"), /*#__PURE__*/_react.default.createElement("option", {
      value: "25"
    }, "25"), /*#__PURE__*/_react.default.createElement("option", {
      value: "50"
    }, "50"), /*#__PURE__*/_react.default.createElement("option", {
      value: "100"
    }, "100"))), this.state.beneficiary.length && !this.state.lowBalance ? /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      onClick: this.openModal
    }, "Make Payment") : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "search"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex searchInput"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Search Here"), /*#__PURE__*/_react.default.createElement("input", {
      type: "text",
      placeholder: "Search here",
      className: "form-control",
      onChange: e => this.searchSpace(e)
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Page Numbers"), /*#__PURE__*/_react.default.createElement("ul", {
      className: "page-numbers"
    }, renderPagination, " ")))), /*#__PURE__*/_react.default.createElement("table", {
      className: "table"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl No."), /*#__PURE__*/_react.default.createElement("td", null, "User"), /*#__PURE__*/_react.default.createElement("td", null, "Wallet"), /*#__PURE__*/_react.default.createElement("td", null, "Request"), /*#__PURE__*/_react.default.createElement("td", null, "Status"), /*#__PURE__*/_react.default.createElement("td", null, "Date"), /*#__PURE__*/_react.default.createElement("td", null, "Action"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.loading ? /*#__PURE__*/_react.default.createElement("tr", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("td", {
      colSpan: "5",
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    }))) : renderItems)), /*#__PURE__*/_react.default.createElement(_ExportReactCSV.ExportReactCSV, {
      csvData: data,
      fileName: 'Users -' + func.time + '.xls'
    })))), /*#__PURE__*/_react.default.createElement(_Footer.default, null), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.addmodalIsOpen,
      className: "adminModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalHeader, null, " Transfer Cashback Here "), /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, this.state.beneficiary.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "row",
      key: index,
      style: {
        borderBottom: '1px solid red',
        marginBottom: '1em'
      }
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.beneficiaryName,
      readOnly: true
    }), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.beneficiaryEmail,
      readOnly: true
    }), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.beneficiaryMobile,
      readOnly: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.beneficiaryAccountNumber,
      readOnly: true
    }), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.beneficiaryIfscCode,
      readOnly: true
    }), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.paymentType,
      readOnly: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Amount to transfer"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      value: i.amount,
      onChange: e => this.changeBeneficiaryAmount(index, e.target.value)
    })))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      onClick: this.refreshTokenAndMakePayment
    }, "Submit", /*#__PURE__*/_react.default.createElement("span", null))))));
  }

}

exports.CashOut = CashOut;
var _default = CashOut;
exports.default = _default;