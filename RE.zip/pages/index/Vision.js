"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Vision = void 0;

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

class Vision extends _react.Component {
  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("section", {
      className: "about my-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "loader"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loader.gif"
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-9"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "about-content"
    }, /*#__PURE__*/_react.default.createElement("h2", null, "Vision"), /*#__PURE__*/_react.default.createElement("p", null, "We believe that Reward Eagle will be successful in the long term by creating value for its online shoppers and e-commerce merchants. We hope to create a secured employment opportunity. Reward Eagle is a driven portal that aims to set the standards of excellence for multiple solutions of e-commerce & e-recruitment with attractive rewards & complete satisfaction. With the growing number of users and services, we hope that Reward Eagle will earn the trust of more users and keep its existing clientele contented."), /*#__PURE__*/_react.default.createElement("h2", null, "Mission"), /*#__PURE__*/_react.default.createElement("p", null, "We seek to offer the highest quality of customer service provided with a sense of trust, individual pride, warmth & compelling satisfactory shopping experience possible. We want to ignite the opportunity to all our users by using our Reward Eagle service to get benefited with various rewards and suitable employment. We aim to propose the finest online retail services for our business and create a space of best coupons and deals, that will connect online shoppers and e-commerce merchants in India. We also focus on connecting our users with the right companies to achieve their dream jobs and get rewarded simultaneously. Our users can benefit savings through these shopping coupons and also earn extra Reward Points on all their online transactions.")))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.Vision = Vision;
var _default = Vision;
exports.default = _default;