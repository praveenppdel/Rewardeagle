"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.HowItWorks = void 0;

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

class HowItWorks extends _react.Component {
  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("section", {
      className: "about my-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container"
    }, /*#__PURE__*/_react.default.createElement("h1", {
      className: "heading"
    }, "How It Works"), /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "Dear Customer welcome to India\u2019s leading site for online coupons, deals, and discounts- Reward Eagle."), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "loader"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loader.gif"
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-9"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "about-content"
    }, /*#__PURE__*/_react.default.createElement("p", null, "It's just four simple steps"), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, "1. Login"), /*#__PURE__*/_react.default.createElement("li", null, "2. Browse"), /*#__PURE__*/_react.default.createElement("li", null, "3. Shop"), /*#__PURE__*/_react.default.createElement("li", null, "4. Earn ")))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "about-content"
    }, /*#__PURE__*/_react.default.createElement("p", null, "Firstly, all you need to do is login or register yourself with your phone no., gmail or facebook account, and you\u2019re good to go. Then, the next step is that You click on the store's icon on the top and you will see all your favorite brands under each category. You search for your favorite online stores and glance at the best deals and offers available. Once you click a particular store and the deal, you will get redirected to your favorite brand\u2019s website and then you can paste your coupon and enjoy great offers. "), /*#__PURE__*/_react.default.createElement("p", null, "Sit and relax, once the order is placed, we will track your purchase and add reward points or cashbacks to your account. Then all you need to do is repeat the process to earn big rewards and cashbacks. "), /*#__PURE__*/_react.default.createElement("p", null, /*#__PURE__*/_react.default.createElement("strong", null, "Special Deals:"), " For this year we have curated some of the biggest offers and deals with the top brands like Amazon, Flipkart, Myntra, Ajio, Adidas, Dominos, and many more. These offers will satisfy yours and your loved ones needs and desires of a shopping spree. Do follow the above procedure and enjoy deals with Reward Eagle."), /*#__PURE__*/_react.default.createElement("h2", null, "Money Saved is Money earned!"), /*#__PURE__*/_react.default.createElement("p", null, "Once you create an account with us, and make some purchases, we add a few reward points or cashbacks to your RE account. The next step is to unlock an icon of your choice and enjoy great deals and cashbacks. While you keep purchasing with us, your points and level keep increasing and thus you are eligible to earn big rewards."), /*#__PURE__*/_react.default.createElement("h2", null, "Other Features:"), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("strong", null, "1. Search box feature: "), "Here you can search for any of your favorite online stores and explore great deals."), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("strong", null, "2. Shopping Assistant: "), "Our shopping assistant is a guide for you, which helps you navigate the entire process of shopping without any hassle and to enjoy amazing rewards in return. "), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("strong", null, "3. Survey: "), "Our online surveys are created only for you, the sole purpose of it is for you to fill the surveys and redeem cashback and rewards. These surveys also help us to analyze the customer\u2019s perspectives and demands."), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("strong", null, "4. Blogs: "), "We write weekly blogs for you, to explore new trends and shopping deals. The purpose of the blogs are not only to keep you entertained but also help impart more knowledge to you about e-commerce and the cashback world. "), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("strong", null, "5. Career Section: "), "In the career section, we help you explore the \u201Cn\u201D number of Jobs and profiles suitable for you. And then you can start applying."), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("strong", null, "6. Contact: "), "Feel free to contact us and get connected. We would love to hear from you and make your shopping experience the most memorable one. ")), /*#__PURE__*/_react.default.createElement("p", null, "Online shopping offers quick, easy, money saving and interesting shopping encounters. One is benefited at all times, as you do not have to wait in long queues; neither have you to travel places to shop for your favorite stuff. We at Reward Eagle offer the comfort to shop 24 x 7 at your own time and place.")))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.HowItWorks = HowItWorks;
var _default = HowItWorks;
exports.default = _default;