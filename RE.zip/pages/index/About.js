"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.About = void 0;

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

class About extends _react.Component {
  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("section", {
      className: "about my-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "loader"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loader.gif"
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-9"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "about-content"
    }, /*#__PURE__*/_react.default.createElement("h1", null, "Reward Eagle"), /*#__PURE__*/_react.default.createElement("p", null, "Reward Eagle is a Japanese JV enterprise based on the CSV prototype to generate a shared force among the retailers and sponsors. We endeavor to build a shared purpose in our business for the community and clients. Our foray is centered on the immense degree of customer service rendered with discernment of faith, individual dignity, warmth & greater prosperity. "), /*#__PURE__*/_react.default.createElement("p", null, "We are a conglomerate for online polls and study, HR solutions, and online retail shopping with the most suitable bargains and awards accessible. Reward Eagle curates the best deals, coupons, and cashback offers from all top retailers on one platform to customize and reward users' online shopping experience."), /*#__PURE__*/_react.default.createElement("p", null, "Our reward program extends HR results to unite potential employees with job providers. A client can generate, edit, and modify their profile and can apply to positions as and when proposed. We equate our users with the right corporations to attain their ideal careers and get remunerated simultaneously. "), /*#__PURE__*/_react.default.createElement("p", null, "We reward top customers with perks, bonuses, and surprise as they board a new journey with us. Clients can experience gains during the purchasing, coupons and also obtain extra Reward Points on all their purchases, etc. "), /*#__PURE__*/_react.default.createElement("p", null, "For more information and regular updates, kindly sign up and stay tuned to receive our newsletters with exciting deals and offers. ")))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.About = About;
var _default = About;
exports.default = _default;