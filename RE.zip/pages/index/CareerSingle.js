"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.CareerSingle = void 0;

var _react = _interopRequireWildcard(require("react"));

class CareerSingle extends _react.Component {
  render() {
    return /*#__PURE__*/_react.default.createElement("div", null);
  }

}

exports.CareerSingle = CareerSingle;
var _default = CareerSingle;
exports.default = _default;