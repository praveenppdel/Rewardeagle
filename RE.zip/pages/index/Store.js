"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Store = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _StoreSidebar = _interopRequireDefault(require("../parts/StoreSidebar"));

var _moment = _interopRequireDefault(require("moment"));

var _reactstrap = require("reactstrap");

const func = require('../parts/functions');

class Store extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "changeActive", id => {
      this.setState({
        active: id
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const url = window.location.href.split("/").pop();
      const response = await fetch('/storeData/' + url);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);

      if (body.data.length) {
        this.setState({
          coupon: body.data[0],
          couponCopy: body.data[0],
          deal: body.data[1],
          dealCopy: body.data[1],
          store: body.data[2],
          storeData: body.data[3][0]
        }, () => this.setAll());
      }

      if (url != 'stores') {
        const response2 = await fetch('/admin/checkStoreUrl/' + url);
        const body2 = await response2.json();
        if (response2.status !== 200) throw Error(body2.message);

        if (body2.storeData.length) {
          this.setState({
            singleStore: body2.storeData[0]
          });
        }
      }
    });
    (0, _defineProperty2.default)(this, "showData", index => {
      if (index === this.state.activeEl) {
        this.setState({
          activeEl: ''
        });
      } else {
        this.setState({
          activeEl: index
        });
      }
    });
    (0, _defineProperty2.default)(this, "timeout", delay => {
      return new Promise(res => setTimeout(res, delay));
    });
    (0, _defineProperty2.default)(this, "redirectMerchant", async (i, type) => {
      if (this.state.user.role) {
        if (i.tlink) {
          this.setState({
            redirectModal: true,
            merchant: i,
            merchantType: type
          }); // await this.timeout(3000);
          // this.setState({ 
          //     redirectModal:              false,
          //     merchant:                   ''
          // })

          var win = window.open(i.tlink, '_blank');
          win.focus();
        }
      } else {
        localStorage.setItem('message', 'Please login to continue');
        localStorage.setItem('redirectTo', window.location.pathname);
        window.location.href = '/login';
      }
    });
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        redirectModal: false,
        merchant: ''
      });
    });
    (0, _defineProperty2.default)(this, "renderCoupon", (i, index) => {
      return /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", {
        className: "cdBox"
      }, /*#__PURE__*/_react.default.createElement("div", {
        className: index === this.state.activeEl && i.discription || index === this.state.activeEl && i.tnc ? "resetcdBox" : ""
      }, /*#__PURE__*/_react.default.createElement("section", {
        className: "not-found-controller cashBackData",
        dangerouslySetInnerHTML: {
          __html: i.cashback
        },
        onClick: () => this.redirectMerchant(i, "coupon")
      }), /*#__PURE__*/_react.default.createElement("div", {
        className: "cdText"
      }, /*#__PURE__*/_react.default.createElement("h3", {
        onClick: () => this.redirectMerchant(i, "coupon")
      }, i.title), /*#__PURE__*/_react.default.createElement("p", null, "Expires on ", (0, _moment.default)(i.expiry).format("DD MMMM  YYYY")), /*#__PURE__*/_react.default.createElement("div", {
        className: "showMore"
      }, /*#__PURE__*/_react.default.createElement("div", {
        className: "offer mr-3",
        onClick: () => this.redirectMerchant(i, "coupon")
      }, /*#__PURE__*/_react.default.createElement("p", null, i.offer)), /*#__PURE__*/_react.default.createElement("span", {
        onClick: () => this.showData(index)
      }, " ", index === this.state.activeEl && i.discription || index === this.state.activeEl && i.tnc ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("i", {
        className: "fa fa-arrow-up"
      }), "Show Less") : /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("i", {
        className: "fa fa-arrow-down"
      }), "Show More"))))), index === this.state.activeEl && i.discription ? /*#__PURE__*/_react.default.createElement("p", {
        className: "desc"
      }, /*#__PURE__*/_react.default.createElement("strong", null, "Description"), /*#__PURE__*/_react.default.createElement("br", null), i.discription) : null, index === this.state.activeEl && i.tnc ? /*#__PURE__*/_react.default.createElement("p", {
        className: "desc"
      }, /*#__PURE__*/_react.default.createElement("strong", null, "Terms & Conditions"), /*#__PURE__*/_react.default.createElement("br", null), i.tnc) : null), /*#__PURE__*/_react.default.createElement("img", {
        src: "/images/icons/scissor-red.svg",
        className: "scissor"
      }));
    });
    (0, _defineProperty2.default)(this, "renderDeal", (i, index) => {
      return /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", {
        className: "cdBox"
      }, /*#__PURE__*/_react.default.createElement("div", {
        className: index === this.state.activeEl && i.discription || index === this.state.activeEl && i.tnc ? "resetcdBox" : ""
      }, /*#__PURE__*/_react.default.createElement("section", {
        className: "not-found-controller cashBackData",
        onClick: () => this.redirectMerchant(i, "deal"),
        dangerouslySetInnerHTML: {
          __html: i.percent
        }
      }), /*#__PURE__*/_react.default.createElement("div", {
        className: "cdText"
      }, /*#__PURE__*/_react.default.createElement("h3", {
        onClick: () => this.redirectMerchant(i, "deal")
      }, i.title), /*#__PURE__*/_react.default.createElement("p", null, "Expires on ", (0, _moment.default)(i.expiry).format("DD MMMM  YYYY")), /*#__PURE__*/_react.default.createElement("div", {
        className: "showMore"
      }, /*#__PURE__*/_react.default.createElement("div", {
        className: "offerDeal mr-3",
        onClick: () => this.redirectMerchant(i, "deal")
      }, /*#__PURE__*/_react.default.createElement("p", null, "Get the Deal")), /*#__PURE__*/_react.default.createElement("span", {
        onClick: () => this.showData(index)
      }, index === this.state.activeEl && i.discription || index === this.state.activeEl && i.tnc ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("i", {
        className: "fa fa-arrow-up"
      }), "Show Less") : /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("i", {
        className: "fa fa-arrow-down"
      }), "Show More"))), index == this.state.active ? /*#__PURE__*/_react.default.createElement("p", {
        className: "desc"
      }, i.cutoff) : null)), index === this.state.activeEl && i.discription ? /*#__PURE__*/_react.default.createElement("p", {
        className: "desc"
      }, /*#__PURE__*/_react.default.createElement("strong", null, "Description"), /*#__PURE__*/_react.default.createElement("br", null), i.discription) : null, index === this.state.activeEl && i.tnc ? /*#__PURE__*/_react.default.createElement("p", {
        className: "desc"
      }, /*#__PURE__*/_react.default.createElement("strong", null, "Terms & Conditions"), /*#__PURE__*/_react.default.createElement("br", null), i.tnc) : null), /*#__PURE__*/_react.default.createElement("img", {
        src: "/images/icons/scissor-red.svg",
        className: "scissor"
      }));
    });
    (0, _defineProperty2.default)(this, "callbackFunction", (childData1, childData2) => {
      this.setState({
        catSelected: childData1,
        storeSelected: childData2
      }, () => this.filterData());
    });
    (0, _defineProperty2.default)(this, "filterData", () => {
      if (!this.state.catSelected.length && !this.state.storeSelected.length) {
        this.resetAll();
      } else {
        if (this.state.catSelected.length) {
          this.setState({
            coupon: this.state.couponCopy.filter(i => this.state.catSelected.includes(i.category)),
            deal: this.state.dealCopy.filter(i => this.state.catSelected.includes(i.category))
          }, () => this.setAll());
        }
      }
    });
    (0, _defineProperty2.default)(this, "resetAll", () => {
      this.setState({
        coupon: this.state.couponCopy,
        deal: this.state.dealCopy,
        all: [...this.state.couponCopy, ...this.state.dealCopy].map(a => ({
          sort: Math.random(),
          value: a
        })).sort((a, b) => a.sort - b.sort).map(a => a.value)
      });
    });
    (0, _defineProperty2.default)(this, "setAll", () => {
      this.setState({
        all: [...this.state.coupon, ...this.state.deal].map(a => ({
          sort: Math.random(),
          value: a
        })).sort((a, b) => a.sort - b.sort).map(a => a.value)
      });
    });
    (0, _defineProperty2.default)(this, "copyText", () => {
      navigator.clipboard.writeText(this.state.merchant.offer);
      func.callSwal("Code Copied Successfully");
    });
    this.state = {
      storeData: this.props.storeData,
      coupon: this.props.coupon,
      deal: this.props.deal,
      store: this.props.store,
      singleStore: this.props.singleStore,
      all: [],
      active: 'all',
      // show:                   '',
      catSelected: [],
      storeSelected: [],
      couponCopy: [],
      dealCopy: [],
      activeEl: '',
      user: [],
      redirectModal: false,
      merchant: '',
      merchantType: ''
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      });
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_StoreSidebar.default, {
      parentCallback: this.callbackFunction
    }), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-9"
    }, this.state.storeData ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.singleStore ? /*#__PURE__*/_react.default.createElement("div", {
      className: "mobile w-100"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "activateRewards"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + this.state.singleStore.logo
    }))) : null, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading my-0"
    }, this.state.storeData.name), /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, this.state.storeData.title), this.state.singleStore ? /*#__PURE__*/_react.default.createElement("div", {
      className: "mobile w-100"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "activateRewards"
    }, /*#__PURE__*/_react.default.createElement("button", {
      onClick: () => this.redirectMerchant(this.state.singleStore, "store"),
      className: "casleyBtn"
    }, "Activate Rewards"))) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "row listFilter"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "recomStore col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "headUl"
    }, /*#__PURE__*/_react.default.createElement("ul", null, this.state.coupon && this.state.coupon.length || this.state.deal && this.state.deal.length ? /*#__PURE__*/_react.default.createElement("li", {
      className: this.state.active == 'all' ? 'active' : null,
      onClick: () => this.changeActive('all')
    }, "All ", /*#__PURE__*/_react.default.createElement("span", null, "(", this.state.coupon.length + this.state.deal.length, ")")) : null, this.state.coupon && this.state.coupon.length ? /*#__PURE__*/_react.default.createElement("li", {
      className: this.state.active == 'coupon' ? 'active' : null,
      onClick: () => this.changeActive('coupon')
    }, "Coupon ", /*#__PURE__*/_react.default.createElement("span", null, "(", this.state.coupon.length, ")")) : null, this.state.deal && this.state.deal.length ? /*#__PURE__*/_react.default.createElement("li", {
      className: this.state.active == 'deal' ? 'active' : null,
      onClick: () => this.changeActive('deal')
    }, "Deal ", /*#__PURE__*/_react.default.createElement("span", null, "(", this.state.deal.length, ")")) : null), /*#__PURE__*/_react.default.createElement("ul", null, this.state.store && this.state.store.length ? /*#__PURE__*/_react.default.createElement("li", {
      className: "storeImg"
    }, /*#__PURE__*/_react.default.createElement("small", {
      className: "text"
    }, "Recommended Stores"), /*#__PURE__*/_react.default.createElement("div", null, this.state.store.map((i, index) => /*#__PURE__*/_react.default.createElement("span", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + i.url
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + i.logo
    })))))) : null)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "dealData"
    }, this.state.active == 'all' && this.state.all ? /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, this.state.all.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.all.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6",
      key: index
    }, i.type == 'coupon' ? this.renderCoupon(i, index) : i.type == 'deal' ? this.renderDeal(i, index) : null))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "w-100"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "No Products for these filters"))) : this.state.active == 'coupon' && this.state.coupon ? /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, this.state.coupon.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.coupon.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6",
      key: index
    }, this.renderCoupon(i, index)))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "w-100"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "No Products for these filters"))) : this.state.active == 'deal' && this.state.deal ? /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, this.state.deal.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.deal.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6",
      key: index
    }, this.renderDeal(i, index)))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "w-100"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "No Products for these filters"))) : null)) : null // <>
    //     <h2 className="heading">Empty Store</h2>
    //     <p className="text-center">We are yet to fill this store. Meanwhile do check other stores.</p>
    // </>
    ))), /*#__PURE__*/_react.default.createElement(_Footer.default, null), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.redirectModal,
      className: "adminModal redirectModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("div", {
      className: "topOffer"
    }, this.state.merchantType == 'coupon' ? /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("section", {
      className: "not-found-controller cashBackData",
      dangerouslySetInnerHTML: {
        __html: this.state.merchant.cashback
      }
    }), /*#__PURE__*/_react.default.createElement("p", {
      className: "cCode"
    }, "Coupon Code ", /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("span", null, this.state.merchant.offer)), /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      onClick: this.copyText
    }, "Copy Code")) : this.state.merchantType == 'deal' ? /*#__PURE__*/_react.default.createElement("div", {
      className: "cashBackData"
    }, /*#__PURE__*/_react.default.createElement("h3", null, /*#__PURE__*/_react.default.createElement("span", null, "Deal Activated. "), " No coupon code required")) : this.state.merchantType == 'store' ? /*#__PURE__*/_react.default.createElement("div", {
      className: "cashBackData"
    }, /*#__PURE__*/_react.default.createElement("h3", null, /*#__PURE__*/_react.default.createElement("span", null, "Rewards Activated. "), " No code required")) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X")), /*#__PURE__*/_react.default.createElement("div", {
      className: "eagle"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/logo-red.gif"
    }), /*#__PURE__*/_react.default.createElement("span", null, " ", '>', " "), /*#__PURE__*/_react.default.createElement("span", null, " ", '>', " "), /*#__PURE__*/_react.default.createElement("span", null, " ", '>', " "), this.state.merchantType == 'coupon' || this.state.merchantType == 'deal' ? /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + this.state.merchant.storeLogo
    }) : this.state.merchantType == 'store' ? /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + this.state.singleStore.logo
    }) : null), /*#__PURE__*/_react.default.createElement("p", {
      style: {
        'color': 'red'
      }
    }, "Redirected. Deal Activated!"), /*#__PURE__*/_react.default.createElement("p", null, this.state.merchant.title))));
  }

}

exports.Store = Store;
var _default = Store;
exports.default = _default;