"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Index = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _Brands = _interopRequireDefault(require("../parts/Brands"));

var _NewsLetter = _interopRequireDefault(require("../parts/NewsLetter"));

var _RecommendedAds = _interopRequireDefault(require("../parts/RecommendedAds"));

var _SignUp = _interopRequireDefault(require("../parts/SignUp"));

var _reactIdSwiper = _interopRequireDefault(require("react-id-swiper"));

var _global = _interopRequireDefault(require("global"));

const func = require('../parts/functions');

class Index extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/homeData');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        slider: body.slider.filter(i => i.type == 'Carousel'),
        snowfall: body.slider.filter(i => i.type == 'SnowFall'),
        category: body.category,
        store: body.store,
        deal: body.deal,
        coupon: body.coupon,
        activeCat: [body.category[0].id, body.category[1].id],
        activeCatIndex: [0, 1],
        ads: body.ads,
        special: body.special,
        weeklyStore: body.weeklyStore,
        tag: body.tag,
        specialSlider: body.ads.filter(i => i.type == 6)
      });
      const one = [];
      const two = [];
      const three = [];
      const four = [];
      body.coupon.forEach(i => {
        if (JSON.parse(i.tags).includes(1)) {
          one.push(i);
        }

        if (JSON.parse(i.tags).includes(2)) {
          two.push(i);
        }

        if (JSON.parse(i.tags).includes(11)) {
          three.push(i);
        }

        if (JSON.parse(i.tags).includes(4)) {
          four.push(i);
        }
      });
      this.setState({
        recommended: one,
        // special:            two,
        staff: three,
        daily: four,
        loading: true
      });

      if (body.tagline.length) {
        this.setState({
          tagline: body.tagline[0].name
        });
      }

      if (body.jhalar.length) {
        this.setState({
          jhalar: body.jhalar[0].name
        });
      }
    });
    (0, _defineProperty2.default)(this, "activeDouble", id => {
      const index = this.state.category.map(e => e.id).indexOf(id);

      if (index < this.state.category.length - 1) {
        this.setState({
          activeCat: [this.state.category[index].id, this.state.category[index + 1].id],
          activeCatIndex: [index, index + 1]
        });
      } else {
        this.setState({
          activeCat: [this.state.category[index - 1].id, this.state.category[index].id],
          activeCatIndex: [index - 1, index]
        });
      }

      if (index == this.state.end - 1 && index < this.state.category.length - 1) {
        if (index + this.state.end - this.state.start < this.state.category.length - 1) {
          this.setState({
            start: index,
            end: index + this.state.end - this.state.start
          });
        } else {
          this.setState({
            start: this.state.category.length - this.state.end + this.state.start,
            end: this.state.category.length
          });
        }
      }
    });
    (0, _defineProperty2.default)(this, "showHow", () => {
      this.setState({
        showHow: true
      });
    });
    (0, _defineProperty2.default)(this, "hideHow", () => {
      this.setState({
        showHow: false
      });
    });
    (0, _defineProperty2.default)(this, "changeStart", () => {
      if (this.state.activeCatIndex[0] > 0) {
        this.setState({
          activeCatIndex: [this.state.activeCatIndex[0] - 1, this.state.activeCatIndex[1] - 1],
          activeCat: [this.state.category[this.state.activeCatIndex[0] - 1].id, this.state.category[this.state.activeCatIndex[1] - 1].id]
        });

        if (this.state.start > 0) {
          this.setState({
            start: this.state.start - 1,
            end: this.state.end - 1
          });
        }
      }
    });
    (0, _defineProperty2.default)(this, "changeEnd", () => {
      if (this.state.category.length - 1 > this.state.activeCatIndex[1]) {
        this.setState({
          activeCatIndex: [this.state.activeCatIndex[0] + 1, this.state.activeCatIndex[1] + 1],
          activeCat: [this.state.category[this.state.activeCatIndex[0] + 1].id, this.state.category[this.state.activeCatIndex[1] + 1].id]
        });

        if (this.state.end < this.state.category.length) {
          this.setState({
            start: this.state.start + 1,
            end: this.state.end + 1
          });
        }
      }
    });
    (0, _defineProperty2.default)(this, "stopSlider", () => {
      this.setState({
        videoOn: true
      });
    });
    this.state = {
      slider: this.props.slider,
      category: this.props.category,
      store: this.props.store,
      deal: this.props.deal,
      coupon: this.props.coupon,
      weeklyStore: this.props.weeklyStore,
      tag: '',
      activeCat: [],
      activeCatIndex: [0, 1],
      ads: this.props.ads,
      recommended: [],
      special: [],
      staff: [],
      daily: [],
      specialSlider: [],
      showHow: false,
      start: 0,
      end: 10,
      snowfall: [],
      videoOn: false,
      tagline: "",
      jhalar: "",
      loading: false
    };
  }

  componentDidMount() {
    _global.default.scrollTo(0, 0);

    this.callApi();

    if (_global.default.innerWidth > 1500) {
      this.setState({
        end: 10
      });
    }

    if (_global.default.innerWidth > 1200 && _global.default.innerWidth < 1500) {
      this.setState({
        end: 7
      });
    }

    if (_global.default.innerWidth > 991 && _global.default.innerWidth < 1200) {
      this.setState({
        end: 5
      });
    }

    if (_global.default.innerWidth < 991) {
      this.setState({
        end: 4
      });
    }
  }

  render() {
    const paramSlider = {
      observer: true,
      observeParents: true,
      slidesPerView: 1,
      spaceBetween: 10,
      loop: true,
      // autoplay: !this.state.videoOn? { delay: 3000, disableOnInteraction: true } : false,
      autoplay: {
        delay: 3000,
        disableOnInteraction: true
      },
      breakpoints: {
        320: {
          slidesPerView: 1,
          spaceBetween: 5
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20
        }
      },
      // noSwiping: true,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev'
      },
      slidesPerView: "auto" // on: {
      //     click: function () {
      //         this.swiper.autoplay.stop()
      //     },
      //     MouseEvent: function (e) {
      //         swiper.autoplay.stop()
      //     },
      // }

    };
    const dealArray = [];

    if (this.state.deal && this.state.deal.length) {
      for (let i = 1; i < this.state.deal.length; i = i + 4) {
        dealArray.push([i, i + 1, i + 2, i + 3]);
      }
    }

    const couponArray = [];

    if (this.state.coupon && this.state.coupon.length) {
      for (let i = 1; i < this.state.coupon.length; i = i + 4) {
        couponArray.push([i, i + 1, i + 2, i + 3]);
      }
    } // const catArray  = []; if(this.state.category && this.state.category.length){ for (let i = 1; i < this.state.category.length; i = i+4) { catArray.push([i,i+1,i+2, i+3]); } }
    // const storeArray = []; if(this.state.store && this.state.store.length){ for (let i = 1; i < this.state.store.length; i = i+4) { storeArray.push([i,i+1,i+2, i+3]); } }


    const specialArray = [];

    if (this.state.specialSlider && this.state.specialSlider.length) {
      for (let i = 1; i < this.state.specialSlider.length; i = i + 4) {
        specialArray.push([i, i + 1, i + 2, i + 3]);
      }
    }

    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, !this.state.loading ? /*#__PURE__*/_react.default.createElement("div", {
      className: "fullLoading"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loader.gif"
    })) : /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.snowfall.length && parseInt(this.state.snowfall[0].name) === 1 ? /*#__PURE__*/_react.default.createElement("div", {
      id: "snowflakes-container"
    }) : null, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 1).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))) : null, /*#__PURE__*/_react.default.createElement(_Header.default, null), this.state.jhalar ? /*#__PURE__*/_react.default.createElement("div", {
      className: "jhalar",
      style: {
        backgroundImage: `url(/images/basic/${this.state.jhalar})`,
        height: "30px"
      }
    }) : null, this.state.slider && this.state.slider.length ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "banner"
    }, /*#__PURE__*/_react.default.createElement("h1", null, this.state.tagline ? this.state.tagline : null), /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, (0, _extends2.default)({}, paramSlider, {
      className: "xx"
    }), this.state.slider.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index,
      onClick: () => this.stopSlider()
    }, i.tab3 == 0 ? /*#__PURE__*/_react.default.createElement("a", {
      href: i.tab2,
      target: i.tab1 == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "images/basic/" + i.name,
      alt: ""
    })) : /*#__PURE__*/_react.default.createElement("video", {
      controls: true
    }, /*#__PURE__*/_react.default.createElement("source", {
      src: "images/basic/" + i.name,
      type: "video/mp4"
    }))))))) : null, this.state.category && this.state.category.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid categories imgExpand"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, func.paramsCatsNStore, this.state.category.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/storeCategory/" + i.url
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "images/category/icon/" + i.icon,
      alt: ""
    }), /*#__PURE__*/_react.default.createElement("p", null, i.name))))))))) : null, this.state.store && this.state.store.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid bgGrey categories storeSwiper imgExpand"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, func.paramsVerySlow, this.state.store.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + i.url
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "images/store/logo/" + i.logo,
      alt: ""
    }))))))))) : null, /*#__PURE__*/_react.default.createElement("section", {
      className: "how"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container howItWorks"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web flex-h"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 23).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-8"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "How It ", /*#__PURE__*/_react.default.createElement("span", null, "Works")), /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "Are you new on Reward Eagle?")), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web flex-h"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 24).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))) : null)), /*#__PURE__*/_react.default.createElement("div", {
      className: this.state.showHow ? "row showHow" : "row hideHow"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/browse.svg"
    })), /*#__PURE__*/_react.default.createElement("h3", null, "Browse"), /*#__PURE__*/_react.default.createElement("p", null, "Find your favourite online stores. Browse through popular brands for great deals and offers.")), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/cart-grey.svg"
    })), /*#__PURE__*/_react.default.createElement("h3", null, "Shop"), /*#__PURE__*/_react.default.createElement("p", null, "Get redirected to your favourite online store\u2019s website or app. Paste your coupon and enjoy active deals.")), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/earn.svg"
    })), /*#__PURE__*/_react.default.createElement("h3", null, "Earn"), /*#__PURE__*/_react.default.createElement("p", null, "Shop through us and Relax. We will track your purchase and add rewards to your account."))), this.state.showHow ? /*#__PURE__*/_react.default.createElement("div", {
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "button kohei",
      onClick: this.hideHow
    }, "Show Less")) : /*#__PURE__*/_react.default.createElement("div", {
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "button kohei",
      onClick: this.showHow
    }, "Know more")))), /*#__PURE__*/_react.default.createElement("section", {
      className: "offers"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-1 web",
      style: {
        paddingRight: 0
      }
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 2).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image,
      key: index
    })))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 topNav topNavOffer"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "shopHead"
    }, " Offers of ", /*#__PURE__*/_react.default.createElement("span", null, "the day")), dealArray.length ? /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, func.params, dealArray.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index,
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, [0, 1, 2, 3].map((j, index2) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3",
      key: index2
    }, this.state.deal[i[j]] ? /*#__PURE__*/_react.default.createElement("div", {
      className: "dealDetail"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + this.state.deal[i[j]].storeUrl
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "offerHead"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "festText"
    }, /*#__PURE__*/_react.default.createElement("h3", null, this.state.deal[i[j]].offday ? this.state.deal[i[j]].offday : "Off the Day")), /*#__PURE__*/_react.default.createElement("div", {
      className: "slashPrice"
    }, /*#__PURE__*/_react.default.createElement("small", null, "Upto ", this.state.deal[i[j]].cutoff, "% Off"), /*#__PURE__*/_react.default.createElement("p", null, "Upto ", this.state.deal[i[j]].current_value, "% Off"))), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + this.state.deal[i[j]].storeLogo
    }), /*#__PURE__*/_react.default.createElement("h4", null, this.state.deal[i[j]].title), /*#__PURE__*/_react.default.createElement("p", null, this.state.deal[i[j]].tagline), /*#__PURE__*/_react.default.createElement("p", {
      className: "offerCount"
    }, this.state.deal[i[j]].offer_count, " Offers"))) : null)))))) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/deals",
      className: "button kohei"
    }, "View All"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 topNav topNavCoupon"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "shopHead"
    }, " Coupons of ", /*#__PURE__*/_react.default.createElement("span", null, "the day")), couponArray.length && this.state.coupon.length >= 4 ? /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, func.params, couponArray.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index,
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, [0, 1, 2, 3].map((j, index2) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 mb-3",
      key: index2
    }, this.state.coupon[i[j]] ? /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + this.state.coupon[i[j]].storeUrl
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/coupon/" + this.state.coupon[i[j]].image
    }), /*#__PURE__*/_react.default.createElement("h3", {
      className: "title"
    }, this.state.coupon[i[j]].storeTitle), /*#__PURE__*/_react.default.createElement("div", {
      className: "couponDetail"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn"
    }, "Coupon"), /*#__PURE__*/_react.default.createElement("section", {
      className: "not-found-controller",
      dangerouslySetInnerHTML: {
        __html: this.state.coupon[i[j]].cashback
      }
    }), /*#__PURE__*/_react.default.createElement("p", null, this.state.coupon[i[j]].title), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/scissor.svg",
      className: "scissor"
    })))) : null)))))) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/deals",
      className: "button kohei"
    }, "View All")))))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-1 web",
      style: {
        paddingLeft: 0
      }
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 3).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))) : null)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid dailyRanking mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web flex-h"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 25).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-8 weeklyTop"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, " ", /*#__PURE__*/_react.default.createElement("span", null, "Weekly Top "), " Ranking Stores"), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/leftArrowRed.svg",
      className: "startArrow",
      onClick: this.changeStart
    }), this.state.category && this.state.category.length ? /*#__PURE__*/_react.default.createElement("ul", {
      className: "doubleList"
    }, this.state.category.slice(this.state.start, this.state.end).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index,
      className: this.state.activeCat.some(el => el == i.id) ? 'active active-' + this.state.activeCat.indexOf(i.id) : null,
      onClick: () => this.activeDouble(i.id)
    }, i.name))) : null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/rightArrowRed.svg",
      className: "endArrow",
      onClick: this.changeEnd
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web flex-h"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 26).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 7 || i.type == 8).slice(0, 2).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image,
      key: index,
      className: index == 0 ? "mb-3" : null
    })))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-8 doubleListdata"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row web"
    }, this.state.coupon && this.state.coupon.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("h2", null, this.state.category[this.state.activeCatIndex[0]].name), /*#__PURE__*/_react.default.createElement("ul", null, this.state.weeklyStore.filter(i => JSON.parse(i.category).includes(this.state.activeCat[0])).slice(0, 5).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + i.url
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "topTag"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", {
      className: "rank"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/rank" + index + ".png"
    })), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + i.logo
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "tagline"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/banner/" + i.banner
    }), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("p", null, i.tagline), /*#__PURE__*/_react.default.createElement("p", null, i.salesline)), /*#__PURE__*/_react.default.createElement("h3", null, /*#__PURE__*/_react.default.createElement("span", null, "Upto ", i.cashback, " Off"))))))))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("h2", null, this.state.category[this.state.activeCatIndex[1]].name), /*#__PURE__*/_react.default.createElement("ul", null, this.state.weeklyStore.filter(i => JSON.parse(i.category).includes(this.state.activeCat[1])).slice(0, 5).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + i.url
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "topTag"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", {
      className: "rank"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/rank" + index + ".png"
    })), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + i.logo
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "tagline"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/banner/" + i.banner
    }), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("p", null, i.tagline), /*#__PURE__*/_react.default.createElement("p", null, i.salesline)), /*#__PURE__*/_react.default.createElement("h3", null, /*#__PURE__*/_react.default.createElement("span", null, "Upto ", i.cashback, " Off")))))))))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "row mobile"
    }, this.state.coupon && this.state.coupon.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("h2", null, this.state.category[this.state.activeCatIndex[0]].name), /*#__PURE__*/_react.default.createElement("ul", null, this.state.weeklyStore.filter(i => JSON.parse(i.category).includes(this.state.activeCat[0])).slice(0, 5).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + i.url
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + i.logo,
      className: "logoImage"
    }), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("p", null, i.tagline), /*#__PURE__*/_react.default.createElement("h3", null, /*#__PURE__*/_react.default.createElement("span", null, "Upto ", i.cashback, " Off")))), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/rank" + index + ".png",
      className: "rank"
    }))))))) : null)), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 right-side web"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 9).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image,
      key: index
    })))) : null))), this.state.ads ? /*#__PURE__*/_react.default.createElement("div", {
      className: "banner my-5"
    }, /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, func.params, this.state.ads.filter(i => i.type == 22).slice(0, 3).map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image,
      alt: ""
    })))))) : null, /*#__PURE__*/_react.default.createElement("section", {
      className: "greyBg staffRecommended mt-3"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, /*#__PURE__*/_react.default.createElement("span", null, "Reward Eagle "), " Collections"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 4).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image,
      key: index
    })))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-8 web",
      style: {
        padding: 0
      }
    }, this.state.staff ? /*#__PURE__*/_react.default.createElement("ul", null, this.state.staff.slice(0, 6).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "couponImg"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/coupon/" + i.image
    }), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("p", null, i.title), /*#__PURE__*/_react.default.createElement("section", {
      className: "not-found-controller",
      dangerouslySetInnerHTML: {
        __html: i.cashback
      }
    }))), /*#__PURE__*/_react.default.createElement("button", null, "Redeem Coupon"))))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-8 mobile"
    }, this.state.staff ? /*#__PURE__*/_react.default.createElement("ul", null, this.state.staff.slice(0, 6).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      className: "card"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "couponImg mb-3"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("p", null, i.title), /*#__PURE__*/_react.default.createElement("h3", null, i.storeTitle)), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + i.storeLogo
    })), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("section", {
      className: "not-found-controller",
      dangerouslySetInnerHTML: {
        __html: i.cashback
      }
    }), /*#__PURE__*/_react.default.createElement("button", null, "Redeem Coupon"))))))) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 web"
    }, this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.ads.filter(i => i.type == 5).slice(0, 1).map((i, index) => /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : "",
      key: index
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image,
      key: index
    })))) : null)))), /*#__PURE__*/_react.default.createElement(_SignUp.default, null), this.state.ads ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("section", {
      className: "recommended bgGrey"
    }, this.state.ads.filter(i => i.type == 6).length ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container py-3"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Special ", /*#__PURE__*/_react.default.createElement("span", null, "Offers")), /*#__PURE__*/_react.default.createElement("div", {
      className: "row web"
    }, this.state.ads.filter(i => i.type == 6).slice(0, 8).map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3 mb-3",
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))))) : null, /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid doubleSwiper specialMobile imgExpand mobile"
    }, /*#__PURE__*/_react.default.createElement(_reactIdSwiper.default, func.paramsDouble, specialArray.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "row " + index,
      key: index
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, this.state.specialSlider[i[0]] ? /*#__PURE__*/_react.default.createElement("a", {
      href: this.state.specialSlider[i[0]].url,
      target: this.state.specialSlider[i[0]].target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + this.state.specialSlider[i[0]].image
    })) : null, this.state.specialSlider[i[1]] ? /*#__PURE__*/_react.default.createElement("a", {
      href: this.state.specialSlider[i[1]].url,
      target: this.state.specialSlider[i[1]].target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + this.state.specialSlider[i[1]].image
    })) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, this.state.specialSlider[i[2]] ? /*#__PURE__*/_react.default.createElement("a", {
      href: this.state.specialSlider[i[2]].url,
      target: this.state.specialSlider[i[2]].target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + this.state.specialSlider[i[2]].image
    })) : null, this.state.specialSlider[i[3]] ? /*#__PURE__*/_react.default.createElement("a", {
      href: this.state.specialSlider[i[3]].url,
      target: this.state.specialSlider[i[3]].target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + this.state.specialSlider[i[3]].image
    })) : null))))))) : null, this.state.ads ? /*#__PURE__*/_react.default.createElement(_RecommendedAds.default, {
      title: "New deals Onboard",
      ads: this.state.ads
    }) : null, /*#__PURE__*/_react.default.createElement(_NewsLetter.default, null), /*#__PURE__*/_react.default.createElement(_Brands.default, null), /*#__PURE__*/_react.default.createElement(_Footer.default, null)));
  }

}

exports.Index = Index;
var _default = Index;
exports.default = _default;