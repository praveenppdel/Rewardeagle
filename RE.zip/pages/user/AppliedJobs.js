"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.AppliedJobs = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _UserBar = _interopRequireDefault(require("../parts/UserBar"));

var _moment = _interopRequireDefault(require("moment"));

class AppliedJobs extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "handleClick", e => {
      this.setState({
        currentPage: Number(e.target.id)
      });
    });
    (0, _defineProperty2.default)(this, "changeitemsPerPage", e => {
      this.setState({
        itemsPerPage: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "searchSpace", e => {
      this.setState({
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/userAppliedJobs/' + this.state.user.id);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data,
        jobs: body.jobs,
        loading: false
      });
    });
    this.state = {
      data: [],
      jobs: [],
      loading: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      }, () => this.callApi());
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), !this.state.loading ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container admin mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_UserBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Applied Jobs"), this.state.data.length ? /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "You applied to the below job openings") : /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "You haven't applied to any job openings"), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/career",
      className: "casleyBtn"
    }, "Go to career Page"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 career"
    }, /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl no."), /*#__PURE__*/_react.default.createElement("td", null, "Date"), /*#__PURE__*/_react.default.createElement("td", null, "Company"), /*#__PURE__*/_react.default.createElement("td", null, "Designation"), /*#__PURE__*/_react.default.createElement("td", null, "Status"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.data.map((i, index) => /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null), /*#__PURE__*/_react.default.createElement("td", null, "Casley India Pvt Ltd "), /*#__PURE__*/_react.default.createElement("td", null, i.role), /*#__PURE__*/_react.default.createElement("td", null, "Applied"))))))), /*#__PURE__*/_react.default.createElement("h3", null, "Latest Jobs"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row latestJobs"
    }, this.state.jobs.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      key: index,
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/career"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "card"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/casley.png"
    }), /*#__PURE__*/_react.default.createElement("p", null, /*#__PURE__*/_react.default.createElement("span", null, "Position:"), "  ", i.role), /*#__PURE__*/_react.default.createElement("p", null, /*#__PURE__*/_react.default.createElement("span", null, "Location:"), "  ", i.location))))))))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    })), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.AppliedJobs = AppliedJobs;
var _default = AppliedJobs;
exports.default = _default;