"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.CashbackReward = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _UserBar = _interopRequireDefault(require("../parts/UserBar"));

var _moment = _interopRequireDefault(require("moment"));

var _axios = _interopRequireDefault(require("axios"));

var _reactstrap = require("reactstrap");

const func = require('../parts/functions');

class CashbackReward extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/userAccounts/' + this.state.user.id);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data,
        loading: false
      });
    });
    (0, _defineProperty2.default)(this, "changeActive", value => {
      this.setState({
        active: value
      });

      if (this.state.data.reward) {
        if (value == "All") {
          this.setState({
            count: this.state.countCopy
          });
        }

        if (value == "Unlocked") {
          this.setState({
            count: this.state.countCopy.filter(i => i.points < this.state.data.reward)
          });
        }

        if (value == "Locked") {
          this.setState({
            count: this.state.countCopy.filter(i => i.points > this.state.data.reward)
          });
        }
      }
    });
    (0, _defineProperty2.default)(this, "checkReward", num => {
      if (this.state.data.reward >= num) {
        this.setState({
          openModal: true,
          points: num
        });
      } else {
        func.callSwal('Insufficient Cashback Amount for this level');
      }
    });
    (0, _defineProperty2.default)(this, "convertReward", () => {
      const data = {
        'userId': this.state.user.id,
        'points': this.state.points
      };

      _axios.default.post('/admin/convertRewardToCash', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          localStorage.setItem('message', res.data.message);
          window.location.href = '/user/my-account';
        }

        func.callSwal(res.data.message);
      });
    });
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        openModal: false,
        points: ''
      });
      window.scrollTo(0, 0);
    });
    this.state = {
      data: [],
      active: 'All',
      count: [],
      countCopy: [],
      openModal: false,
      points: '',
      loading: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      }, () => this.callApi());
    }

    this.setState({
      count: func.count,
      countCopy: func.count
    });
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), !this.state.loading ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container admin my-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_UserBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10 cReward"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Cashback Reward"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row rowHeading"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Your Reward Points ", this.state.data ? this.state.data.reward : 0)), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("ul", {
      className: "lockStructure"
    }, /*#__PURE__*/_react.default.createElement("li", {
      className: this.state.active == "All" ? "active" : null,
      onClick: () => this.changeActive('All')
    }, "All ", /*#__PURE__*/_react.default.createElement("strong", null)), /*#__PURE__*/_react.default.createElement("li", {
      className: this.state.active == "Unlocked" ? "active" : null,
      onClick: () => this.changeActive('Unlocked')
    }, "Unlocked ", /*#__PURE__*/_react.default.createElement("strong", null)), /*#__PURE__*/_react.default.createElement("li", {
      className: this.state.active == "Locked" ? "active" : null,
      onClick: () => this.changeActive('Locked')
    }, "Locked ", /*#__PURE__*/_react.default.createElement("strong", null))))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, this.state.count.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4",
      key: index,
      onClick: () => this.checkReward(i.points)
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("div", {
      className: "counter"
    }, /*#__PURE__*/_react.default.createElement("p", null, i.id)), this.state.data ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, i.points > this.state.data.reward ? /*#__PURE__*/_react.default.createElement("div", {
      className: "lock"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/lock.png"
    })) : null) : /*#__PURE__*/_react.default.createElement("div", {
      className: "lock"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/lock.png"
    })), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/gold.png",
      className: "gold"
    }), /*#__PURE__*/_react.default.createElement("p", null, "Reward Points ", i.points), /*#__PURE__*/_react.default.createElement("div", {
      className: "locked"
    }, /*#__PURE__*/_react.default.createElement("p", null, "Locked ", i.locked))))))))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    })), /*#__PURE__*/_react.default.createElement(_Footer.default, null), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.openModal,
      className: "adminModal"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("h3", {
      className: "text-center"
    }, "Convert ", this.state.points, " reward points to cashback ? "), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      onClick: this.convertReward
    }, " Yes")))));
  }

}

exports.CashbackReward = CashbackReward;
var _default = CashbackReward;
exports.default = _default;