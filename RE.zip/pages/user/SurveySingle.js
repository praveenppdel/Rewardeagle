"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.SurveySingle = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _Brands = _interopRequireDefault(require("../parts/Brands"));

var _NewsLetter = _interopRequireDefault(require("../parts/NewsLetter"));

var _ThankYouModal = _interopRequireDefault(require("../parts/ThankYouModal"));

var _axios = _interopRequireDefault(require("axios"));

const func = require('../parts/functions');

class SurveySingle extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const url = window.location.href.split("/").pop();
      const response = await fetch('/admin/takeSurvey/' + url);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data,
        surveyId: url,
        questions: body.questions
      });
      const response2 = await fetch('/surveyData');
      const body2 = await response2.json();
      if (response2.status !== 200) throw Error(body2.message);
      this.setState({
        surveyCat: body2.surveyCat
      });
    });
    (0, _defineProperty2.default)(this, "checkOption", (quest, ans) => {
      this.state.answers[quest] = ans;
      this.setState({
        answers: this.state.answers
      });
    });
    (0, _defineProperty2.default)(this, "timeout", async delay => {
      return new Promise(res => setTimeout(res, delay));
    });
    (0, _defineProperty2.default)(this, "submitHandler", async e => {
      e.preventDefault();
      const data = {
        'userId': this.state.user.id,
        'answers': JSON.stringify(this.state.answers),
        'surveyId': this.state.surveyId
      };

      _axios.default.post('/admin/submitSurvey', data).then(async res => {
        if (res.data.success) {
          localStorage.setItem('message', res.data.message);
          this.setState({
            showModal: true
          });
          await this.timeout(5000);
          window.location.href = '/user/your-surveys';
        } else {
          func.callSwal(res.data.message);
        }
      }).catch(err => func.printError(err));
    });
    this.state = {
      user: [],
      data: [],
      answers: [],
      questions: [],
      surveyCat: [],
      surveyId: '',
      showModal: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      });
    }

    this.callApi();
  }

  checked(e, index) {
    this.state.answers[index] = e.target.value;
    this.setState({
      answers: this.state.answers
    });
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container dailyRanking my-5"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Survey for ", this.state.data.title ? this.state.data.title : null, " "), /*#__PURE__*/_react.default.createElement("p", {
      className: "headingPara"
    }, "If you\u2019re interested in earning money by participating in free online surveys, join our Online Survey and get upto 100 points on each survey response."), /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, this.state.questions.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 card",
      key: index
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("h3", null, i.title), i.type == 2 ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, JSON.parse(i.options).map((j, index2) => /*#__PURE__*/_react.default.createElement("div", {
      key: index2,
      onClick: () => this.checkOption(index, index2),
      className: "optionTick"
    }, /*#__PURE__*/_react.default.createElement("input", {
      type: "radio",
      name: index,
      required: i.mandatory == 1 ? true : false
    }), j))) : i.type == 1 ? /*#__PURE__*/_react.default.createElement("input", {
      type: "text",
      className: "form-control",
      value: this.state.answers[index],
      name: index,
      onChange: e => this.checked(e, index),
      placeholder: "Your Answer"
    }) : null))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit")))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row my-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 surveyCatList"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "More Survey Categories"), /*#__PURE__*/_react.default.createElement("ul", null, this.state.surveyCat.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/survey-category/" + i.id
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/basic/" + i.tab3
    }), /*#__PURE__*/_react.default.createElement("p", null, i.name)))))))), /*#__PURE__*/_react.default.createElement(_NewsLetter.default, null), /*#__PURE__*/_react.default.createElement(_Brands.default, null), /*#__PURE__*/_react.default.createElement(_Footer.default, null), /*#__PURE__*/_react.default.createElement(_ThankYouModal.default, {
      showModal: this.state.showModal,
      text: "for partcipating in our survey"
    }));
  }

}

exports.SurveySingle = SurveySingle;
var _default = SurveySingle;
exports.default = _default;