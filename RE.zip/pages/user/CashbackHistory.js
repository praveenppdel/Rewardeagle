"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.CashbackHistory = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _UserBar = _interopRequireDefault(require("../parts/UserBar"));

var _moment = _interopRequireDefault(require("moment"));

class CashbackHistory extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/userCashbackHistory/' + this.state.user.id);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.cashback,
        transferRequest: body.transferRequest,
        loading: false
      });
    });
    this.state = {
      data: [],
      transferRequest: [],
      loading: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      }, () => this.callApi());
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), !this.state.loading ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container admin mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_UserBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Cashback History"), this.state.data.length ? /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "Monitor all purchases made via RewardEagle and track your cashback status.Summary of all the bonus money you have earned from RewardEagle.") : null // <p className="text-center">You have no cashback history</p>
    , /*#__PURE__*/_react.default.createElement("div", {
      className: "chistory"
    }, this.state.data.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "card",
      key: index
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("h3", null, "For shopping on ", /*#__PURE__*/_react.default.createElement("a", {
      href: "/store/" + i.url
    }, i.name))), /*#__PURE__*/_react.default.createElement("li", null, i.status)), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, "Cashback Amount :", i.status == "Pending" ? "Upto" : null, " Rs ", i.customerPayout), /*#__PURE__*/_react.default.createElement("li", null, "Alloted On: ", (0, _moment.default)(i.updated_at).format("DD MMMM  YYYY"))))))), /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Transfer Request"), /*#__PURE__*/_react.default.createElement("p", {
      className: "text-center"
    }, "Transfers can take upto 30-45 days to get approved."), /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl no."), /*#__PURE__*/_react.default.createElement("td", null, "Amount"), /*#__PURE__*/_react.default.createElement("td", null, "Requested On"), /*#__PURE__*/_react.default.createElement("td", null, "Status"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.transferRequest.map((i, index) => /*#__PURE__*/_react.default.createElement("tr", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null, i.redeem), /*#__PURE__*/_react.default.createElement("td", null, (0, _moment.default)(i.updated_at).format("DD MMMM  YYYY")), /*#__PURE__*/_react.default.createElement("td", null, i.status == 0 ? "Requested" : "Transferred")))))))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    })), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.CashbackHistory = CashbackHistory;
var _default = CashbackHistory;
exports.default = _default;