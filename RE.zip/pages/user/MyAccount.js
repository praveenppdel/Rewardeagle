"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.MyAccount = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _UserBar = _interopRequireDefault(require("../parts/UserBar"));

var _axios = _interopRequireDefault(require("axios"));

const func = require('../parts/functions');

class MyAccount extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "setMinNum", async e => {
      var data = await func.setMinNum(e);
      this.setState({
        [e.target.name]: data
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/userAccounts/' + this.state.user.id);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);

      if (body.data) {
        const xx = body.pending.reduce((sum, i) => sum + i.customerPayout, 0);
        this.setState({
          data: body.data,
          loading: false,
          pending: xx
        });

        if (body.profile.length) {
          if (body.profile[0].bank) {
            this.setState({
              eligible: true
            });
          } else {
            func.callSwal('Please update your profile for cashback');
          }
        } else {
          func.callSwal('Please create your profile for cashback');
        }
      }
    });
    (0, _defineProperty2.default)(this, "submitHandler", e => {
      e.preventDefault();

      if (!this.state.eligible) {
        func.callSwal('Please update your profile for cashback');
      } else if (this.state.data) {
        const data = {
          'userId': this.state.user.id,
          'redeem': this.state.redeem
        };

        _axios.default.post('/admin/redeemRequest', data).catch(err => func.printError(err)).then(res => {
          if (res.data.success) {
            localStorage.setItem('message', res.data.message);
            window.location.href = '/user/cashback-history';
          }

          func.callSwal(res.data.message);
        });
      } else {
        func.callSwal('You have no cashback');
        this.setState({
          redeem: ''
        });
      }
    });
    this.state = {
      data: '',
      pending: '',
      user: [],
      profile: {},
      redeem: '',
      eligible: false,
      loading: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      }, () => this.callApi());
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "jhalar"
    }), !this.state.loading ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container admin mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_UserBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10 cashrew"
    }, /*#__PURE__*/_react.default.createElement("ul", {
      className: "cashPoints"
    }, /*#__PURE__*/_react.default.createElement("li", null, "Cashback Approved", /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("span", null, " Rs ", this.state.data ? this.state.data.cashback : 0)), /*#__PURE__*/_react.default.createElement("li", null, "Cashback Pending", /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("span", null, " Rs ", this.state.pending ? this.state.pending : 0)), /*#__PURE__*/_react.default.createElement("li", null, "Reward Points", /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("span", null, " ", this.state.pending ? this.state.data.reward : 0))), /*#__PURE__*/_react.default.createElement("h3", {
      className: "mt-5"
    }, "Transfer To Bank"), /*#__PURE__*/_react.default.createElement("p", null, "You can request an IMPS transfer to your bank account."), /*#__PURE__*/_react.default.createElement("p", null, /*#__PURE__*/_react.default.createElement("strong", null, "Note:"), " The service is available 24*7 throughout the year including bank holidays."), this.state.data ? /*#__PURE__*/_react.default.createElement("p", null, "Rs. ", this.state.data.cashback, " available balance") : null, /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "redeem",
      value: this.state.redeem,
      onChange: this.setMinNum,
      max: this.state.data.cashback,
      placeholder: "Cashback transfer",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit",
      style: {
        margin: 0
      }
    }, "Submit")))), /*#__PURE__*/_react.default.createElement("ul", {
      className: "rules"
    }, /*#__PURE__*/_react.default.createElement("li", null, "Minimum Amount that can be redeemed is Rs 100. "), /*#__PURE__*/_react.default.createElement("li", null, "Maximum Withdrawal per day is Rs. 10000. TDS applicable above the mentioned amount."))))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    })), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.MyAccount = MyAccount;
var _default = MyAccount;
exports.default = _default;