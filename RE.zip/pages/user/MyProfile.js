"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.MyProfile = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _UserBar = _interopRequireDefault(require("../parts/UserBar"));

var _axios = _interopRequireDefault(require("axios"));

const func = require('../parts/functions');

class MyProfile extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/checkProfile/' + this.state.user.id);
      const body = await response.json();
      console.log(`body`, body);
      if (response.status !== 200) throw Error(body.message);

      if (body.data && body.data.id) {
        this.setState({
          profileExists: true,
          id: body.data.id,
          oldImage: body.data.image
        });

        if (body.data.user) {
          this.setState({
            name: JSON.parse(body.data.user)[0],
            email: JSON.parse(body.data.user)[1],
            phone: JSON.parse(body.data.user)[2],
            gender: JSON.parse(body.data.user)[3],
            dob: JSON.parse(body.data.user)[4]
          });
        }

        if (body.data.bank) {
          this.setState({
            actype: JSON.parse(body.data.bank)[0],
            bank: JSON.parse(body.data.bank)[1],
            acholder: JSON.parse(body.data.bank)[2],
            acnumber: JSON.parse(body.data.bank)[3],
            ifsc: JSON.parse(body.data.bank)[4]
          });
        }

        if (body.data.google) {
          this.setState({
            gpid: JSON.parse(body.data.google)[0],
            gpmob: JSON.parse(body.data.google)[1]
          });
        }

        if (body.data.scim) {
          this.setState({
            salary: JSON.parse(body.data.scim)[0],
            occupation: JSON.parse(body.data.scim)[1],
            interest: JSON.parse(body.data.scim)[2],
            marital: JSON.parse(body.data.scim)[3]
          });
        }

        if (body.data.address) {
          this.setState({
            state: JSON.parse(body.data.address)[0],
            city: JSON.parse(body.data.address)[1],
            address: JSON.parse(body.data.address)[2]
          });
        }

        if (body.data.paytm) {
          this.setState({
            paytmid: JSON.parse(body.data.paytm)[0],
            paytmmob: JSON.parse(body.data.paytm)[1]
          });
        }

        if (body.data.phonepe) {
          this.setState({
            ppid: JSON.parse(body.data.phonepe)[0],
            ppmob: JSON.parse(body.data.phonepe)[1]
          });
        }
      }
    });
    (0, _defineProperty2.default)(this, "uploadImage", e => {
      this.setState({
        image: e.target.files[0]
      });
    });
    (0, _defineProperty2.default)(this, "submitHandler", e => {
      e.preventDefault();
      const data = new FormData();
      data.append('file', this.state.image);
      data.append('userId', this.state.user.id);
      data.append('user', JSON.stringify([this.state.name, this.state.email, this.state.phone, this.state.gender, this.state.dob]));
      data.append('address', JSON.stringify([this.state.state, this.state.city, this.state.address]));
      data.append('scim', JSON.stringify([this.state.salary, this.state.occupation, this.state.interest, this.state.marital]));
      data.append('bank', JSON.stringify([this.state.actype, this.state.bank, this.state.acholder, this.state.acnumber, this.state.ifsc]));
      data.append('google', JSON.stringify([this.state.gpid, this.state.gpmob]));
      data.append('paytm', JSON.stringify([this.state.paytmid, this.state.paytmmob]));
      data.append('phonepe', JSON.stringify([this.state.ppid, this.state.ppmob]));

      if (this.state.profileExists) {
        data.append('id', this.state.id);
        data.append('oldImage', this.state.oldImage);

        _axios.default.post('/admin/updateProfile', data).catch(err => func.printError(err)).then(res => {
          if (res.data.success) {
            localStorage.setItem('message', res.data.message);
            window.location.href = '/user/my-account';
          }

          func.callSwal(res.data.message);
        });
      } else {
        _axios.default.post('/admin/createProfile', data).catch(err => func.printError(err)).then(res => {
          if (res.data.success) {
            localStorage.setItem('message', res.data.message);
            window.location.href = '/user/my-account';
          }

          func.callSwal(res.data.message);
        });
      }
    });
    this.state = {
      loading: false,
      profileExists: false,
      user: [],
      id: '',
      name: '',
      email: '',
      gender: '',
      dob: '',
      phone: '',
      state: '',
      city: '',
      address: '',
      salary: '',
      occupation: '',
      interest: '',
      marital: '',
      actype: '',
      bank: '',
      acholder: '',
      acnumber: '',
      ifsc: '',
      gpid: '',
      gpmob: '',
      paytmid: '',
      paytmmob: '',
      ppid: '',
      ppmob: '',
      image: null,
      oldImage: ''
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      }, () => this.callApi());
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), !this.state.loading ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container admin mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_UserBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "My Profile"), /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row mb-5"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Your Name"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Your Name",
      name: "name",
      required: true,
      value: this.state.name,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Email"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "email",
      placeholder: "Your Email",
      name: "email",
      required: true,
      value: this.state.email,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Gender"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "gender",
      required: true,
      value: this.state.gender,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Gender"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Male"
    }, "Male"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Female"
    }, "Female"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Date of Birth"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      placeholder: "Your Date of Birth",
      name: "dob",
      required: true,
      value: this.state.dob,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Phone"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Your Phone",
      name: "phone",
      required: true,
      value: this.state.phone,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "State"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "State",
      name: "state",
      required: true,
      value: this.state.state,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "City"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "City",
      name: "city",
      required: true,
      value: this.state.city,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Address"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Address",
      name: "address",
      required: true,
      value: this.state.address,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Annual Salary"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "salary",
      required: true,
      value: this.state.salary,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Salary"), func.salary.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      key: index,
      value: i.value
    }, i.text)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Occupation"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "occupation",
      required: true,
      value: this.state.occupation,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Occupation"), func.occupation.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      key: index,
      value: i.value
    }, i.text)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Interest"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "interest",
      required: true,
      value: this.state.interest,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Interest"), func.interest.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      key: index,
      value: i.value
    }, i.text)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Marital Status"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "marital",
      required: true,
      value: this.state.marital,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Marital Status"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Single"
    }, "Single"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Married"
    }, "Married"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Profile Pic"), /*#__PURE__*/_react.default.createElement("input", {
      type: "file",
      className: "form-control",
      onChange: this.uploadImage
    }), this.state.oldImage ? /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/profile/" + this.state.oldImage,
      className: "preview"
    }) : null)), /*#__PURE__*/_react.default.createElement("h3", null, "Bank Details"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Account Type"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "actype",
      value: this.state.actype,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Account Type"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Savings"
    }, "Savings"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Current"
    }, "Current"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Bank Name"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Bank Name",
      name: "bank",
      value: this.state.bank,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Name of Account Holder"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Name of Account Holder",
      name: "acholder",
      value: this.state.acholder,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Confirm Account Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Account Number",
      name: "acnumber",
      value: this.state.acnumber,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "IFSC Code"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "IFSC Code",
      name: "ifsc",
      value: this.state.ifsc,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("h3", null, "Other Bank Options"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Google Pay ID"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Google Pay ID",
      name: "gpid",
      value: this.state.gpid,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Mobile Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Mobile Number",
      name: "gpmob",
      value: this.state.gpmob,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "PayTM ID"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "PayTM ID",
      name: "paytmid",
      value: this.state.paytmid,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Mobile Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Mobile Number",
      name: "paytmmob",
      value: this.state.paytmmob,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "PhonePe ID"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "PhonePe ID",
      name: "ppid",
      value: this.state.ppid,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Mobile Number"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Mobile Number",
      name: "ppmob",
      value: this.state.ppmob,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, this.state.profileExists ? "Update Profile" : "Create Profile")))))) : /*#__PURE__*/_react.default.createElement("div", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    })), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.MyProfile = MyProfile;
var _default = MyProfile;
exports.default = _default;