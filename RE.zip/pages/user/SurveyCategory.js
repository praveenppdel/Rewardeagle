"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Survey = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _Brands = _interopRequireDefault(require("../parts/Brands"));

var _NewsLetter = _interopRequireDefault(require("../parts/NewsLetter"));

class Survey extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const url = window.location.href.split("/").pop();
      const response = await fetch('/admin/surveyCategoryData/' + url);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data
      });
      const response2 = await fetch('/surveyData');
      const body2 = await response2.json();
      if (response2.status !== 200) throw Error(body2.message);
      this.setState({
        surveyCat: body2.surveyCat
      });
    });
    this.state = {
      data: [],
      surveyCat: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container dailyRanking my-5"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Survey for ", this.state.data.length ? this.state.data[0].name : null, " "), /*#__PURE__*/_react.default.createElement("p", {
      className: "headingPara"
    }, "If you\u2019re interested in earning money by participating in free online surveys, join our Online Survey and get upto 100 points on each survey response."), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 surveyCatPage mb-5"
    }, /*#__PURE__*/_react.default.createElement("ul", null, this.state.data.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/survey/" + i.id
    }, /*#__PURE__*/_react.default.createElement("span", null, index + 1), i.title, " - ", i.reward, " reward Points"))))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 surveyCatList"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "More Survey Categories"), /*#__PURE__*/_react.default.createElement("ul", null, this.state.surveyCat.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/survey-category/" + i.id
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/basic/" + i.tab3
    }), /*#__PURE__*/_react.default.createElement("p", null, i.name)))))))), /*#__PURE__*/_react.default.createElement(_NewsLetter.default, null), /*#__PURE__*/_react.default.createElement(_Brands.default, null), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.Survey = Survey;
var _default = Survey;
exports.default = _default;