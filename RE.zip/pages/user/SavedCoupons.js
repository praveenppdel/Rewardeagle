"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.SavedCoupons = void 0;

var _react = _interopRequireWildcard(require("react"));

class SavedCoupons extends _react.Component {
  render() {
    return /*#__PURE__*/_react.default.createElement("div", null);
  }

}

exports.SavedCoupons = SavedCoupons;
var _default = SavedCoupons;
exports.default = _default;