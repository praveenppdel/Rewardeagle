"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.SocialShare = void 0;

var _react = _interopRequireWildcard(require("react"));

var _reactShare = require("react-share");

class SocialShare extends _react.Component {
  render() {
    const shareUrl = this.props.url;
    const title = this.props.title;
    const media = this.props.media;
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, /*#__PURE__*/_react.default.createElement("span", null, "Refer and "), "Earn"), /*#__PURE__*/_react.default.createElement("div", {
      className: "socialShare flex-h mb-5"
    }, /*#__PURE__*/_react.default.createElement(_reactShare.FacebookShareButton, {
      url: shareUrl,
      quote: title
    }, " ", /*#__PURE__*/_react.default.createElement(_reactShare.FacebookIcon, {
      size: 32,
      round: true
    }), " "), /*#__PURE__*/_react.default.createElement(_reactShare.FacebookMessengerShareButton, {
      url: shareUrl,
      appId: "154761472308630"
    }, " ", /*#__PURE__*/_react.default.createElement(_reactShare.FacebookMessengerIcon, {
      size: 32,
      round: true
    })), /*#__PURE__*/_react.default.createElement(_reactShare.TwitterShareButton, {
      url: shareUrl,
      title: title
    }, /*#__PURE__*/_react.default.createElement(_reactShare.TwitterIcon, {
      size: 32,
      round: true
    })), /*#__PURE__*/_react.default.createElement(_reactShare.WhatsappShareButton, {
      url: shareUrl,
      title: title,
      separator: ":: "
    }, /*#__PURE__*/_react.default.createElement(_reactShare.WhatsappIcon, {
      size: 32,
      round: true
    })), /*#__PURE__*/_react.default.createElement(_reactShare.LinkedinShareButton, {
      url: shareUrl
    }, /*#__PURE__*/_react.default.createElement(_reactShare.LinkedinIcon, {
      size: 32,
      round: true
    }))));
  }

}

exports.SocialShare = SocialShare;
var _default = SocialShare;
exports.default = _default;
{
  /* <PinterestShareButton url={String(window.location)} media={media}><PinterestIcon size={32} round /></PinterestShareButton> */
}