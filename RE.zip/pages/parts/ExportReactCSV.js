"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ExportReactCSV = void 0;

var _react = _interopRequireDefault(require("react"));

var _reactCsv = require("react-csv");

const ExportReactCSV = ({
  csvData,
  fileName
}) => {
  return /*#__PURE__*/_react.default.createElement("button", {
    variant: "warning",
    className: "exportBtn"
  }, /*#__PURE__*/_react.default.createElement(_reactCsv.CSVLink, {
    data: csvData,
    filename: fileName
  }, "Export"));
};

exports.ExportReactCSV = ExportReactCSV;