"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.StoreSidebar = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _reactIdSwiper = _interopRequireDefault(require("react-id-swiper"));

var _reactstrap = require("reactstrap");

const func = require('../parts/functions');

class StoreSidebar extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const url = window.location.href.split("/").pop(); // var cat = [];

      if (url != 'stores') {
        const response2 = await fetch('/admin/checkStoreUrl/' + url);
        const body2 = await response2.json();
        if (response2.status !== 200) throw Error(body2.message);

        if (body2.storeData.length) {
          this.setState({
            store: body2.storeData[0]
          });
        }
      }

      const response = await fetch('/storeSidebar');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      const categories = [];
      body.categories.forEach(i => {
        i.isChecked = false;
        categories.push(i);
      });

      if (window.location.pathname.split("/")[1] && window.location.pathname.split("/")[1] == 'storeCategory') {
        if (categories.filter(i => i.url == url).length) {
          categories.filter(i => i.url == url)[0].isChecked = true;
          const id = categories.filter(i => i.url == url)[0].id;
          this.setState({
            catSelected: [id]
          }, () => this.sendDataToParent());
        }
      }

      const tag = [];
      body.tags.forEach(i => {
        i.isChecked = false;
        tag.push(i);
      });

      if (window.location.pathname.split("/")[1] && window.location.pathname.split("/")[1] == 'storeTag') {
        if (tag.filter(i => i.url == url).length) {
          tag.filter(i => i.url == url)[0].isChecked = true;
          const id = tag.filter(i => i.url == url)[0].id;
          this.setState({
            tagSelected: [id]
          }, () => this.sendDataToParent());
        }
      }

      this.setState({
        categories: categories,
        tag: tag
      });
    });
    (0, _defineProperty2.default)(this, "filterCategory", (index, check) => {
      this.state.categories[index].isChecked = check;
      const id = this.state.categories[index].id;
      this.setState({
        categories: this.state.categories
      });

      if (check) {
        this.setState({
          catSelected: [...this.state.catSelected, id]
        }, () => this.sendDataToParent());
      } else {
        this.setState({
          catSelected: this.state.catSelected.filter(i => i !== id)
        }, () => this.sendDataToParent());
      }
    });
    (0, _defineProperty2.default)(this, "filterTag", (index, check) => {
      this.state.tag[index].isChecked = check;
      const id = this.state.tag[index].id;
      this.setState({
        tag: this.state.tag
      });

      if (check) {
        this.setState({
          tagSelected: [...this.state.tagSelected, id]
        }, () => this.sendDataToParent());
      } else {
        this.setState({
          tagSelected: this.state.tagSelected.filter(i => i !== id)
        }, () => this.sendDataToParent());
      }
    });
    (0, _defineProperty2.default)(this, "sendDataToParent", () => {
      this.props.parentCallback(this.state.catSelected, this.state.tagSelected);
    });
    (0, _defineProperty2.default)(this, "redirectMerchant", async () => {
      if (this.state.user.role) {
        if (this.state.store.tlink) {
          this.setState({
            redirectModal: true
          });
          var win = window.open(this.state.store.tlink, '_blank');
          win.focus();
        }
      } else {
        localStorage.setItem('message', 'Please login to continue');
        localStorage.setItem('redirectTo', window.location.pathname);
        window.location.href = '/login';
      }
    });
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        redirectModal: false
      });
    });
    this.state = {
      store: this.props.store,
      categories: this.props.categories,
      tag: this.props.tag,
      catSelected: [],
      tagSelected: [],
      user: [],
      redirectModal: false,
      merchant: ''
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      });
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3 storeSidebar web"
    }, this.state.store && this.state.store.name ? /*#__PURE__*/_react.default.createElement("ul", {
      className: "breadCrumb"
    }, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/"
    }, "Home ", '>', " ")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores"
    }, "Stores ", '>', " ")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + this.state.store.url
    }, this.state.store.name))) : null, this.state.store ? /*#__PURE__*/_react.default.createElement("div", {
      className: "activateReward mb-3"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + this.state.store.logo
    }), /*#__PURE__*/_react.default.createElement("p", null, "Upto ", this.state.store.cashback, " Off"), /*#__PURE__*/_react.default.createElement("button", {
      onClick: () => this.redirectMerchant(),
      className: "casleyBtn"
    }, "Activate Rewards")) : null, this.state.categories ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.categories.length ? /*#__PURE__*/_react.default.createElement("div", {
      className: "filter"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "filterHead"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Categories")), this.state.categories.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "filterCover",
      key: index
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "onoffswitch"
    }, /*#__PURE__*/_react.default.createElement("input", {
      type: "checkbox",
      name: "category",
      className: "onoffswitch-checkbox",
      id: 'cat-' + index,
      onChange: e => this.filterCategory(index, e.target.checked),
      value: index,
      checked: i.isChecked
    }), /*#__PURE__*/_react.default.createElement("label", {
      className: "onoffswitch-label",
      htmlFor: 'cat-' + index
    }, /*#__PURE__*/_react.default.createElement("span", {
      className: "onoffswitch-inner"
    }), /*#__PURE__*/_react.default.createElement("span", {
      className: "onoffswitch-switch"
    }))), /*#__PURE__*/_react.default.createElement("span", {
      style: {
        marginLeft: '10px'
      }
    }, i.name)))) : null) : null, this.state.tag ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.tag.length ? /*#__PURE__*/_react.default.createElement("div", {
      className: "filter"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "filterHead"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Tags")), this.state.tag.map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "filterCover",
      key: index
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "onoffswitch"
    }, /*#__PURE__*/_react.default.createElement("input", {
      type: "checkbox",
      name: "tag",
      className: "onoffswitch-checkbox",
      id: 'tag' + index,
      onChange: e => this.filterTag(index, e.target.checked),
      value: index,
      checked: i.isChecked
    }), /*#__PURE__*/_react.default.createElement("label", {
      className: "onoffswitch-label",
      htmlFor: 'tag' + index
    }, /*#__PURE__*/_react.default.createElement("span", {
      className: "onoffswitch-inner"
    }), /*#__PURE__*/_react.default.createElement("span", {
      className: "onoffswitch-switch"
    }))), /*#__PURE__*/_react.default.createElement("span", {
      style: {
        marginLeft: '10px'
      }
    }, i.name)))) : null) : null, this.state.store ? /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.redirectModal,
      className: "adminModal redirectModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("div", {
      className: "topOffer"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("section", {
      className: "not-found-controller cashBackData",
      dangerouslySetInnerHTML: {
        __html: this.state.store.cashback
      }
    }), /*#__PURE__*/_react.default.createElement("p", null, "Coupon Code ", /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("span", null, this.state.store.offer))), /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X")), /*#__PURE__*/_react.default.createElement("div", {
      className: "eagle"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/logo-red.gif"
    }), /*#__PURE__*/_react.default.createElement("span", null, " ", '>', " "), /*#__PURE__*/_react.default.createElement("span", null, " ", '>', " "), /*#__PURE__*/_react.default.createElement("span", null, " ", '>', " "), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/logo/" + this.state.store.logo
    })), /*#__PURE__*/_react.default.createElement("p", {
      style: {
        'color': 'red'
      }
    }, "Redirecting. Please wait ..."), /*#__PURE__*/_react.default.createElement("p", null, this.state.store.title))) : null);
  }

}

exports.StoreSidebar = StoreSidebar;
var _default = StoreSidebar;
exports.default = _default;