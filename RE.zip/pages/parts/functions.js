"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.callSwal = callSwal;
exports.printError = printError;
exports.checkDuplicate = checkDuplicate;
exports.setMinNum = setMinNum;
exports.sortArray = sortArray;
exports.sideLinks = exports.userLinks = exports.adminLinks = exports.count = exports.salary = exports.occupation = exports.interest = exports.faqQA = exports.faqCat = exports.storeFilter = exports.adList = exports.brands = exports.paramAdsHeader = exports.paramHeader = exports.params4 = exports.params3 = exports.params21 = exports.params2 = exports.params = exports.countFour = exports.paramsVerySlow = exports.paramsDouble = exports.paramsCatsNStore = exports.paramSlider = exports.basics = exports.time = void 0;
const time = new Date().toISOString().slice(0, 19).replace('T', ' ');
exports.time = time;

function callSwal(mesg) {
  swal({
    title: mesg,
    timer: 4000
  });
}

function printError(mesg) {
  console.log('mesg', mesg);
}

const basics = [{
  single: false,
  value: "Publisher",
  name: "Publisher"
}, {
  single: false,
  value: "CouponType",
  name: "Type of Coupon"
}, {
  single: false,
  value: "Carousel",
  name: "Carousel"
}, {
  single: false,
  value: "Tags",
  name: "Tags"
}, {
  single: false,
  value: "Survey",
  name: "Survey Category"
}, {
  single: true,
  value: "SnowFall",
  name: "Snow Fall"
}, {
  single: true,
  value: "Tagline",
  name: "Tagline"
}, {
  single: true,
  value: "Jhalar",
  name: "Jhalar"
}];
exports.basics = basics;

function checkDuplicate(array) {
  return new Promise((resolve, reject) => {
    const dup = array.reduce((i, index) => {
      i.items[index] = i.items[index] ? i.items[index] += 1 : 1;
      if (i.items[index] === 2) i.dup.push(index);
      return i;
    }, {
      items: {},
      dup: []
    });
    resolve(dup);
    return;
  });
}

function setMinNum(e) {
  return new Promise((resolve, reject) => {
    if (e.target.max) {
      let {
        value,
        min,
        max
      } = e.target;
      var data = Math.max(Number(min), Math.min(Number(max), Number(value)));
    } else {
      let {
        value,
        min
      } = e.target;
      var data = Math.max(Number(min), Number(value));
    }

    resolve(data);
    return;
  });
}

function sortArray(array, sortBy, type, direction) {
  return new Promise((resolve, reject) => {
    if (type == 'text') {
      if (direction == 'Up') {
        array.sort(function (a, b) {
          if (a.store.toLowerCase() < b.store.toLowerCase()) return -1;
          if (a.store.toLowerCase() > b.store.toLowerCase()) return 1;
          return 0;
        });
      } else {
        array.sort(function (a, b) {
          if (a.store.toLowerCase() < b.store.toLowerCase()) return 1;
          if (a.store.toLowerCase() > b.store.toLowerCase()) return -1;
          return 0;
        });
      }
    }

    if (type == 'number') {
      const xx = sortBy;

      if (direction == 'Up') {
        array.sort(function (a, b) {
          if (a.xx > b.xx) return 1;
          if (b.xx > a.xx) return -1;
          return 0;
        });
      } else {
        array.sort(function (a, b) {
          if (a.xx > b.xx) return -1;
          if (b.xx > a.xx) return 1;
          return 0;
        });
      }
    }

    resolve(array);
    return;
  });
}

const paramSlider = {
  observer: true,
  observeParents: true,
  slidesPerView: 1,
  spaceBetween: 10,
  loop: true,
  autoplay: {
    delay: 3000,
    disableOnInteraction: true
  },
  breakpoints: {
    640: {
      slidesPerView: 2,
      spaceBetween: 20
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  },
  on: {
    click: function () {
      swiper.autoplay.stop();
    }
  }
};
exports.paramSlider = paramSlider;
const paramsCatsNStore = {
  slidesPerView: 4,
  spaceBetween: 10,
  loop: true,
  autoplay: {
    delay: 4000
  },
  breakpoints: {
    640: {
      slidesPerView: 4,
      spaceBetween: 40
    },
    768: {
      slidesPerView: 6,
      spaceBetween: 40
    },
    1400: {
      slidesPerView: 12,
      spaceBetween: 40
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.paramsCatsNStore = paramsCatsNStore;
const paramsDouble = {
  slidesPerView: 1,
  spaceBetween: 0,
  loop: true,
  autoplay: {
    delay: 4000
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.paramsDouble = paramsDouble;
const paramsVerySlow = {
  slidesPerView: 4,
  spaceBetween: 40,
  loop: true,
  // speed: 5000,
  autoplay: {
    delay: 4000
  },
  breakpoints: {
    640: {
      slidesPerView: 4,
      spaceBetween: 40
    },
    768: {
      slidesPerView: 5,
      spaceBetween: 50
    },
    1400: {
      slidesPerView: 9,
      spaceBetween: 40
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.paramsVerySlow = paramsVerySlow;
const countFour = [0, 1, 2, 3];
exports.countFour = countFour;
const params = {
  fadeEffect: {
    crossFade: true
  },
  autoplay: {
    delay: 4500,
    disableOnInteraction: true
  },
  slidersPerView: 1,
  effect: "fade",
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  },
  loop: true
};
exports.params = params;
const params2 = {
  slidesPerView: 10,
  spaceBetween: 10,
  loop: true,
  autoplay: {
    delay: 4000
  },
  breakpoints: {
    640: {
      slidesPerView: 2,
      spaceBetween: 20
    },
    768: {
      slidesPerView: 4,
      spaceBetween: 40
    },
    1400: {
      slidesPerView: 10,
      spaceBetween: 5
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.params2 = params2;
const params21 = {
  slidesPerView: 10,
  spaceBetween: 10,
  loop: true,
  autoplay: {
    delay: 5500
  },
  breakpoints: {
    640: {
      slidesPerView: 2,
      spaceBetween: 20
    },
    768: {
      slidesPerView: 4,
      spaceBetween: 40
    },
    1400: {
      slidesPerView: 10,
      spaceBetween: 5
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.params21 = params21;
const params3 = {
  slidesPerView: 3,
  spaceBetween: 10,
  loop: true,
  autoplay: {
    delay: 3000
  },
  breakpoints: {
    640: {
      slidesPerView: 1,
      spaceBetween: 0
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 20
    },
    1400: {
      slidesPerView: 3,
      spaceBetween: 5
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.params3 = params3;
const params4 = {
  slidesPerView: 2,
  spaceBetween: 10,
  loop: true,
  autoplay: {
    delay: 2500
  },
  breakpoints: {
    640: {
      slidesPerView: 3,
      spaceBetween: 0
    },
    768: {
      slidesPerView: 5,
      spaceBetween: 20
    },
    1400: {
      slidesPerView: 10,
      spaceBetween: 5
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.params4 = params4;
const paramHeader = {
  observer: true,
  observeParents: true,
  watchSlidesVisibility: true,
  watchSlidesProgress: true,
  slidesPerView: 1,
  spaceBetween: 20,
  loop: true,
  // autoplay: { delay: 25000 },
  breakpoints: {
    640: {
      slidesPerView: 1,
      spaceBetween: 20
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 20
    },
    1400: {
      slidesPerView: 3,
      spaceBetween: 20
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.paramHeader = paramHeader;
const paramAdsHeader = {
  observer: true,
  observeParents: true,
  watchSlidesVisibility: true,
  watchSlidesProgress: true,
  slidesPerView: 1,
  spaceBetween: 20,
  loop: true,
  // autoplay: { delay: 25000 },
  breakpoints: {
    640: {
      slidesPerView: 3,
      spaceBetween: 10
    },
    768: {
      slidesPerView: 5,
      spaceBetween: 10
    },
    1400: {
      slidesPerView: 8,
      spaceBetween: 10
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
};
exports.paramAdsHeader = paramAdsHeader;
const brands = [{
  img: '1.png'
}, {
  img: '2.png'
}, {
  img: '3.png'
}, {
  img: '4.png'
}, {
  img: '5.png'
}, {
  img: '6.png'
}, {
  img: '7.png'
}, {
  img: '8.png'
}, {
  img: '9.png'
}, {
  img: '10.png'
}]; // export const specialSlider=[
//     { 'img': 'special-1.jpg', 'url': '/xx'},
//     { 'img': 'special-2.jpg', 'url': '/xx'},
//     { 'img': 'special-3.jpg', 'url': '/xx'},
// ]

exports.brands = brands;
const adList = [{
  'single': true,
  'type': 1,
  'text': 'Above Banner'
}, {
  'single': true,
  'type': 2,
  'text': 'Offer Left Side'
}, {
  'single': true,
  'type': 3,
  'text': 'Offer Right Side'
}, {
  'single': true,
  'type': 4,
  'text': 'Reward Eagle Collections Left Side'
}, {
  'single': true,
  'type': 5,
  'text': 'Reward Eagle Collections Right Side'
}, {
  'single': false,
  'type': 6,
  'text': 'Special Offer'
}, {
  'single': true,
  'type': 7,
  'text': 'Weekly Top Ranking Stores Left Top'
}, {
  'single': true,
  'type': 8,
  'text': 'Weekly Top Ranking Stores Left Bottom'
}, {
  'single': true,
  'type': 9,
  'text': 'Weekly Top Ranking Stores Right Top'
}, {
  'single': true,
  'type': 10,
  'text': 'Daily Ranking Right Bottom Small'
}, {
  'single': false,
  'type': 11,
  'text': 'New deals Onboard Ads'
}, {
  'single': true,
  'type': 12,
  'text': 'New deals Onboard Left'
}, {
  'single': true,
  'type': 13,
  'text': 'New deals Onboard Right'
}, {
  'single': true,
  'type': 14,
  'text': 'Shop Page Left Top'
}, {
  'single': true,
  'type': 15,
  'text': 'Shop Page Left Bottom'
}, {
  'single': true,
  'type': 16,
  'text': 'Shop Page Right Top'
}, {
  'single': true,
  'type': 17,
  'text': 'Shop Page Right Bottom'
}, {
  'single': true,
  'type': 18,
  'text': 'Categories Left'
}, {
  'single': true,
  'type': 19,
  'text': 'Categories Right'
}, {
  'single': false,
  'type': 20,
  'text': 'Stores Header'
}, {
  'single': false,
  'type': 21,
  'text': 'Survey Header'
}, {
  'single': false,
  'type': 22,
  'text': 'Special Slider'
}, {
  'single': true,
  'type': 23,
  'text': 'How It Works Left'
}, {
  'single': true,
  'type': 24,
  'text': 'How It Works Right'
}, {
  'single': true,
  'type': 25,
  'text': 'Weekly Top Left'
}, {
  'single': true,
  'type': 26,
  'text': 'Weekly Top Right'
}];
exports.adList = adList;
const storeFilter = [{
  'value': "0",
  'text': 'ALL'
}, {
  'value': "a",
  'text': 'A'
}, {
  'value': "b",
  'text': 'B'
}, {
  'value': "c",
  'text': 'C'
}, {
  'value': "d",
  'text': 'D'
}, {
  'value': "e",
  'text': 'E'
}, {
  'value': "f",
  'text': 'F'
}, {
  'value': "g",
  'text': 'G'
}, {
  'value': "h",
  'text': 'H'
}, {
  'value': "i",
  'text': 'I'
}, {
  'value': "j",
  'text': 'J'
}, {
  'value': "k",
  'text': 'K'
}, {
  'value': "l",
  'text': 'L'
}, {
  'value': "m",
  'text': 'M'
}, {
  'value': "n",
  'text': 'N'
}, {
  'value': "o",
  'text': 'O'
}, {
  'value': "p",
  'text': 'P'
}, {
  'value': "q",
  'text': 'Q'
}, {
  'value': "r",
  'text': 'R'
}, {
  'value': "s",
  'text': 'S'
}, {
  'value': "t",
  'text': 'T'
}, {
  'value': "u",
  'text': 'U'
}, {
  'value': "v",
  'text': 'V'
}, {
  'value': "w",
  'text': 'W'
}, {
  'value': "x",
  'text': 'X'
}, {
  'value': "y",
  'text': 'Y'
}, {
  'value': "z",
  'text': 'Z'
}];
exports.storeFilter = storeFilter;
const faqCat = [{
  'id': 1,
  'cat': 'Bonus'
}, {
  'id': 2,
  'cat': 'Cashback issues'
}, {
  'id': 3,
  'cat': 'Withdrawl'
}, {
  'id': 4,
  'cat': 'Cashback Facts'
}, {
  'id': 5,
  'cat': 'Partner With Us'
}, {
  'id': 6,
  'cat': 'Reward Eagle Modus Operandi'
}, {
  'id': 7,
  'cat': 'Tracking'
}, {
  'id': 8,
  'cat': 'Miscelleneous'
}];
exports.faqCat = faqCat;
const faqQA = [{
  'id': 1,
  'catId': 1,
  'quest': 'How to redeem my referral bonus?',
  'ans': '<p>Referral bonus is added to your pending balance every time someone signs up with Reward Eagle using yourreferral code. Your friend needs to complete the requisite requirements in order to successfully activate yourrespective bonus. To view the details for your referral scheme please visit the Refer and Earn section of MyAccounts, or simply click here</p>'
}, {
  'id': 2,
  'catId': 1,
  'quest': 'How to redeem my joining bonus?',
  'ans': '<p>Bonus amount, received on successful sign-up using a promotional code or via other promotional activities are summed up in your Pending Balance and can be redeemed as per our withdrawal policy.</p>'
}, {
  'id': 3,
  'catId': 1,
  'quest': 'Do I need to use joining / referral code while sign up?',
  'ans': '<p>You should apply the codes available to you either by referral or any promotional activity in order to avail thebenefits of the scheme. You can also use this field to enter a referral code from a friend, so that both of youcan avail benefits of the running referral scheme! Note: Only one code is applicable per sign up.</p>'
}, {
  'id': 4,
  'catId': 1,
  'quest': 'Why should I refer a friend?',
  'ans': '<p>You can earn an unlimited bonus amount for each friend that signs up using your referral code every time.There are no caps on the number of friends that you can refer. For more information, login to your Reward Eagle account and visit the Refer and Earn section under ‘My Accounts’, or simply click here.</p>'
}, {
  'id': 5,
  'catId': 2,
  'quest': 'Why was my cashback cancelled?',
  'ans': '<p>Some common reasons when any cashback can be declined are:</p><ul><li>The order was cancelled.</li><li>The order was returned or partially returned.</li><li>The order was exchanged or partially exchanged.</li><li>The order was changed.</li><li>The order was paid for using a gift code or gift voucher.</li><li>The order was paid for using Cash on Delivery.</li><li>The order might have been classified as bulk order from a wholesaler or a travel agent etc.</li><li>The order did not comply with the store"s cashback policy.</li><li>Sometimes stores do not provide us any specific reason for declining the cashback. In such cases aMissing Cashback claim can be filed to our customer support and we will do our best to find thereason for cancellation of the cashback.</li></ul>Note: The store holds sole discretion in determining the validity of the cashback transaction.'
}, {
  'id': 6,
  'catId': 2,
  'quest': 'Is there any difference between my confirmed cashback and pending cashback?',
  'ans': 'Pending cashback tracked amounts are indicative and can change upon final confirmation from the merchant.On any purchase made by a user, the corresponding transaction is tracked by the merchant store who in turnshare only the relevant information required to track cashback. Factors such as a new user or an existing useror the platform used (Desktop / App / Mobile web etc.), and the specific product category for the item youhave purchased influences the cashback rate. However, the complete tracking information is not provided bythe merchant to us and thus we cannot always accurately estimate your cashback amount.In case your cashback transaction was confirmed for an incorrect amount, please file a Missing Cashback Claimfor Incorrect Amount and share us at hello@rewardeagle.com.'
}, {
  'id': 7,
  'catId': 2,
  'quest': 'What if I need to wait for cashback for long time?',
  'ans': 'The cashback process demands a final confirmation from the store to confirm the purchase. Meanwhile,merchants validate that the sale meets conditions for earning requisite cashback. Usually this process maytake 8-10 weeks. Our team constantly coordinates with stores to reduce this wait period and to avoid anydiscrepancy and providing better service we may usually take 4-8 weeks for a transaction to be confirmed.In case your cashback is pending even after 60 days from the date of purchase, kindly reach out to ourcustomer support at hello@rewardeagle.com..'
}, {
  'id': 8,
  'catId': 2,
  'quest': 'How can I track my cashback activities?',
  'ans': 'Generally, it can take upto 56 hours for cashback to get tracked. In case your transaction is not tracked evenafter mentioned duration, kindly reach out to our customer support at hello@rewardeagle.com.'
}, {
  'id': 9,
  'catId': 3,
  'quest': 'I have not received my withdrawal amount.',
  'ans': "We're sorry that you are facing a problem with your withdrawal. Please reach out to our Customer Care teamat hello@rewardeagle.com for assistance in resolving this issue."
}, {
  'id': 10,
  'catId': 3,
  'quest': 'What is the validity of my available balance? What can I do with my available balance? Does the money in my account expire?',
  'ans': 'All the available money generated via Reward Eagle is eligible to withdrawal as per our withdrawal policy. Youcan also recharge online wallet, phone or DTH accounts or even transferred to your bank account. The moneyin your account never expires and is subject to withdrawal as per user suitability..'
}, {
  'id': 11,
  'catId': 3,
  'quest': 'Is KYC necessary to withdraw my balance?',
  'ans': 'Yes, as per guidelines every user needs to successfully complete their KYC to enable themselves to withdrawmoney. Every account holds one integrated bank details for the better accountability and smooth services..'
}, {
  'id': 12,
  'catId': 3,
  'quest': 'How can I withdraw my balance?',
  'ans': 'To withdraw your balance, log in to your Reward Eagle account and visit the Cashback Activity in your MyAccount, or just click here. <ul><li>Select the method of withdrawal, bank, e-wallet or recharge.</li><li>Select the account where you wish to transfer your Available Balance.</li><li>Enter the amount and hit Submit.</li><li>Bank transfers take between 5-7 business days to reflect in your account. eWallet and Recharge transactions are almost instantaneous but can take upto 48 hours to reflect in your account.Also, there is absolutely no cost or fees applicable to withdrawing your balance.</li></ul><p><strong>Note:</strong> Cashback earned from some merchants cannot be withdrawn to a bank account and is listed separatelyas rewards. Minimum withdrawal limits apply.</p>'
}, {
  'id': 13,
  'catId': 3,
  'quest': 'What are the minimum withdrawal limits?',
  'ans': 'The minimum withdrawal amount is set to Rs. 200 for all payment options.You can withdraw your balance to your Bank Account, Amazon Pay Balance, PayTM wallet, Freecharge walletand recharge your mobile phones and DTH.'
}, {
  'id': 14,
  'catId': 3,
  'quest': 'Can I transfer my balance to another Reward Eagle account?',
  'ans': 'Sorry, we do not allow intra-account transfer of available balance. A user can withdraw successfully only totheir RE verified accounts.'
}, {
  'id': 15,
  'catId': 3,
  'quest': "I'm getting an error while withdrawing my balance. What do I do?",
  'ans': "We're sorry that you are facing a problem with your withdrawal. Please reach out to our Customer Care teamat hello@rewardeagle.com for assistance in resolving this issue."
}, {
  'id': 16,
  'catId': 4,
  'quest': 'How can I check the exact cashback rate for my planned purchase?',
  'ans': '<p>To get a transparent clarity on the cashback rates applicable on your purchase, kindly visit any specificmerchant page and check ‘Rewards Rates’ on the left column. Click on ‘View More’ for the exact cashbackrates offered by that merchant on your purchase, as per below mentioned conditions:</p><ul><li>Whether you are a new user or an existing user on the merchant site</li><li>The cashback rate applicable to the specific category of product you have purchased</li><li>The merchant platform (Desktop / Mobile web / Android / iOS) which you are using to make thepurchase.</li></ul>'
}, {
  'id': 17,
  'catId': 4,
  'quest': 'Does the tracked pending cashback is only an estimate?',
  'ans': 'Pending cashback transactions are indicative and can change upon final confirmation from store.On any purchase made by a user, the corresponding transaction is tracked by the merchant store who in turnshare only the relevant information required to track cashback. Factors such as a new user or an existing useror the platform used (Desktop / App / Mobile web etc.), and the specific product category for the item youhave purchased influences the cashback rate. However, the complete tracking information is not provided bythe merchant to us and thus we cannot always accurately estimate your cashback amount.In case your cashback transaction was confirmed for an incorrect amount, please file a Missing Cashback Claimfor Incorrect Amount and share us at hello@rewardeagle.com.'
}, {
  'id': 18,
  'catId': 4,
  'quest': 'How long does it take to confirm the Cashback?',
  'ans': 'The perquisite condition for any cashback activity requires the final confirmation from the merchant in contextwith the sale of products, that is to say that the purchase was not returned or exchanged. Meanwhile, themerchants validate the sale to meet conditions required to earn cashback.Our team constantly coordinates with stores to reduce this wait period and to avoid any discrepancy andproviding better service we may usually take 4-8 weeks for a transaction to be confirmed.'
}, {
  'id': 19,
  'catId': 4,
  'quest': 'Does any offer carry no cashback?',
  'ans': 'Yes, there are stores and offers on which there is no cashback applicable. But we track those transactions toensure the loyalty benefits to our users..'
}, {
  'id': 20,
  'catId': 4,
  'quest': 'What happens to my transaction if my cashback is cancelled?',
  'ans': 'In case your cashback is cancelled by the retailer, the cashback amount for that transaction gets removed fromyour pending balance automatically with the status as cancelled. The merchant store holds sole discretion indetermining the validity of a transaction and holds the final binding decision.'
}, {
  'id': 21,
  'catId': 5,
  'quest': 'How can I share the business proposal to Reward Eagle?',
  'ans': 'Please send us an email at hello@rewardeagle.com.'
}, {
  'id': 22,
  'catId': 6,
  'quest': 'Looking for a missed Offer!! Couldn’t find it now?',
  'ans': 'Almost all coupons and offers come with a validity period and are only valid until promotion lasts. On reachingthe expiration date, the corresponding coupons and offers are automatically removed from our Website.This is done to ensure that you have a great all-around experience and do not attempt to use offers which nolonger work.'
}, {
  'id': 23,
  'catId': 6,
  'quest': 'What are RE Voucher Rewards?',
  'ans': 'RE Voucher rewards are special cashback that you get from specific stores and with certain constraints. Forexample, Amazon allows us to give Cashback only redeemable as Amazon Pay Balance. It means, you can earnCashback on your Amazon shopping but you cannot transfer that cashback to your Bank or Wallet everytimeyou make a purchase. Instead, the rewards can be used as the Gift Cards option for withdrawing AmazonCashback.'
}, {
  'id': 24,
  'catId': 6,
  'quest': 'What are RE Rewards?',
  'ans': '<p>Reward Eagle rewards their users for online purchases made in the form of cashback which can be redeemeddirectly to your wallet. Some stores like Flipkart, Snapdeal allow cashback earned from them to be used onlyfor transfers to an online wallet like PayTM; or making a mobile phone or DTH recharge. These cashbacks aretermed as RE Rewards.</p><p><strong>Note:</strong> Any stores carrying Rewards instead of Cashback will explicitly mention them on the respective storepages. The majority of stores do not carry rewards.</p>'
}, {
  'id': 25,
  'catId': 6,
  'quest': 'What is RE Cashback?',
  'ans': '<p>Reward Eagle grants additional cashback on your online purchases in addition to the discounts provided by the store merchant.</p><ul><li>To earn cashback, please ensure that you get redirected to the store only via the Reward Eagle linkand make your purchase.</li><li>Once your purchase is completed, we usually track it within 48 hours and your cashback is added toyour pending balance.</li><li>Stores wait for the return and exchange period to be over before giving us the final confirmation ofthe sale. This process can usually take 5-8 weeks depending on the store.</li><li>Once we receive final confirmation of the sale from the merchant your pending cashback is madeavailable for you to use.</li><li>Cashback earned from Reward Eagle is your money and can be used to recharge online wallet, phoneor DTH accounts, or even transferred to your bank account.</li><p><strong>Note:</strong> Amount added to your pending balance is indicative and may change upon final confirmation from thestore.</p>'
}, {
  'id': 26,
  'catId': 7,
  'quest': 'How to ensure on getting cashback?',
  'ans': '<p>Below mentioned points ensure that your cashback tracks properly</p><ul><li>Be logged into your Reward Eagle account.</li><li>Ensure that you are shopping at a store that offers desired cashback.</li><li>When you click an offer or store or get deals, Reward Eagle redirects you to the correspondingmerchant store page. Please ensure that you transact in the opened window.</li><li>Please ensure that your shopping cart is empty in the shopping window. If it is not empty please clearthe contents of your cart and visit the store via Reward Eagle again.</li><li>Do not use any price comparison or discount widgets while shopping.</li></ul>'
}, {
  'id': 27,
  'catId': 7,
  'quest': 'How to ensure on getting cashback?',
  'ans': 'We recommend that you wait for at least 56 hours after the transaction is made. In cases where a transactionwas not tracked automatically even after 56 hours, kindly reach our customer support at hello@rewardeagle.com and share the nature of your transaction in detail.'
}, {
  'id': 28,
  'catId': 8,
  'quest': 'Can I create and use multiple accounts?',
  'ans': 'No, one account is valid per user after the successful KYC completion. This is to offer transparent and better services via rewarding our users with exciting rewards for their online transactions.'
}, {
  'id': 29,
  'catId': 8,
  'quest': 'Can I interchange my login social IDs while login ?',
  'ans': '<p>If you signed up using your email id and password, you can login using both Facebook and Google (only ifFacebook and Google accounts are created with the same email ID).</p><p>If you signed up using Google, you can login with Facebook but not with your email id and password (only if Facebook and Google accounts have been created with the same email ID).</p>If you signed up using Facebook, you can login with Google account (email id on google and Facebook account needs to be the same)</p>'
}, {
  'id': 30,
  'catId': 8,
  'quest': 'Can I change my email address on my account?',
  'ans': 'Currently we do not provide such feature to change the mail ID directly. Though, you can share the query to usat hello@rewardeagle.com.'
}, {
  'id': 31,
  'catId': 8,
  'quest': 'How can I subscribe to Reward Eagle promotional mails?',
  'ans': 'To approve email subscriptions please login to your Reward Eagle My Account and subscribe us.'
}, {
  'id': 32,
  'catId': 8,
  'quest': 'How can I unsubscribe to Reward Eagle promotional mails?',
  'ans': 'To stop email subscriptions please login to your Reward Eagle My Account and unsubscribe us.'
}, {
  'id': 33,
  'catId': 8,
  'quest': 'How can I close my account?',
  'ans': 'We’re sorry, but currently we do not provide an option to deactivate your Reward Eagle account. You canunsubscribe from all Reward Eagle emails to stop any communication from Reward Eagle. Please be assuredthat we do not share your details with any third parties and we promise not to spam.'
}];
exports.faqQA = faqQA;
const interest = [{
  'value': "Travel",
  'text': 'Travel'
}, {
  'value': "Cooking",
  'text': 'Cooking'
}, {
  'value': "Books",
  'text': 'Books'
}, {
  'value': "Music",
  'text': 'Music'
}, {
  'value': "Shopping",
  'text': 'Shopping'
}, {
  'value': "Movie",
  'text': 'Movie'
}, {
  'value': "Megastores",
  'text': 'Megastores'
}, {
  'value': "Electronics",
  'text': 'Electronics'
}, {
  'value': "Home living",
  'text': 'Home living'
}, {
  'value': "Social Work",
  'text': 'Social Work'
}, {
  'value': "Fashion",
  'text': 'Fashion'
}, {
  'value': "DIY",
  'text': 'DIY'
}, {
  'value': "Driving",
  'text': 'Driving'
}, {
  'value': "Camera",
  'text': 'Camera'
}, {
  'value': "Swiming",
  'text': 'Swiming'
}, {
  'value': "Internet",
  'text': 'Internet'
}, {
  'value': "Game",
  'text': 'Game'
}, {
  'value': "SNS",
  'text': 'SNS'
}, {
  'value': "Exercise",
  'text': 'Exercise'
}, {
  'value': "Walking",
  'text': 'Walking'
}, {
  'value': "Workout",
  'text': 'Workout'
}, {
  'value': "Eating",
  'text': 'Eating'
}, {
  'value': "Other",
  'text': 'Other'
}];
exports.interest = interest;
const occupation = [{
  'value': "Accounting/Finance",
  'text': " Accounting/Finance"
}, {
  'value': "Administrative",
  'text': " Administrative"
}, {
  'value': "Advertising",
  'text': " Advertising"
}, {
  'value': "Architecture",
  'text': " Architecture"
}, {
  'value': "Artist/Actor/Creative/Performer",
  'text': " Artist/Actor/Creative/Performer"
}, {
  'value': "Aviation/Airlines",
  'text': " Aviation/Airlines"
}, {
  'value': "Banking/Financial",
  'text': " Banking/Financial"
}, {
  'value': "Bio-Pharmaceutical",
  'text': " Bio-Pharmaceutical"
}, {
  'value': "Bookkeeper",
  'text': "Bookkeeper"
}, {
  'value': "Builder",
  'text': "Builder"
}, {
  'value': "Business",
  'text': "Business"
}, {
  'value': "Celebrity",
  'text': "Celebrity"
}, {
  'value': "Chef",
  'text': "Chef"
}, {
  'value': "Clerical",
  'text': "Clerical"
}, {
  'value': "Computer Related (hardware)",
  'text': "Computer Related (hardware"
}, {
  'value': "Computer Related (IT)",
  'text': "Computer Related (IT"
}, {
  'value': "Computer Related (software)",
  'text': "Computer Related (software"
}, {
  'value': "Consulting",
  'text': "Consulting"
}, {
  'value': "Craftsman/Construction",
  'text': "Craftsman/Construction"
}, {
  'value': "Customer Support",
  'text': "Customer Support"
}, {
  'value': "Designer",
  'text': "Designer"
}, {
  'value': "Doctor",
  'text': "Doctor"
}, {
  'value': "Educator/Academic",
  'text': "Educator/Academic"
}, {
  'value': "Engineering/Architecture",
  'text': "Engineering/Architecture"
}, {
  'value': "Entertainment",
  'text': "Entertainment"
}, {
  'value': "Environmental",
  'text': "Environmental"
}, {
  'value': "Executive/Senior Management",
  'text': "Executive/Senior Management"
}, {
  'value': "Farmer",
  'text': "Farmer"
}, {
  'value': "Finance",
  'text': "Finance"
}, {
  'value': "Flight Attendant",
  'text': "Flight Attendant"
}, {
  'value': "Food Services",
  'text': "Food Services"
}, {
  'value': "Government",
  'text': "Government"
}, {
  'value': "Homemaker",
  'text': "Homemaker"
}, {
  'value': "Household",
  'text': "Household"
}, {
  'value': "Human Resources",
  'text': "Human Resources"
}, {
  'value': "Industrial",
  'text': "Industrial"
}, {
  'value': "Insurance",
  'text': "Insurance"
}, {
  'value': "Lawyer",
  'text': "Lawyer"
}, {
  'value': "Legal Professions",
  'text': "Legal Professions"
}, {
  'value': "Medical/Healthcare",
  'text': "Medical/Healthcare"
}, {
  'value': "Management",
  'text': "Management"
}, {
  'value': "Manufacturing/Operations",
  'text': "Manufacturing/Operations"
}, {
  'value': "Marine",
  'text': "Marine"
}, {
  'value': "Marketing",
  'text': "Marketing"
}, {
  'value': "Media",
  'text': "Media"
}, {
  'value': "Medical/Healthcare",
  'text': "Medical/Healthcare"
}, {
  'value': "Military",
  'text': "Military"
}, {
  'value': "Musician",
  'text': "Musician"
}, {
  'value': "Nurse",
  'text': "Nurse"
}, {
  'value': "Political",
  'text': "Political"
}, {
  'value': "Professor",
  'text': "Professor"
}, {
  'value': "Public Relations",
  'text': "Public Relations"
}, {
  'value': "Public Sector",
  'text': "Public Sector"
}, {
  'value': "Publishing",
  'text': "Publishing"
}, {
  'value': "Real Estate",
  'text': "Real Estate"
}, {
  'value': "Recreation",
  'text': "Recreation"
}, {
  'value': "Research/Scientist",
  'text': "Research/Scientist"
}, {
  'value': "Retail",
  'text': "Retail"
}, {
  'value': "Retired",
  'text': "Retired"
}, {
  'value': "Sales",
  'text': "Sales"
}, {
  'value': "Secretary",
  'text': "Secretary"
}, {
  'value': "Self Employed",
  'text': "Self Employed"
}, {
  'value': "Service Industry",
  'text': "Service Industry"
}, {
  'value': "Social Science",
  'text': "Social Science"
}, {
  'value': "Social Services",
  'text': "Social Services"
}, {
  'value': "Sports",
  'text': "Sports"
}, {
  'value': "Student",
  'text': "Student"
}, {
  'value': "Teaching",
  'text': "Teaching"
}, {
  'value': "Technical",
  'text': "Technical"
}, {
  'value': "Technician",
  'text': "Technician"
}, {
  'value': "Telecommunications",
  'text': "Telecommunications"
}, {
  'value': "Transportation/Logistics",
  'text': "Transportation/Logistics"
}, {
  'value': "Travel/Hospitality/Tourism",
  'text': "Travel/Hospitality/Tourism"
}, {
  'value': "Unemployed",
  'text': "Unemployed"
}, {
  'value': "Other",
  'text': "Other"
}];
exports.occupation = occupation;
const salary = [{
  'value': "Up to 2 Lakh",
  'text': "Up to 2 Lakh"
}, {
  'value': "2-5 Lakh",
  'text': "2-5 Lakh"
}, {
  'value': "5-10 Lakh",
  'text': "5-10 Lakh"
}, {
  'value': "10-20 Lakh",
  'text': "10-20 Lakh"
}, {
  'value': "20-50 Lakh",
  'text': "20-50 Lakh"
}];
exports.salary = salary;
const count = [{
  'id': 1,
  'locked': 50,
  'points': 5
}, {
  'id': 2,
  'locked': 100,
  'points': 10
}, {
  'id': 3,
  'locked': 150,
  'points': 15
}, {
  'id': 4,
  'locked': 200,
  'points': 20
}, {
  'id': 5,
  'locked': 250,
  'points': 25
}, {
  'id': 6,
  'locked': 300,
  'points': 30
}, {
  'id': 7,
  'locked': 350,
  'points': 35
}, {
  'id': 8,
  'locked': 400,
  'points': 40
}, {
  'id': 9,
  'locked': 450,
  'points': 45
}, {
  'id': 10,
  'locked': 500,
  'points': 50
}, {
  'id': 11,
  'locked': 550,
  'points': 55
}, {
  'id': 12,
  'locked': 600,
  'points': 60
}, {
  'id': 13,
  'locked': 650,
  'points': 65
}, {
  'id': 14,
  'locked': 700,
  'points': 70
}, {
  'id': 15,
  'locked': 750,
  'points': 75
}, {
  'id': 16,
  'locked': 800,
  'points': 80
}, {
  'id': 17,
  'locked': 850,
  'points': 85
}, {
  'id': 18,
  'locked': 900,
  'points': 100
}];
exports.count = count;
const adminLinks = [{
  main: true,
  cat: 1,
  text: "Products",
  active: "/products"
}, // { main: false, subcat: 1, url: "/admin/createStore", text: "Add Store", active: "/admin/createStore" },
{
  main: false,
  subcat: 1,
  url: "/admin/adminStore",
  text: "Store",
  active: "/admin/adminStore"
}, {
  main: false,
  subcat: 1,
  url: "/admin/adminCategory",
  text: "Category",
  active: "/admin/adminCategory"
}, {
  main: false,
  subcat: 1,
  url: "/admin/adminCoupon",
  text: "Coupon",
  active: "/admin/adminCoupon"
}, {
  main: false,
  subcat: 1,
  url: "/admin/adminDeal",
  text: "Deal",
  active: "/admin/adminDeal"
}, {
  main: true,
  cat: 2,
  text: "SEO",
  active: "/seo"
}, {
  main: false,
  subcat: 2,
  url: "/admin/meta",
  text: "Meta",
  active: "/admin/meta"
}, {
  main: false,
  subcat: 2,
  url: "/admin/blogmeta",
  text: "Blog Meta",
  active: "/admin/blogmeta"
}, {
  main: false,
  subcat: 2,
  url: "/admin/refSchema",
  text: "RefSchema",
  active: "/admin/refSchema"
}, {
  main: false,
  subcat: 2,
  url: "/admin/refSitemap",
  text: "RefSitemap",
  active: "/admin/refSitemap"
}, {
  main: true,
  cat: 3,
  text: "Operations",
  active: "/operations"
}, {
  main: false,
  subcat: 3,
  url: "/admin/users",
  text: "Users",
  active: "/admin/users"
}, {
  main: false,
  subcat: 3,
  url: "/admin/basics",
  text: "Basics",
  active: "/admin/basics"
}, {
  main: false,
  subcat: 3,
  url: "/admin/blogs",
  text: "Blogs",
  active: "/admin/blogs"
}, {
  main: false,
  subcat: 3,
  url: "/admin/career",
  text: "Career",
  active: "/admin/career"
}, {
  main: false,
  subcat: 3,
  url: "/admin/questionBank",
  text: "QuestionBank",
  active: "/admin/questionBank"
}, {
  main: false,
  subcat: 3,
  url: "/admin/survey",
  text: "Survey",
  active: "/admin/survey"
}, {
  main: false,
  subcat: 3,
  url: "/admin/advertisement",
  text: "Advertisement",
  active: "/admin/advertisement"
}, {
  main: true,
  cat: 4,
  text: "Transactions",
  active: "/transactions"
}, {
  main: false,
  subcat: 4,
  url: "/admin/leaderboard",
  text: "Leaderboard",
  active: "/admin/leaderboard"
}, {
  main: false,
  subcat: 4,
  url: "/admin/vendorApi",
  text: "Vendor API",
  active: "/admin/vendorApi"
}, {
  main: false,
  subcat: 4,
  url: "/admin/cashout",
  text: "CashOut",
  active: "/admin/cashout"
}, {
  main: false,
  subcat: 4,
  url: "/admin/adminCashback",
  text: "Cashback",
  active: "/admin/adminCashback"
}, {
  main: true,
  cat: 5,
  text: "Responses",
  active: "/responses"
}, {
  main: false,
  subcat: 5,
  url: "/admin/subscription",
  text: "Subscription",
  active: "/admin/subscription"
}, {
  main: false,
  subcat: 5,
  url: "/admin/survey-response",
  text: "Survey Response",
  active: "/admin/survey-response"
}, {
  main: false,
  subcat: 5,
  url: "/admin/comments",
  text: "Comments",
  active: "/admin/comments"
}, {
  main: false,
  subcat: 5,
  url: "/admin/job-applications",
  text: "Resume",
  active: "/admin/job-applications"
}, {
  main: false,
  subcat: 5,
  url: "/admin/contacts",
  text: "Contact",
  active: "/admin/contacts"
}, {
  main: true,
  cat: 6,
  text: "Reports",
  active: "/reports"
}, {
  main: false,
  subcat: 6,
  url: "/admin/summary",
  text: "Report",
  active: "/admin/summary"
}];
exports.adminLinks = adminLinks;
const userLinks = [{
  url: "/user/my-account",
  text: "My Account",
  active: "/user/my-account"
}, {
  url: "/user/my-profile",
  text: "My Profile",
  active: "/user/my-profile"
}, {
  url: "/user/cashback-reward",
  text: "Cashback Reward",
  active: "/user/cashback-reward"
}, {
  url: "/user/refer-and-earn",
  text: "Refer & Earn",
  active: "/user/refer-and-earn"
}, {
  url: "/user/your-surveys",
  text: "Your Surveys",
  active: "/user/your-surveys"
}, {
  url: "/user/cashback-history",
  text: "Cashback History",
  active: "/user/cashback-history"
}, {
  url: "/user/applied-jobs",
  text: "Applied jobs",
  active: "/user/applied-jobs"
}];
exports.userLinks = userLinks;
const sideLinks = [{
  url: "/about-us",
  text: "About Us"
}, {
  url: "/blog",
  text: "Blogs"
}, {
  url: "/stores",
  text: "Stores"
}, {
  url: "/category",
  text: "Category"
}, {
  url: "/career",
  text: "Career"
}, {
  url: "/user/refer-and-earn",
  text: "Refer & Earn"
}, {
  url: "/survey",
  text: "Survey"
}, {
  url: "/faq",
  text: "FAQ"
}, {
  url: "/contact-us",
  text: "Contact Us"
}];
exports.sideLinks = sideLinks;