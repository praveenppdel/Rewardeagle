"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.NewsLetter = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _axios = _interopRequireDefault(require("axios"));

const func = require('../parts/functions');

class NewsLetter extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "submitHandler", e => {
      e.preventDefault();
      const data = {
        email: this.state.email
      };

      _axios.default.post('/admin/subscribe', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          localStorage.setItem('message', res.data.message);
          window.location.href = '/stores';
        }

        func.callSwal(res.data.message);
        this.setState({
          email: ''
        });
      });
    });
    this.state = {
      email: ''
    };
  }

  render() {
    return /*#__PURE__*/_react.default.createElement("section", {
      className: "newsletter"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("h3", null, "SUBSCRIBE US TO AVAIL MORE BENEFITS"), /*#__PURE__*/_react.default.createElement("p", null, "Shop what you love and save upto 90% off.")), /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "email",
      name: "email",
      value: this.state.email,
      onChange: this.onChange,
      placeholder: "Subscribe With Us"
    }), /*#__PURE__*/_react.default.createElement("button", {
      className: "form-control kohei button"
    }, "Subscribe")));
  }

}

exports.NewsLetter = NewsLetter;
var _default = NewsLetter;
exports.default = _default;