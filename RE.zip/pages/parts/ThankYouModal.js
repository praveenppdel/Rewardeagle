"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.ThankYouModal = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _reactstrap = require("reactstrap");

class ThankYouModal extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        addmodalIsOpen: false
      });
    });
    this.state = {
      addmodalIsOpen: true
    };
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.props.showModal ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.addmodalIsOpen,
      className: "adminModal thankYouModal"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/thankyou.png"
    }), /*#__PURE__*/_react.default.createElement("p", null, this.props.text), /*#__PURE__*/_react.default.createElement("p", null, /*#__PURE__*/_react.default.createElement("span", null, "Congratulations!!"), " Your reward points will be transferred to your account after successful verification."), /*#__PURE__*/_react.default.createElement("div", {
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/survey",
      className: "casleyBtn mr-3"
    }, "Participate in more survey"), /*#__PURE__*/_react.default.createElement("a", {
      href: "/user/my-account",
      className: "casleyBtn"
    }, "Go to dashboard"))))) : null);
  }

}

exports.ThankYouModal = ThankYouModal;
var _default = ThankYouModal;
exports.default = _default;