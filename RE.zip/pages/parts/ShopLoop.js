"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.ShopLoop = void 0;

var _react = _interopRequireWildcard(require("react"));

class ShopLoop extends _react.Component {
  render() {
    return /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    });
  }

}

exports.ShopLoop = ShopLoop;
var _default = ShopLoop;
exports.default = _default;