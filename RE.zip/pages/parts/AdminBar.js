"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.AdminBar = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

const func = require('./functions');

class AdminBar extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "activeDropDown", (id, act) => {
      console.log(`id`, id, act);

      if (this.state.activeDd == id) {
        this.setState({
          activeDd: '',
          active: ''
        });
      } else {
        this.setState({
          activeDd: id,
          active: act
        });
      }
    });
    this.state = {
      active: '',
      activeDd: '',
      activeUrl: '',
      user: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      });
    }

    this.setState({
      activeUrl: window.location.pathname
    }); // if(window.location.pathname === '/admin/admin'){ this.setState({ active: '/admin/users' }) }
    // if(window.location.pathname === '/admin/addBlog'){ this.setState({ active: '/admin/blogs' }) }
    // if(window.location.pathname.split("/")[2] === 'updateBlog'){ this.setState({ active: '/admin/blogs' }) }
    // // if(window.location.pathname === '/admin/createStore'){ this.setState({ active: '/admin/adminStore' }) }
    // if(window.location.pathname.split("/")[2] === 'updateStore'){ this.setState({ active: '/admin/adminStore' }) }
    // if(window.location.pathname.split("/")[2] === 'updateDeal'){ this.setState({ active: '/admin/adminDeal' }) }
  }

  render() {
    console.log(`this.state`, this.state);
    return /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 adminSidebar"
    }, this.state.user.role ? /*#__PURE__*/_react.default.createElement("ul", {
      className: "my-5"
    }, this.state.user.role === "Admin" ? func.adminLinks.filter(i => i.main).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index,
      className: this.state.active === i.active ? "active" : null,
      onClick: () => this.activeDropDown(i.cat, i.active)
    }, i.text, /*#__PURE__*/_react.default.createElement("ul", {
      className: this.state.activeDd == i.cat ? 'showDd' : null
    }, func.adminLinks.filter(j => !j.main).filter(j => j.subcat == i.cat).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index,
      className: this.state.activeUrl === i.active ? "active" : null
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url
    }, i.text)))))) : this.state.user.role === "User" ? func.userLinks.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      className: this.state.active === i.active ? "active" : null
    }, i.text))) : null) : null);
  }

}

exports.AdminBar = AdminBar;
var _default = AdminBar;
exports.default = _default;