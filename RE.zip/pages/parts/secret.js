"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.password = exports.username = exports.payOutAPI = exports.getAccountDetail = exports.accessTokenAPI = exports.payuClientId = exports.payoutMerchantId = exports.webhookData = exports.grant_type = exports.scope = exports.grant_refresh_token = exports.vcToken = exports.inrId = exports.inrToken = exports.fbAppId = exports.clientSecret = exports.clientId = void 0;
// Google
const clientId = '915022609455-gv870i2eefdcl20c41tl4o02nbjr6kno.apps.googleusercontent.com';
exports.clientId = clientId;
const clientSecret = 'g0tpSKG9EjKQnV1OsuZmSjEq'; // FB

exports.clientSecret = clientSecret;
const fbAppId = "764859870817527"; // APIs

exports.fbAppId = fbAppId;
const inrToken = "n7d8uqko19n4l4cz";
exports.inrToken = inrToken;
const inrId = "nav69787557";
exports.inrId = inrId;
const vcToken = "bf9518e15f52378d18d471216e1d9dc223e867a56ea44d23ca2c8bbc230e8262";
exports.vcToken = vcToken;
const grant_refresh_token = "refresh_token";
exports.grant_refresh_token = grant_refresh_token;
const scope = "create_payout_transactions";
exports.scope = scope;
const grant_type = "password"; // Development
// export const key =                      "cCJaBWSW"
// export const salt =                     "vZTnGbBRBV"
// export const payoutMerchantId=          "1111123"
// export const payuClientId =             "6f8bb4951e030d4d7349e64a144a534778673585f86039617c167166e9154f7e"
// export const payuClientSecret =         "18f70adc78dbb685d91d81a34c53cb72e373faddf48918152af3b82ff4790f2d"
// export const accessTokenAPI=            "https://cors-anywhere.herokuapp.com/https://uat-accounts.payu.in/oauth/token"
// export const getAccountDetail=          "https://cors-anywhere.herokuapp.com/https://test.payumoney.com/payout/merchant/getAccountDetail"
// export const payOutAPI=                 "https://cors-anywhere.herokuapp.com/https://test.payumoney.com/payout/payment"
// export const webhook=                   "https://cors-anywhere.herokuapp.com/https://test.payumoney.com/payout/saveWebhook"

exports.grant_type = grant_type;
const webhookData = {
  "default": "http://localhost:3000/admin/payuresponse"
}; // export const username=                  "payouttest4@mailinator.com"
// export const password=                  "Tester@123"
//Production

exports.webhookData = webhookData;
const payoutMerchantId = "1111193";
exports.payoutMerchantId = payoutMerchantId;
const payuClientId = "ccbb70745faad9c06092bb5c79bfd919b6f45fd454f34619d83920893e90ae6b"; // export const payuClientSecret =           "18f70adc78dbb685d91d81a34c53cb72e373faddf48918152af3b82ff4790f2d"

exports.payuClientId = payuClientId;
const accessTokenAPI = "https://cors-anywhere.herokuapp.com/https://accounts.payu.in/oauth/token";
exports.accessTokenAPI = accessTokenAPI;
const getAccountDetail = "https://cors-anywhere.herokuapp.com/https://payout.payumoney.com/payout/merchant/getAccountDetail";
exports.getAccountDetail = getAccountDetail;
const payOutAPI = "https://cors-anywhere.herokuapp.com/https://payout.payumoney.com/payout/payment"; // export const webhook=                   "https://test.payumoney.com/payout/saveWebhook" 

exports.payOutAPI = payOutAPI;
const username = "kohei.serizawa@casleyconsulting.co.jp";
exports.username = username;
const password = "Payu@1234";
exports.password = password;