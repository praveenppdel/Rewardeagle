"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.RecommendedAds = void 0;

var _react = _interopRequireWildcard(require("react"));

class RecommendedAds extends _react.Component {
  componentDidMount() {
    (window.adsbygoogle = window.adsbygoogle || []).push({});
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.props.ads ? /*#__PURE__*/_react.default.createElement("section", {
      className: "recommended"
    }, this.props.ads.filter(i => i.type == 11 || i.type == 12 || i.type == 13).length ? /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "New deals Onboard"), /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2"
    }, /*#__PURE__*/_react.default.createElement("ins", {
      className: "adsbygoogle",
      style: {
        display: 'block'
      },
      "data-ad-client": "ca-pub-3464486838908135",
      "data-ad-slot": "4089050875",
      "data-ad-format": "auto",
      "data-full-width-responsive": "true"
    })), this.props.ads.filter(i => i.type == 11).slice(0, 2).map((i, index) => /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4",
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      target: i.target == 1 ? "_blank" : ""
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/ads/" + i.image
    })))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2"
    }, /*#__PURE__*/_react.default.createElement("ins", {
      className: "adsbygoogle",
      style: {
        display: 'block'
      },
      "data-ad-client": "ca-pub-3464486838908135",
      "data-ad-slot": "6576672905",
      "data-ad-format": "auto",
      "data-full-width-responsive": "true"
    })))) : null) : null);
  }

}

exports.RecommendedAds = RecommendedAds;
var _default = RecommendedAds;
exports.default = _default;