"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.UserBar = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

const func = require('./functions');

class UserBar extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/userData/' + this.state.user.id);
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);

      if (body.data) {
        this.setState({
          data: body.data
        });
      }

      const response2 = await fetch('/admin/userAccounts/' + this.state.user.id);
      const body2 = await response2.json();
      if (response2.status !== 200) throw Error(body2.message);
      const xx = body2.pending.reduce((sum, i) => sum + i.customerPayout, 0);
      this.setState({
        cashData: body2.data,
        pending: xx
      });
    });
    this.state = {
      active: '',
      user: [],
      data: '',
      cashData: '',
      pending: ''
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    if (typeof Storage !== "undefined") {
      this.setState({
        user: JSON.parse(localStorage.getItem('user')) || []
      }, () => this.callApi());
    }

    this.setState({
      active: window.location.pathname
    });

    if (window.location.pathname === '/admin/admin') {
      this.setState({
        active: '/admin/users'
      });
    }

    if (window.location.pathname === '/admin/addBlog') {
      this.setState({
        active: '/admin/blogs'
      });
    }

    if (window.location.pathname.split("/")[2] === 'updateBlog') {
      this.setState({
        active: '/admin/blogs'
      });
    }

    if (window.location.pathname === '/admin/createStore') {
      this.setState({
        active: '/admin/adminStore'
      });
    }

    if (window.location.pathname.split("/")[2] === 'updateStore') {
      this.setState({
        active: '/admin/adminStore'
      });
    }
  }

  render() {
    return /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-2 userBar mt-5 web"
    }, this.state.data.image ? /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/profile/" + this.state.data.image
    }) : null, /*#__PURE__*/_react.default.createElement("p", {
      className: "userCash"
    }, "\u20B9", this.state.cashData ? this.state.cashData.cashback : 0, " Available"), /*#__PURE__*/_react.default.createElement("p", {
      className: "userCash"
    }, "\u20B9", this.state.pending ? this.state.pending : 0, " Pending"), /*#__PURE__*/_react.default.createElement("p", {
      className: "mycashback"
    }, "Reward Points: ", this.state.cashData ? this.state.cashData.reward : 0), this.state.user.role ? /*#__PURE__*/_react.default.createElement("ul", {
      className: "my-5 web"
    }, func.userLinks.map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: i.url,
      className: this.state.active === i.active ? "active" : null
    }, i.text)))) : null);
  }

}

exports.UserBar = UserBar;
var _default = UserBar;
exports.default = _default;