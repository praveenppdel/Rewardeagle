"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Footer = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

class Footer extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/footerData');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        store: body.store,
        coupon: body.coupon,
        deal: body.deal,
        blog: body.blog
      });
    });
    this.state = {
      store: [],
      coupon: [],
      deal: [],
      blog: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("footer", null, /*#__PURE__*/_react.default.createElement("div", {
      className: "container py-3"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Latest Offers"), /*#__PURE__*/_react.default.createElement("ul", null, this.state.store.slice(0, 10).map((i, index) => /*#__PURE__*/_react.default.createElement("li", {
      key: index
    }, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores/" + i.url
    }, i.name))))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Quick Links"), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/blog"
    }, "Blog")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/faq"
    }, "FAQ")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/career"
    }, "Career")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/survey"
    }, "Survey")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/user/refer-and-earn"
    }, "Refer and Earn")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/privacy-policy"
    }, "Privacy Policy")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/terms-and-conditions"
    }, "T & C")))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "Company"), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/about-us"
    }, "About Us")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/contact-us"
    }, "Contact Us")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/how-it-works"
    }, "How It Works")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/vision-and-mission"
    }, "Vision & Mission")))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("h3", null, "General"), /*#__PURE__*/_react.default.createElement("ul", null, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/user/my-account"
    }, "My Account")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/user/cashback-reward"
    }, "Cashback Rewards")))))), /*#__PURE__*/_react.default.createElement("div", {
      className: "social"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "social-container"
    }, /*#__PURE__*/_react.default.createElement("ul", {
      className: "social-icons"
    }, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      target: "_blank",
      href: "https://www.facebook.com/rewardeagle"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/facebook-white.svg",
      className: "first"
    }), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/facebook.svg",
      className: "second"
    }))), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      target: "_blank",
      href: "https://www.linkedin.com/company/20445385/admin/"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/linkedin-white.svg",
      className: "first"
    }), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/linkedin.svg",
      className: "second"
    }))), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      target: "_blank",
      href: "https://twitter.com/Reward_Eagle"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/twitter-white.svg",
      className: "first"
    }), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/twitter.svg",
      className: "second"
    }))), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      target: "_blank",
      href: "https://www.instagram.com/rewardeagle_india/"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/instagram-white.svg",
      className: "first"
    }), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/instagram.svg",
      className: "second"
    }))), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      target: "_blank",
      href: "//api.whatsapp.com/send?phone=919695871040&text= Hi, I got your number from Reward Eagle Website."
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/whatsapp-white.svg",
      className: "first"
    }), /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/whatsapp-button.svg",
      className: "second"
    }))))), /*#__PURE__*/_react.default.createElement("span", {
      className: "mr-3"
    }, "Copyrights 2021, Casley India Pvt.Ltd."), /*#__PURE__*/_react.default.createElement("span", null, "Email: hello@rewardeagle.com"))), /*#__PURE__*/_react.default.createElement("ul", {
      className: "footerLinks"
    }, /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/home.svg"
    }), "Home")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/stores"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/diamond.svg"
    }), "Stores")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/deals"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/deal.svg"
    }), "Deals")), /*#__PURE__*/_react.default.createElement("li", null, /*#__PURE__*/_react.default.createElement("a", {
      href: "/category"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/category.svg"
    }), "Categories"))));
  }

}

exports.Footer = Footer;
var _default = Footer;
exports.default = _default;