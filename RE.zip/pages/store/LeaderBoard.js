"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.LeaderBoard = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _reactstrap = require("reactstrap");

var _axios = _interopRequireDefault(require("axios"));

var _Autocomplete = _interopRequireDefault(require("@material-ui/lab/Autocomplete"));

var _TextField = _interopRequireDefault(require("@material-ui/core/TextField"));

// import moment from "moment"
// import { Dropdown } from 'semantic-ui-react'
const func = require('../parts/functions');

class LeaderBoard extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/adminLeaderBoard');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        data: body.data,
        storeList: body.store,
        publisherList: body.publisher,
        loading: false
      });
    });
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "handleClick", e => {
      this.setState({
        currentPage: Number(e.target.id)
      });
    });
    (0, _defineProperty2.default)(this, "changeitemsPerPage", e => {
      this.setState({
        itemsPerPage: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "searchSpace", e => {
      this.setState({
        search: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "addModalOn", () => {
      this.setState({
        addCashbackmodalIsOpen: true
      });
    });
    (0, _defineProperty2.default)(this, "addRewardPoints", () => {
      this.setState({
        addRewardModalIsOpen: true
      });
    });
    (0, _defineProperty2.default)(this, "setMinNum", async e => {
      var data = await func.setMinNum(e);
      this.setState({
        [e.target.name]: data
      });
    });
    (0, _defineProperty2.default)(this, "getUsers", async e => {
      this.setState({
        check: e.target.value
      });

      if (e.target.value.length > 5) {
        const data = {
          email: e.target.value
        };

        _axios.default.post('/admin/getUserOptions', data).catch(err => func.printError(err)).then(res => {
          this.setState({
            userOptions: res.data.data
          });
        });
      }
    });
    (0, _defineProperty2.default)(this, "resetData", () => {
      this.setState({
        addCashbackmodalIsOpen: false,
        addRedeemModalIsOpen: false,
        editRewardModalIsOpen: false,
        addRewardModalIsOpen: false,
        userId: '',
        reward: '',
        points: '',
        description: '',
        store: '',
        publisher: '',
        date: '',
        amount: '',
        redeem: '',
        maxPoints: '',
        rewardPayout: '',
        customerPayout: '',
        selectedId: ''
      });
      window.scrollTo(0, 0);
    });
    (0, _defineProperty2.default)(this, "addSubmit", e => {
      e.preventDefault();
      const data = new FormData();
      data.append('userId', this.state.userId);
      data.append('store', this.state.store);
      data.append('publisher', this.state.publisher);
      data.append('date', this.state.date);
      data.append('amount', this.state.amount);
      data.append('rewardPayout', this.state.rewardPayout);
      data.append('customerPayout', this.state.customerPayout);
      data.append('status', this.state.status);
      data.append('points', this.state.points);
      data.append('description', this.state.description);

      _axios.default.post('/admin/addCashback', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          this.state.data.some(el => el.id === res.data.data.id) ? this.setState({
            data: this.state.data.map(x => x.id === parseInt(res.data.data.id) ? x = res.data.data : x)
          }) : this.setState({
            data: [...this.state.data, res.data.data]
          });
        }

        func.callSwal(res.data.message);
      });

      this.resetData();
    });
    (0, _defineProperty2.default)(this, "addRewardSubmit", e => {
      e.preventDefault();
      const data = {
        'userId': this.state.userId,
        'points': this.state.points,
        'description': this.state.description
      };

      _axios.default.post('/admin/addReward', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          this.state.data.some(el => el.id === res.data.data.id) ? this.setState({
            data: this.state.data.map(x => x.id === parseInt(res.data.data.id) ? x = res.data.data : x)
          }) : this.setState({
            data: [...this.state.data, res.data.data]
          });
        }

        func.callSwal(res.data.message);
      });

      this.resetData();
    });
    (0, _defineProperty2.default)(this, "submitRedeem", e => {
      e.preventDefault();
      const data = {
        'userId': this.state.userId,
        'points': this.state.redeem,
        'description': this.state.description
      };

      _axios.default.post('/admin/redeemPoints', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          this.state.data.some(el => el.id === res.data.data.id) ? this.setState({
            data: this.state.data.map(x => x.id === parseInt(res.data.data.id) ? x = res.data.data : x)
          }) : this.setState({
            data: [...this.state.data, res.data.data]
          });
        }

        func.callSwal(res.data.message);
      });

      this.resetData();
    });
    (0, _defineProperty2.default)(this, "redeemPoints", i => {
      this.setState({
        userId: i.userId,
        maxPoints: i.total,
        addRedeemModalIsOpen: true
      });
    });
    (0, _defineProperty2.default)(this, "editModalOn", i => {
      this.setState({
        editmodalIsOpen: true,
        selectedId: i.id
      });
    });
    (0, _defineProperty2.default)(this, "updateSubmit", e => {
      e.preventDefault();
      const data = new FormData();
      data.append('id', this.state.selectedId);
      data.append('store', this.state.store);
      data.append('url', this.state.url.replace(/ /g, "-"));
      data.append('category', this.state.category);
      data.append('title', this.state.title);
      data.append('percent', this.state.percent);
      data.append('image', this.state.image);
      data.append('tagline', this.state.tagline);
      data.append('cutoff', this.state.cutoff);
      data.append('current_value', this.state.current_value);
      data.append('status', this.state.status);
      data.append('oldImageName', this.state.oldImageName);

      _axios.default.post('/admin/updateDeal', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          this.setState({
            data: this.state.data.map(x => x.id === parseInt(res.data.data.id) ? x = res.data.data : x)
          });
        }

        func.callSwal(res.data.message);
      });

      this.resetData();
    });
    (0, _defineProperty2.default)(this, "handleAutoChange", (e, value) => {
      this.setState({
        userId: value.id
      });
    });
    this.state = {
      addCashbackmodalIsOpen: false,
      addRedeemModalIsOpen: false,
      editRewardModalIsOpen: false,
      data: [],
      userOptions: [],
      check: '',
      storeList: [],
      publisherList: [],
      userId: '',
      reward: '',
      points: '',
      description: '',
      store: '',
      publisher: '',
      date: '',
      amount: '',
      redeem: '',
      rewardPayout: '',
      customerPayout: '',
      selectedId: '',
      search: '',
      currentPage: 1,
      itemsPerPage: 100,
      loading: true,
      status: '' // userOptions:                        [
      //     {id: 1, name: 'aaaaaaaa'},
      //     {id: 2, name: 'bbbbbbbbbb'},
      //     {id: 3, name: 'cccccccc'},
      //     {id: 4, name: 'ddddddddd'},
      //     {id: 5, name: 'eeeeeee'},
      // ],

    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  render() {
    const {
      currentPage,
      itemsPerPage
    } = this.state;
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const renderItems = this.state.data.filter(i => {
      if (this.state.search == null) return i;else if (i.name ? i.name.toLowerCase().includes(this.state.search.toLowerCase()) : null || i.email ? i.email.toLowerCase().includes(this.state.search.toLowerCase()) : null) {
        return i;
      }
    }).slice(indexOfFirstItem, indexOfLastItem).map((i, index) => {
      return /*#__PURE__*/_react.default.createElement("tr", {
        key: index
      }, /*#__PURE__*/_react.default.createElement("td", null, index + 1), /*#__PURE__*/_react.default.createElement("td", null, i.name, /*#__PURE__*/_react.default.createElement("br", null), i.email, " / ", i.phone), /*#__PURE__*/_react.default.createElement("td", null, i.cashback), /*#__PURE__*/_react.default.createElement("td", null, i.reward), /*#__PURE__*/_react.default.createElement("td", null, i.redeemed), /*#__PURE__*/_react.default.createElement("td", null, i.total), /*#__PURE__*/_react.default.createElement("td", {
        className: "editIcon text-center"
      }, /*#__PURE__*/_react.default.createElement("img", {
        src: "/images/icons/edit.svg",
        alt: "Edit Icon",
        onClick: () => this.redeemPoints(i)
      })));
    });
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(this.state.data.length / itemsPerPage); i++) {
      pageNumbers.push(i);
    }

    const renderPagination = pageNumbers.map(number => {
      if (currentPage == number) {
        return /*#__PURE__*/_react.default.createElement("li", {
          key: number,
          id: number,
          onClick: this.handleClick,
          className: "active"
        }, " ", number);
      } else {
        return /*#__PURE__*/_react.default.createElement("li", {
          key: number,
          id: number,
          onClick: this.handleClick
        }, " ", number);
      }
    });
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( LeaderBoard )"), /*#__PURE__*/_react.default.createElement("div", {
      className: "btn-pag"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "perPage"
    }, /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("label", null, "Add Cashback here"), /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      onClick: this.addModalOn
    }, "Add Cashback")), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement("label", null, "Add Reward Points here"), /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      onClick: this.addRewardPoints
    }, "Add Reward Points"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "search"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex mr-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Items per page"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      required: true,
      value: itemsPerPage,
      onChange: e => this.changeitemsPerPage(e)
    }, /*#__PURE__*/_react.default.createElement("option", null, itemsPerPage), /*#__PURE__*/_react.default.createElement("option", {
      value: "10"
    }, "10"), /*#__PURE__*/_react.default.createElement("option", {
      value: "25"
    }, "25"), /*#__PURE__*/_react.default.createElement("option", {
      value: "50"
    }, "50"), /*#__PURE__*/_react.default.createElement("option", {
      value: "100"
    }, "100"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex searchInput"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Search Here"), /*#__PURE__*/_react.default.createElement("input", {
      type: "text",
      placeholder: "Search here",
      className: "form-control",
      onChange: e => this.searchSpace(e)
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "noFlex"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Page Numbers"), /*#__PURE__*/_react.default.createElement("ul", {
      className: "page-numbers"
    }, renderPagination, " ")))), /*#__PURE__*/_react.default.createElement("table", {
      className: "table table-hover table-responsive"
    }, /*#__PURE__*/_react.default.createElement("thead", null, /*#__PURE__*/_react.default.createElement("tr", null, /*#__PURE__*/_react.default.createElement("td", null, "Sl no."), /*#__PURE__*/_react.default.createElement("td", null, "User"), /*#__PURE__*/_react.default.createElement("td", null, "Cashback"), /*#__PURE__*/_react.default.createElement("td", null, "Reward Points"), /*#__PURE__*/_react.default.createElement("td", null, "Redeemed"), /*#__PURE__*/_react.default.createElement("td", null, "Total"), /*#__PURE__*/_react.default.createElement("td", null, "Redeem"))), /*#__PURE__*/_react.default.createElement("tbody", null, this.state.loading ? /*#__PURE__*/_react.default.createElement("tr", {
      className: "loading"
    }, /*#__PURE__*/_react.default.createElement("td", {
      colSpan: "6",
      className: "text-center"
    }, /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/icons/loading.gif"
    }))) : renderItems))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.addCashbackmodalIsOpen,
      className: "adminModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalHeader, null, " Add Cashback Here "), /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.addSubmit
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 blogMeta compare label-down"
    }, /*#__PURE__*/_react.default.createElement(_Autocomplete.default, {
      id: "combo-box-demo",
      options: this.state.userOptions,
      getOptionLabel: option => option.name,
      renderInput: params => /*#__PURE__*/_react.default.createElement(_TextField.default, (0, _extends2.default)({}, params, {
        label: this.state.userOptions.length ? "Search Here - " + this.state.userOptions.length : "Search Here",
        variant: "outlined"
      })),
      onInputChange: e => this.getUsers(e),
      onChange: this.handleAutoChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Cashback Points"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      step: ".01",
      className: "form-control",
      name: "points",
      value: this.state.points,
      onChange: this.setMinNum,
      placeholder: "Cahback Points Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Cashback Status"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "status",
      value: this.state.status,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Status"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Approved"
    }, "Approved"), /*#__PURE__*/_react.default.createElement("option", {
      value: "Pending"
    }, "Pending"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Description"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Desscription Here",
      name: "description",
      value: this.state.description,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Store Name"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "store",
      value: this.state.store,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Store"), this.state.storeList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Publisher"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "publisher",
      value: this.state.publisher,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Publisher"), this.state.publisherList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Date"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "date",
      required: true,
      value: this.state.date,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Amount"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "amount",
      value: this.state.amount,
      onChange: this.setMinNum,
      placeholder: "Enter Amount",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Reward Payout"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "rewardPayout",
      value: this.state.rewardPayout,
      onChange: this.setMinNum,
      placeholder: "Reward Payout",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Customer Payout"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "customerPayout",
      value: this.state.customerPayout,
      onChange: this.setMinNum,
      placeholder: "Customer Payout",
      required: true
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit"))))), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.addRedeemModalIsOpen,
      className: "adminModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalHeader, null, " Redeem Points here "), /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("form", {
      className: "modal-form",
      encType: "multipart/form-data",
      onSubmit: this.submitRedeem
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Redeem Points"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      step: ".01",
      className: "form-control",
      name: "redeem",
      value: this.state.redeem,
      onChange: this.setMinNum,
      max: this.state.maxPoints,
      placeholder: "Add Redeem Points Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Description"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Desscription Here",
      name: "description",
      value: this.state.description,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit"))))), /*#__PURE__*/_react.default.createElement(_reactstrap.Modal, {
      isOpen: this.state.addRewardModalIsOpen,
      className: "adminModal"
    }, /*#__PURE__*/_react.default.createElement(_reactstrap.ModalHeader, null, " Add Reward Points Here "), /*#__PURE__*/_react.default.createElement("div", {
      className: "closeModal",
      onClick: this.resetData
    }, "X"), /*#__PURE__*/_react.default.createElement(_reactstrap.ModalBody, null, /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.addRewardSubmit
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6 blogMeta compare label-down"
    }, /*#__PURE__*/_react.default.createElement(_Autocomplete.default, {
      id: "combo-box-demo",
      options: this.state.userOptions,
      getOptionLabel: option => option.name,
      renderInput: params => /*#__PURE__*/_react.default.createElement(_TextField.default, (0, _extends2.default)({}, params, {
        label: this.state.userOptions.length ? "Search Here - " + this.state.userOptions.length : "Search Here",
        variant: "outlined"
      })),
      onInputChange: e => this.getUsers(e),
      onChange: this.handleAutoChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Reward Points"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      step: ".01",
      className: "form-control",
      name: "points",
      value: this.state.points,
      onChange: this.setMinNum,
      placeholder: "Add Reward Points Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Description"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Desscription Here",
      name: "description",
      value: this.state.description,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit"))))));
  }

}

exports.LeaderBoard = LeaderBoard;
var _default = LeaderBoard;
exports.default = _default;