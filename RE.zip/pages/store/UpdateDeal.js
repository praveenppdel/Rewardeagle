"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.UpdateDeal = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _axios = _interopRequireDefault(require("axios"));

var _semanticUiReact = require("semantic-ui-react");

const func = require('../parts/functions');

class UpdateDeal extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "timeout", delay => {
      return new Promise(res => setTimeout(res, delay));
    });
    (0, _defineProperty2.default)(this, "setMinNum", async e => {
      var data = await func.setMinNum(e);
      this.setState({
        [e.target.name]: data
      });
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const id = window.location.href.split("/").pop();
      this.setState({
        id: id
      });
      await this.timeout(2000);
      this.setState({
        loading: false
      });

      _axios.default.get('/admin/getDeal/' + id).then(res => {
        this.setState({
          store: res.data.data.store,
          url: res.data.data.url,
          tlink: res.data.data.tlink,
          category: res.data.data.category,
          publisher: res.data.data.publisher,
          title: res.data.data.title,
          deal_type: res.data.data.deal_type,
          percent: res.data.data.percent,
          tags: res.data.data.tags,
          tagline: res.data.data.tagline,
          cutoff: res.data.data.cutoff,
          current_value: res.data.data.current_value,
          offer_count: res.data.data.offer_count,
          status: res.data.data.status,
          tnc: res.data.data.tnc,
          discription: res.data.data.discription,
          start: res.data.data.start,
          expiry: res.data.data.expiry,
          tagData: res.data.tagData,
          offday: res.data.data.offday,
          // image :                     res.data.data.image,
          // oldImageName :              res.data.data.image,
          publisherList: res.data.publisherList,
          categoryList: res.data.categoryList,
          tagOptions: res.data.tagOptions,
          storeList: res.data.store
        });
      });
    });
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "tagSelected", (e, {
      value
    }) => {
      this.setState({
        selectedTag: value
      });
    });
    (0, _defineProperty2.default)(this, "submitHandler", e => {
      e.preventDefault();
      const tagList = [];
      this.state.tagData.forEach(i => {
        tagList.push(i.value);
      });
      var finalTag = Array.from(new Set([...tagList, ...this.state.selectedTag]));
      const data = new FormData();
      data.append('id', this.state.id);
      data.append('store', this.state.store);
      data.append('url', this.state.url.replace(/ /g, "-").toLowerCase());
      data.append('tlink', this.state.tlink);
      data.append('category', this.state.category);
      data.append('publisher', this.state.publisher);
      data.append('title', this.state.title);
      data.append('deal_type', this.state.deal_type);
      data.append('percent', this.state.percent);
      data.append('tags', JSON.stringify(finalTag));
      data.append('tagline', this.state.tagline);
      data.append('cutoff', this.state.cutoff);
      data.append('current_value', this.state.current_value);
      data.append('offer_count', this.state.offer_count);
      data.append('status', this.state.status);
      data.append('tnc', this.state.tnc);
      data.append('discription', this.state.discription);
      data.append('start', this.state.start.split('T')[0]);
      data.append('expiry', this.state.expiry.split('T')[0]);
      data.append('offday', this.state.offday); // data.append('image', this.state.image)
      // data.append('oldImageName', this.state.oldImageName)

      _axios.default.post('/admin/updateDeal', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          localStorage.setItem('message', res.data.message);
          window.location.href = '/admin/adminDeal';
        }

        func.callSwal(res.data.message);
      });
    });
    this.state = {
      id: '',
      store: '',
      url: '',
      tlink: '',
      category: '',
      publisher: '',
      title: '',
      deal_type: '',
      percent: '',
      tags: '',
      tagline: '',
      cutoff: '',
      current_value: '',
      offer_count: '',
      status: '',
      tnc: '',
      discription: '',
      start: '',
      expiry: '',
      offday: '',
      // image :                   '',
      // oldImageName :            '',
      storeList: [],
      categoryList: [],
      publisherList: [],
      tagOptions: [],
      tagData: [],
      selectedTag: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  arrayTagRemove(index) {
    this.state.tagData.splice(index, 1);
    this.setState({
      tagData: this.state.tagData
    });
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( Update Deal )"), /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Store Name"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "store",
      value: this.state.store,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Store"), this.state.storeList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Category Name"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "category",
      value: this.state.category,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Category"), this.state.categoryList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Internal URL"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Internal URL of Deal",
      name: "url",
      required: true,
      value: this.state.url,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Status"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "status",
      value: this.state.status,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Status"), /*#__PURE__*/_react.default.createElement("option", {
      value: "1"
    }, "Active"), /*#__PURE__*/_react.default.createElement("option", {
      value: "0"
    }, "Close"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Title"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Title Here",
      name: "title",
      required: true,
      value: this.state.title,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Percent"), /*#__PURE__*/_react.default.createElement("input", {
      type: "text",
      className: "form-control",
      name: "percent",
      value: this.state.percent,
      onChange: this.onChange,
      placeholder: "Add Percent Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Off The day"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Off The day",
      name: "offday",
      required: true,
      value: this.state.offday,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Tagline"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Tagline Here",
      name: "tagline",
      required: true,
      value: this.state.tagline,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Cut off"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "cutoff",
      value: this.state.cutoff,
      onChange: this.setMinNum,
      placeholder: "Add Cutoff Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Current Value"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "current_value",
      value: this.state.current_value,
      onChange: this.setMinNum,
      placeholder: "Add Current Value Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Offer Count"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 0,
      className: "form-control",
      name: "offer_count",
      value: this.state.offer_count,
      onChange: this.setMinNum,
      placeholder: "Add Offer Count Here",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Publisher"), /*#__PURE__*/_react.default.createElement("select", {
      className: "form-control",
      name: "publisher",
      required: true,
      value: this.state.publisher,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Publisher"), this.state.publisherList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Commission Type"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "deal_type",
      value: this.state.deal_type,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Type"), /*#__PURE__*/_react.default.createElement("option", {
      value: "1"
    }, "Value Based"), /*#__PURE__*/_react.default.createElement("option", {
      value: "2"
    }, "Percentage Based"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Start"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "start",
      required: true,
      value: this.state.start.split('T')[0],
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Expiry"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "expiry",
      required: true,
      value: this.state.expiry.split('T')[0],
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Terms & Conditions"), /*#__PURE__*/_react.default.createElement("textarea", {
      className: "form-control",
      type: "text",
      placeholder: "Add Terms & Conditions",
      name: "tnc",
      required: true,
      value: this.state.tnc,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Discription"), /*#__PURE__*/_react.default.createElement("textarea", {
      className: "form-control",
      type: "text",
      placeholder: "Add Discription Here",
      name: "discription",
      required: true,
      value: this.state.discription,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 compare label-down"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Add Tags"), /*#__PURE__*/_react.default.createElement("div", {
      className: "update-treat"
    }, this.state.tagData.length ? /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.state.tagData.map((i, index) => /*#__PURE__*/_react.default.createElement("span", {
      className: "ui label mr-3",
      key: index
    }, i.text, /*#__PURE__*/_react.default.createElement("i", {
      "aria-hidden": "true",
      className: "delete icon",
      onClick: () => this.arrayTagRemove(index)
    })))) : null), /*#__PURE__*/_react.default.createElement(_semanticUiReact.Dropdown, {
      placeholder: "Select Tags",
      multiple: true,
      fluid: true,
      search: true,
      selection: true,
      onChange: this.tagSelected,
      options: this.state.tagOptions
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Tracking Link"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Tracking Link of Coupon",
      name: "tlink",
      required: true,
      value: this.state.tlink,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit")))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.UpdateDeal = UpdateDeal;
var _default = UpdateDeal;
exports.default = _default;