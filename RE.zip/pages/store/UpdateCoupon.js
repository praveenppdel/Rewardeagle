"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.UpdateCoupon = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _axios = _interopRequireDefault(require("axios"));

var _semanticUiReact = require("semantic-ui-react");

const func = require('../parts/functions');

class UpdateCoupon extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "timeout", delay => {
      return new Promise(res => setTimeout(res, delay));
    });
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const id = window.location.href.split("/").pop();
      this.setState({
        id: id
      });
      await this.timeout(2000);
      this.setState({
        loading: false
      });

      _axios.default.get('/admin/getCoupon/' + id).then(res => {
        this.setState({
          store: res.data.data.store,
          category: res.data.data.category,
          tags: res.data.data.tags,
          title: res.data.data.title,
          url: res.data.data.url,
          tlink: res.data.data.tlink,
          publisher: res.data.data.publisher,
          commission: res.data.data.commission,
          image: res.data.data.image,
          offer: res.data.data.offer,
          cashback: res.data.data.cashback,
          status: res.data.data.status,
          tnc: res.data.data.tnc,
          discription: res.data.data.discription,
          start: res.data.data.start,
          expiry: res.data.data.expiry,
          coupon_type: res.data.data.coupon_type,
          oldImageName: res.data.data.image,
          publisherList: res.data.publisherList,
          categoryList: res.data.categoryList,
          tagOptions: res.data.tagOptions,
          storeList: res.data.store,
          tagData: res.data.tagData
        });
      });
    });
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "uploadImage", e => {
      this.setState({
        image: e.target.files[0]
      });
    });
    (0, _defineProperty2.default)(this, "tagSelected", (e, {
      value
    }) => {
      this.setState({
        selectedTag: value
      });
    });
    (0, _defineProperty2.default)(this, "submitHandler", e => {
      e.preventDefault();
      const tagList = [];
      this.state.tagData.forEach(i => {
        tagList.push(i.value);
      });
      var finalTag = Array.from(new Set([...tagList, ...this.state.selectedTag]));
      const data = new FormData();
      data.append('id', this.state.id);
      data.append('store', this.state.store);
      data.append('category', this.state.category);
      data.append('tags', JSON.stringify(finalTag));
      data.append('title', this.state.title);
      data.append('url', this.state.url.replace(/ /g, "-").toLowerCase());
      data.append('tlink', this.state.tlink);
      data.append('publisher', this.state.publisher);
      data.append('commission', this.state.commission);
      data.append('image', this.state.image);
      data.append('offer', this.state.offer);
      data.append('cashback', this.state.cashback);
      data.append('status', this.state.status);
      data.append('tnc', this.state.tnc);
      data.append('discription', this.state.discription);
      data.append('start', this.state.start.split('T')[0]);
      data.append('expiry', this.state.expiry.split('T')[0]);
      data.append('coupon_type', this.state.coupon_type);
      data.append('oldImageName', this.state.oldImageName);

      _axios.default.post('/admin/updateCoupon', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          localStorage.setItem('message', res.data.message);
          window.location.href = '/admin/adminCoupon';
        }

        func.callSwal(res.data.message);
      });
    });
    this.state = {
      id: '',
      store: '',
      category: '',
      tags: '',
      title: '',
      url: '',
      tlink: '',
      publisher: '',
      commission: '',
      image: '',
      offer: '',
      cashback: '',
      status: '',
      tnc: '',
      discription: '',
      start: '',
      expiry: '',
      coupon_type: '',
      oldImageName: '',
      storeList: [],
      categoryList: [],
      publisherList: [],
      tagOptions: [],
      tagData: [],
      selectedTag: []
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  arrayTagRemove(index) {
    this.state.tagData.splice(index, 1);
    this.setState({
      tagData: this.state.tagData
    });
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( Update Coupon )"), /*#__PURE__*/_react.default.createElement("form", {
      className: "modal-form",
      encType: "multipart/form-data",
      onSubmit: this.submitHandler
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Store Name"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "store",
      value: this.state.store,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Store"), this.state.storeList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Category Name"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "category",
      value: this.state.category,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Category"), this.state.categoryList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Publisher Name"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "publisher",
      value: this.state.publisher,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Publisher"), this.state.publisherList.map((i, index) => /*#__PURE__*/_react.default.createElement("option", {
      value: i.id,
      key: index
    }, i.name)))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Internal URL"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Internal URL of Coupon",
      name: "url",
      required: true,
      value: this.state.url,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Status"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "status",
      value: this.state.status,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Status"), /*#__PURE__*/_react.default.createElement("option", {
      value: "1"
    }, "Active"), /*#__PURE__*/_react.default.createElement("option", {
      value: "0"
    }, "Close"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-9"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Title"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Title Here",
      name: "title",
      required: true,
      value: this.state.title,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Commission"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Commission Here",
      name: "commission",
      required: true,
      value: this.state.commission,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Cashback"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Cashback Here",
      name: "cashback",
      required: true,
      value: this.state.cashback,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Coupon Code"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Add Coupon Code Here",
      name: "offer",
      required: true,
      value: this.state.offer,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Start"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "start",
      required: true,
      value: this.state.start.split('T')[0],
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Expiry"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "date",
      name: "expiry",
      required: true,
      value: this.state.expiry.split('T')[0],
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Commission Type"), /*#__PURE__*/_react.default.createElement("select", {
      type: "select",
      className: "form-control",
      required: true,
      name: "coupon_type",
      value: this.state.coupon_type,
      onChange: this.onChange
    }, /*#__PURE__*/_react.default.createElement("option", {
      value: ""
    }, "Select Type"), /*#__PURE__*/_react.default.createElement("option", {
      value: "1"
    }, "Value Based"), /*#__PURE__*/_react.default.createElement("option", {
      value: "2"
    }, "Percentage Based"))), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-3"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Image"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "file",
      onChange: this.uploadImage
    }), this.state.oldImageName ? /*#__PURE__*/_react.default.createElement("img", {
      src: "/images/store/coupon/" + this.state.oldImageName,
      className: "img-fluid tableImg"
    }) : null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 compare label-down"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Add Tags"), this.state.tagData.length ? /*#__PURE__*/_react.default.createElement("div", {
      className: "update-treat"
    }, this.state.tagData.map((i, index) => /*#__PURE__*/_react.default.createElement("span", {
      className: "ui label mr-3",
      key: index
    }, i.text, /*#__PURE__*/_react.default.createElement("i", {
      "aria-hidden": "true",
      className: "delete icon",
      onClick: () => this.arrayTagRemove(index)
    })))) : null, /*#__PURE__*/_react.default.createElement(_semanticUiReact.Dropdown, {
      placeholder: "Select Tags",
      multiple: true,
      fluid: true,
      search: true,
      selection: true,
      onChange: this.tagSelected,
      options: this.state.tagOptions
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Terms & Conditions"), /*#__PURE__*/_react.default.createElement("textarea", {
      className: "form-control",
      type: "text",
      placeholder: "Add Terms & Conditions",
      name: "tnc",
      required: true,
      value: this.state.tnc,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-6"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Discription"), /*#__PURE__*/_react.default.createElement("textarea", {
      className: "form-control",
      type: "text",
      placeholder: "Add Discription Here",
      name: "discription",
      required: true,
      value: this.state.discription,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Tracking Link"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Tracking Link of Coupon",
      name: "tlink",
      required: true,
      value: this.state.tlink,
      onChange: this.onChange
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit")))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.UpdateCoupon = UpdateCoupon;
var _default = UpdateCoupon;
exports.default = _default;