"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.CreateStore = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _Header = _interopRequireDefault(require("../parts/Header"));

var _Footer = _interopRequireDefault(require("../parts/Footer"));

var _AdminBar = _interopRequireDefault(require("../parts/AdminBar"));

var _axios = _interopRequireDefault(require("axios"));

var _ckeditor4React = _interopRequireDefault(require("ckeditor4-react"));

var _semanticUiReact = require("semantic-ui-react");

const func = require('../parts/functions');

class CreateStore extends _react.Component {
  constructor(props) {
    super(props);
    (0, _defineProperty2.default)(this, "callApi", async () => {
      const response = await fetch('/admin/publisherList');
      const body = await response.json();
      if (response.status !== 200) throw Error(body.message);
      this.setState({
        publisherList: body.data,
        categoryList: body.categoryList,
        tagOptions: body.tagOptions,
        catOptions: body.catOptions,
        publisherOptions: body.publisherOptions
      });
    });
    (0, _defineProperty2.default)(this, "onChange", e => {
      this.setState({
        [e.target.name]: e.target.value
      });
    });
    (0, _defineProperty2.default)(this, "uploadLogo", e => {
      this.setState({
        logo: e.target.files[0],
        previewLogo: URL.createObjectURL(e.target.files[0])
      });
    });
    (0, _defineProperty2.default)(this, "uploadBanner", e => {
      this.setState({
        banner: e.target.files[0],
        previewBanner: URL.createObjectURL(e.target.files[0])
      });
    });
    (0, _defineProperty2.default)(this, "setMinNum", async e => {
      var data = await func.setMinNum(e);
      this.setState({
        display_order: data
      });
    });
    (0, _defineProperty2.default)(this, "tagSelected", (e, {
      value
    }) => {
      this.setState({
        selectedTag: value
      });
    });
    (0, _defineProperty2.default)(this, "catSelected", (e, {
      value
    }) => {
      this.setState({
        selectedCat: value
      });
    });
    (0, _defineProperty2.default)(this, "pubSelected", (e, {
      value
    }) => {
      this.setState({
        selectedPub: value
      });
    });
    (0, _defineProperty2.default)(this, "addSubmit", e => {
      e.preventDefault();
      const data = new FormData();
      data.append('name', this.state.name);
      data.append('title', this.state.title);
      data.append('display_order', this.state.display_order);
      data.append('url', this.state.url.replace(/ /g, "-").toLowerCase());
      data.append('tlink', this.state.tlink);
      data.append('description', this.state.description); // data.append('publisher', this.state.publisher)

      data.append('publisher', JSON.stringify(this.state.selectedPub));
      data.append('logo', this.state.logo);
      data.append('category', JSON.stringify(this.state.selectedCat));
      data.append('tags', JSON.stringify(this.state.selectedTag));
      data.append('banner', this.state.banner);
      data.append('tagline', this.state.tagline);
      data.append('salesline', this.state.salesline);
      data.append('cashback', this.state.cashback);

      _axios.default.post('/admin/addStore', data).catch(err => func.printError(err)).then(res => {
        if (res.data.success) {
          localStorage.setItem('message', res.data.message);
          window.location.href = '/admin/adminStore';
        }

        func.callSwal(res.data.message);
      });
    });
    this.state = {
      name: '',
      publisher: '',
      display_order: '',
      url: '',
      tlink: '',
      title: '',
      description: '',
      logo: null,
      previewLogo: null,
      banner: null,
      previewBanner: null,
      // category:                   '',
      tagline: '',
      salesline: '',
      cashback: '',
      publisherList: [],
      publisherOptions: [],
      // categoryList:               [],
      catOptions: [],
      tagOptions: [],
      selectedCat: [],
      selectedTag: [],
      selectedPub: []
    };
    this.handleChange1 = this.handleChange1.bind(this);
    this.onEditorChange1 = this.onEditorChange1.bind(this);
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.callApi();
  }

  onEditorChange1(evt1) {
    this.setState({
      description: evt1.editor.getData()
    });
  }

  handleChange1(changeEvent1) {
    this.setState({
      description: changeEvent1.target.value
    });
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "container-fluid admin"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement(_AdminBar.default, null), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-10"
    }, /*#__PURE__*/_react.default.createElement("h2", {
      className: "heading"
    }, "Admin ( Create Store )"), /*#__PURE__*/_react.default.createElement("form", {
      encType: "multipart/form-data",
      onSubmit: this.addSubmit
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "row"
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Store Name"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Store Name",
      name: "name",
      required: true,
      value: this.state.name,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, this.state.previewLogo ? /*#__PURE__*/_react.default.createElement("img", {
      src: this.state.previewLogo,
      alt: "",
      className: "img-fluid tableImg"
    }) : null, /*#__PURE__*/_react.default.createElement("label", null, "Logo"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "file",
      onChange: this.uploadLogo
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, this.state.previewBanner ? /*#__PURE__*/_react.default.createElement("img", {
      src: this.state.previewBanner,
      alt: "",
      className: "img-fluid tableImg"
    }) : null, /*#__PURE__*/_react.default.createElement("label", null, "Banner"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "file",
      onChange: this.uploadBanner
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Display Order"), /*#__PURE__*/_react.default.createElement("input", {
      type: "number",
      onKeyDown: e => e.key === 'e' && e.preventDefault(),
      min: 1,
      className: "form-control",
      name: "display_order",
      value: this.state.display_order,
      onChange: this.setMinNum,
      placeholder: "Display Order",
      required: true
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Internal URL"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Internal URL",
      name: "url",
      required: true,
      value: this.state.url,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Tagline"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Tagline",
      name: "tagline",
      required: true,
      value: this.state.tagline,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Store Title"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Store Title",
      name: "title",
      required: true,
      value: this.state.title,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Cashback"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Cashback",
      name: "cashback",
      required: true,
      value: this.state.cashback,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-4"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Sales Line"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Sales Line",
      name: "salesline",
      required: true,
      value: this.state.salesline,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Tracking Link"), /*#__PURE__*/_react.default.createElement("input", {
      className: "form-control",
      type: "text",
      placeholder: "Tracking Link",
      name: "tlink",
      required: true,
      value: this.state.tlink,
      onChange: this.onChange
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Description"), /*#__PURE__*/_react.default.createElement(_ckeditor4React.default, {
      onBeforeLoad: CKEDITOR => CKEDITOR.disableAutoInline = true,
      content: this.state.description,
      onChange: this.onEditorChange1,
      config: {
        extraAllowedContent: "*(*); div(col-sm-*, container-fluid, container, row)"
      }
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 compare label-down mb-5"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Add Category"), /*#__PURE__*/_react.default.createElement(_semanticUiReact.Dropdown, {
      placeholder: "Select Category",
      multiple: true,
      fluid: true,
      search: true,
      selection: true,
      onChange: this.catSelected,
      options: this.state.catOptions
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 compare label-down mb-5"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Add Tags"), /*#__PURE__*/_react.default.createElement(_semanticUiReact.Dropdown, {
      placeholder: "Select Tags",
      multiple: true,
      fluid: true,
      search: true,
      selection: true,
      onChange: this.tagSelected,
      options: this.state.tagOptions
    })), /*#__PURE__*/_react.default.createElement("div", {
      className: "col-sm-12 compare label-down mb-5"
    }, /*#__PURE__*/_react.default.createElement("label", null, "Add Publishers"), /*#__PURE__*/_react.default.createElement(_semanticUiReact.Dropdown, {
      placeholder: "Select Publishers",
      multiple: true,
      fluid: true,
      search: true,
      selection: true,
      onChange: this.pubSelected,
      options: this.state.publisherOptions
    }))), /*#__PURE__*/_react.default.createElement("div", {
      className: "my-div"
    }, /*#__PURE__*/_react.default.createElement("button", {
      className: "casleyBtn",
      type: "submit"
    }, "Submit", /*#__PURE__*/_react.default.createElement("span", null))))))), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
  }

}

exports.CreateStore = CreateStore;
var _default = CreateStore;
exports.default = _default;